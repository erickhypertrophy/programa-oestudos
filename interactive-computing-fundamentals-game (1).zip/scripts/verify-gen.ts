import { makeGen } from '../src/components/Exercise';
import { normalizeAnswer, fromTwos } from '../src/lib/logic';
let fails = 0;
for (const kind of ['dec2bin','bin2dec','hex2dec','bin2hex','dec2hex','twos','addbin']) for (let d=0; d<3; d++) for (let i=0;i<300;i++) {
  const g = makeGen(kind, d);
  const num = (g.prompt.match(/\*\*(.+?)\*\*/g) ?? []).map(s=>s.replace(/\*/g,''));
  let expect = '';
  if (kind==='dec2bin') expect = (+num[0]).toString(2);
  if (kind==='bin2dec') expect = String(parseInt(num[0],2));
  if (kind==='hex2dec') expect = String(parseInt(num[0],16));
  if (kind==='bin2hex') expect = parseInt(num[0],2).toString(16);
  if (kind==='dec2hex') expect = (+num[0]).toString(16);
  if (kind==='twos') { const a = g.answer[0]; if (fromTwos(a) !== +num[0] || a.length!==8) { fails++; console.log('twos', num[0], a); } continue; }
  if (kind==='addbin') { const [x,y] = num[0].split(' + '); expect = (parseInt(x,2)+parseInt(y,2)).toString(2); }
  if (!g.answer.map(normalizeAnswer).includes(normalizeAnswer(expect))) { fails++; console.log(kind, g.prompt, g.answer, expect); }
}
console.log(fails ? `❌ ${fails} falhas` : '✅ geradores OK (6300 amostras)');
