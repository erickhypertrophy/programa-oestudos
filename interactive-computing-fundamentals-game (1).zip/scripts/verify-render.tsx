import React from 'react';
import { renderToString } from 'react-dom/server';
(globalThis as any).localStorage = { getItem: () => null, setItem: () => {}, removeItem: () => {} };
(globalThis as any).window = { scrollTo: () => {} };
import { PHASES } from '../src/content';
import { Markdown } from '../src/components/Markdown';
import { ExerciseView } from '../src/components/Exercise';
import { Demo } from '../src/components/Demos';
import { Guide } from '../src/components/Screens';
let n = 0;
for (const p of PHASES) for (const s of p.sections) {
  const html = renderToString(<Markdown text={s.body} />); n++;
  if (html.includes('demo desconhecida')) throw new Error('demo desconhecida em ' + s.id);
  for (const ex of s.exercises) renderToString(<ExerciseView ex={ex} difficulty={1} done={false} onAttempt={() => {}} onDone={() => {}} />);
}
for (const p of PHASES) for (const ex of p.boss.exercises) renderToString(<ExerciseView ex={ex} difficulty={2} done={false} onAttempt={() => {}} onDone={() => {}} />);
for (const d of ['bit-switch','counter-4','counter-8','text-bits','color-bits','gates-basic','gates-all','gates-nand','adder-1','adder-8','twos','sr-latch','dff','mux','cpu','powers']) renderToString(<Demo name={d} />);
renderToString(<Guide back={() => {}} />);
console.log(`✅ renderizou ${n} seções, todos os exercícios, 16 demos e o guia sem erros`);
