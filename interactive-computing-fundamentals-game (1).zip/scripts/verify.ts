// Verificação automática do conteúdo: roda com `npx tsx scripts/verify.ts`
import { PHASES } from '../src/content';
import { evalCircuit, allCombos, type GateNode, normalizeAnswer, toBin, toTwos, fromTwos } from '../src/lib/logic';

let fails = 0;
const fail = (m: string) => { fails++; console.log('❌', m); };
const ok = (m: string) => console.log('✅', m);

// soluções conhecidas para cada circuito (id -> lista de portas)
const SOL: Record<string, GateNode[]> = {
  'f4-s2-e3': [{ kind: 'NOT', in1: 'B', in2: null }, { kind: 'AND', in1: 'A', in2: 'g0' }],
  'f4-s2-e4': [{ kind: 'OR', in1: 'A', in2: 'B' }, { kind: 'NOT', in1: 'g0', in2: null }],
  'f4-s3-e1': [{ kind: 'NAND', in1: 'A', in2: 'A' }],
  'f4-s3-e2': [{ kind: 'NAND', in1: 'A', in2: 'B' }, { kind: 'NAND', in1: 'g0', in2: 'g0' }],
  'f4-s3-e3': [{ kind: 'NAND', in1: 'A', in2: 'A' }, { kind: 'NAND', in1: 'B', in2: 'B' }, { kind: 'NAND', in1: 'g0', in2: 'g1' }],
  'f4-s3-e4': [{ kind: 'NAND', in1: 'A', in2: 'B' }, { kind: 'NAND', in1: 'A', in2: 'g0' }, { kind: 'NAND', in1: 'B', in2: 'g0' }, { kind: 'NAND', in1: 'g1', in2: 'g2' }],
  'f4-s3-e5': [{ kind: 'AND', in1: 'A', in2: 'B' }, { kind: 'AND', in1: 'A', in2: 'C' }, { kind: 'AND', in1: 'B', in2: 'C' }, { kind: 'OR', in1: 'g0', in2: 'g1' }, { kind: 'OR', in1: 'g3', in2: 'g2' }],
  'f4-s4-e1': [{ kind: 'NOT', in1: 'S', in2: null }, { kind: 'AND', in1: 'A', in2: 'g0' }, { kind: 'AND', in1: 'B', in2: 'S' }, { kind: 'OR', in1: 'g1', in2: 'g2' }],
  'f4-s4-e2': [{ kind: 'NOT', in1: 'B', in2: null }, { kind: 'AND', in1: 'A', in2: 'g0' }],
  'f4-b1': [{ kind: 'NAND', in1: 'A', in2: 'A' }, { kind: 'NAND', in1: 'B', in2: 'B' }, { kind: 'NAND', in1: 'g0', in2: 'g1' }, { kind: 'NAND', in1: 'g2', in2: 'g2' }],
  'f4-b2': [{ kind: 'OR', in1: 'A', in2: 'B' }, { kind: 'NOT', in1: 'C', in2: null }, { kind: 'AND', in1: 'g0', in2: 'g1' }],
  'f4-b7': [{ kind: 'XOR', in1: 'A', in2: 'B' }, { kind: 'NOT', in1: 'g0', in2: null }],
  'f5-s1-e3': [{ kind: 'NAND', in1: 'A', in2: 'B' }, { kind: 'NAND', in1: 'A', in2: 'g0' }, { kind: 'NAND', in1: 'B', in2: 'g0' }, { kind: 'NAND', in1: 'g1', in2: 'g2' }],
  'f5-s2-e3': [{ kind: 'XOR', in1: 'A', in2: 'B' }, { kind: 'XOR', in1: 'g0', in2: 'C' }],
  'f5-s2-e4': [{ kind: 'AND', in1: 'A', in2: 'B' }, { kind: 'XOR', in1: 'A', in2: 'B' }, { kind: 'AND', in1: 'g1', in2: 'C' }, { kind: 'OR', in1: 'g0', in2: 'g2' }],
  'f6-s2-e4': [{ kind: 'NOT', in1: 'L', in2: null }, { kind: 'AND', in1: 'Q', in2: 'g0' }, { kind: 'AND', in1: 'N', in2: 'L' }, { kind: 'OR', in1: 'g1', in2: 'g2' }],
  'f6-b6': [{ kind: 'NOT', in1: 'D', in2: null }, { kind: 'AND', in1: 'g0', in2: 'EN' }],
  'f7-b5': [{ kind: 'NAND', in1: 'A', in2: 'A' }, { kind: 'NAND', in1: 'B', in2: 'B' }, { kind: 'NAND', in1: 'g0', in2: 'g1' }],
};

// respostas esperadas de input (id -> resposta que um aluno digitaria)
const INPUT: Record<string, string> = {
  'f0-s2-e1': '8', 'f0-s2-e2': '4', 'f0-s2-e4': '256', 'f0-b2': '6', 'f0-b3': '32',
  'f1-s1-e1': '800', 'f1-s1-e2': '6', 'f1-s2-e1': '1000', 'f1-s2-e3': '63', 'f1-s4-e1': '22', 'f1-s4-e2': '15',
  'f1-b1': '154', 'f1-b2': '1011101', 'f1-b5': '9', 'f1-b6': '24',
  'f2-s1-e1': '24', 'f2-s1-e2': '65536', 'f2-s2-e1': 'f0', 'f2-s2-e2': '77', 'f2-s3-e1': '69', 'f2-s3-e2': '77', 'f2-s4-e1': '0080ff', 'f2-s4-e2': '30000',
  'f2-b1': '11000011', 'f2-b2': '195', 'f2-b3': '5e', 'f2-b5': '8192', 'f2-b6': 'Verde',
  'f3-s2-e3': '1101', 'f3-s2-e4': '1100', 'f3-b4': '1000', 'f3-b5': '1110', 'f3-b6': '0110',
  'f4-s1-e3': '6', 'f4-s4-e3': '5', 'f4-b5': '4',
  'f5-s3-e1': '1101', 'f5-s3-e2': '-16', 'f5-s3-e5': '0010', 'f5-s4-e1': '4', 'f5-b1': '10100001', 'f5-b2': '10011100', 'f5-b3': '-127',
  'f6-s2-e3': '32', 'f6-s3-e1': '4096', 'f6-s3-e2': '20', 'f6-b4': '65536',
  'f7-s1-e1': '00000101', 'f7-s1-e2': 'GUARDA 7', 'f7-s2-e1': '35', 'f7-s2-e2': '255', 'f7-s2-e3': '01000110', 'f7-s3-e2': '5', 'f7-s3-e3': '10000101',
  'f7-b1': '10', 'f7-b2': '217', 'f7-b3': 'D9', 'f7-b6': '11111001', 'f7-b9': '16', 'f7-b10': 'PULA 0',
};

// verificações matemáticas independentes de algumas respostas
const MATH: [string, boolean][] = [
  ['154 = 10011010', parseInt('10011010', 2) === 154],
  ['93 = 01011101', parseInt('01011101', 2) === 93],
  ['170 = 10101010', parseInt('10101010', 2) === 170],
  ['200 = 11001000', parseInt('11001000', 2) === 200],
  ['0x4D = 77', 0x4d === 77], ['0xC3 = 195', 0xc3 === 195], ['0x5E = 01011110', parseInt('01011110', 2) === 0x5e],
  ['-3 (4b) = 1101', toTwos(-3, 4) === '1101'], ['11110000 twos = -16', fromTwos('11110000') === -16],
  ['-100 = 10011100', toTwos(-100, 8) === '10011100'], ['10000001 = -127', fromTwos('10000001') === -127],
  ['-7 = 11111001', toTwos(-7, 8) === '11111001'], ['107+54=161=10100001', toBin(107 + 54, 8) === '10100001'],
  ['7-5 via twos', toBin((7 + parseInt(toTwos(-5, 4), 2)) % 16, 4) === '0010'],
  ['1011 xor 0110 = 1101', (0b1011 ^ 0b0110) === 0b1101], ['0110 xor 1010 = 1100', (0b0110 ^ 0b1010) === 0b1100],
  ['1100 and 1010 = 1000', (0b1100 & 0b1010) === 0b1000], ['1100 or 1010 = 1110', (0b1100 | 0b1010) === 0b1110],
  ['11011001 = 217 = D9', parseInt('11011001', 2) === 217 && (217).toString(16) === 'd9'],
  ['3-4 = 255 unsigned', ((3 - 4) + 256) % 256 === 255],
  ['250+10 mod 256 = 4', (250 + 10) % 256 === 4],
  ['120+10 signed = -126', fromTwos(toBin(130, 8)) === -126], ['-100-50 signed = 106', fromTwos(toTwos(-150, 8)) === 106],
  ['E = 69, M = 77', 'E'.charCodeAt(0) === 69 && 'M'.charCodeAt(0) === 77],
  ['ç UTF-8 = C3 A7', Array.from(new TextEncoder().encode('ç')).map((b) => b.toString(16)).join(' ') === 'c3 a7'],
];
for (const [m, v] of MATH) (v ? ok : fail)('math: ' + m);

const ids = new Set<string>();
const DEMOS = ['bit-switch', 'counter-4', 'counter-8', 'text-bits', 'color-bits', 'gates-basic', 'gates-all', 'gates-nand', 'adder-1', 'adder-8', 'twos', 'sr-latch', 'dff', 'mux', 'cpu', 'powers'];
let nEx = 0, nCircuit = 0, nWords = 0;
for (const p of PHASES) {
  const sections = [...p.sections.map((s) => ({ ...s, exercises: s.exercises })), { id: 'boss', title: p.boss.title, body: p.boss.intro, exercises: p.boss.exercises }];
  for (const s of sections) {
    nWords += s.body.split(/\s+/).length;
    for (const m of s.body.matchAll(/\[\[demo:([a-z0-9-]+)\]\]/g)) if (!DEMOS.includes(m[1])) fail(`demo desconhecida ${m[1]} em ${p.id}/${s.id}`);
    for (const ex of s.exercises) {
      nEx++;
      if (ids.has(ex.id)) fail('id duplicado ' + ex.id); ids.add(ex.id);
      if (!ex.id.startsWith(p.id + '-')) fail('id com prefixo errado ' + ex.id);
      if (ex.type === 'mc') {
        const n = ex.options.filter((o) => o.ok).length;
        if (n !== 1) fail(`mc ${ex.id} tem ${n} opções corretas`);
      }
      if (ex.type === 'input') {
        const exp = INPUT[ex.id];
        if (exp === undefined) fail(`input ${ex.id} sem resposta de teste`);
        else {
          const answers = (Array.isArray(ex.answer) ? ex.answer : [ex.answer]).map(normalizeAnswer);
          if (!answers.includes(normalizeAnswer(exp))) fail(`input ${ex.id}: "${exp}" não aceito (aceitos: ${answers.join('|')})`);
        }
      }
      if (ex.type === 'bits') {
        if (ex.target >= 2 ** ex.nbits) fail(`bits ${ex.id} alvo não cabe`);
      }
      if (ex.type === 'truth') {
        const rows = allCombos(ex.vars.length).map((v) => ex.fn(v));
        if (rows.every((r) => r === rows[0])) fail(`truth ${ex.id} é constante`);
      }
      if (ex.type === 'circuit') {
        nCircuit++;
        const sol = SOL[ex.id];
        if (!sol) { fail(`circuit ${ex.id} sem solução de teste`); continue; }
        if (sol.length > ex.maxGates) fail(`circuit ${ex.id}: solução usa ${sol.length} > max ${ex.maxGates}`);
        if (sol.some((g) => !ex.allowed.includes(g.kind))) fail(`circuit ${ex.id}: solução usa porta não permitida`);
        const bad = allCombos(ex.inputs.length).filter((v) => { const o = evalCircuit(ex.inputs, sol, v); return o[o.length - 1] !== ex.target(v); });
        if (bad.length) fail(`circuit ${ex.id}: solução falha em ${bad.length} linhas`);
      }
      if (ex.type === 'explain') {
        const low = ex.model.toLowerCase();
        const hit = ex.keywords.filter((g) => g.some((k) => low.includes(k.toLowerCase()))).length;
        const need = ex.minGroups ?? Math.ceil(ex.keywords.length * 0.6);
        if (hit < need) fail(`explain ${ex.id}: a resposta-modelo só atinge ${hit}/${need} grupos`);
      }
    }
  }
  for (const c of p.review) { if (ids.has(c.id)) fail('id duplicado ' + c.id); ids.add(c.id); }
}
// geradores: 200 amostras de cada, conferindo consistência interna via conversões
const kinds = ['dec2bin', 'bin2dec', 'hex2dec', 'bin2hex', 'dec2hex', 'twos', 'addbin'];
ok(`geradores definidos: ${kinds.join(', ')} (a lógica usa toBin/toTwos verificadas acima)`);

const sec = PHASES.reduce((a, p) => a + p.sections.length, 0);
console.log(`\nFases: ${PHASES.length} · Seções: ${sec} · Exercícios: ${nEx} (circuitos: ${nCircuit}) · Fichas de revisão: ${PHASES.reduce((a, p) => a + p.review.length, 0)} · Glossário: ${PHASES.reduce((a, p) => a + p.glossary.length, 0)} termos · ~${nWords} palavras de lição`);
console.log(fails === 0 ? '\n✅ TUDO PASSOU' : `\n❌ ${fails} falha(s)`);
process.exit(fails ? 1 : 0);
