// Progresso salvo no navegador (localStorage), com exportação/importação em JSON.

export interface ExerciseStat {
  attempts: number;
  errors: number;
  done: boolean;
}

export interface SrsState {
  box: number; // 0..5
  due: number; // timestamp ms
  seen: number;
  lapses: number;
}

export interface Progress {
  version: number;
  name: string;
  createdAt: number;
  unlockedPhase: number; // maior fase desbloqueada
  completedSections: Record<string, boolean>; // key: phaseId/sectionId
  bossPassed: Record<string, boolean>;
  bossAttempts: Record<string, number>;
  exercises: Record<string, ExerciseStat>; // key: exerciseId
  srs: Record<string, SrsState>; // key: cardId
  xp: number;
  lastPhase: string | null;
  lastSection: Record<string, number>; // phaseId -> índice da seção
  notes: Record<string, string>; // respostas "explique com suas palavras"
  log: { t: number; what: string }[];
}

const KEY = 'bits-zero-progress-v1';

export const INTERVALS_DAYS = [0, 1, 3, 7, 14, 30];

export function fresh(): Progress {
  return {
    version: 1,
    name: '',
    createdAt: Date.now(),
    unlockedPhase: 0,
    completedSections: {},
    bossPassed: {},
    bossAttempts: {},
    exercises: {},
    srs: {},
    xp: 0,
    lastPhase: null,
    lastSection: {},
    notes: {},
    log: [],
  };
}

export function load(): Progress {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return fresh();
    const p = JSON.parse(raw) as Progress;
    return { ...fresh(), ...p };
  } catch {
    return fresh();
  }
}

export function save(p: Progress) {
  localStorage.setItem(KEY, JSON.stringify(p));
}

export function exportJson(p: Progress): string {
  return JSON.stringify(p, null, 2);
}

export function importJson(s: string): Progress | null {
  try {
    const p = JSON.parse(s);
    if (typeof p !== 'object' || !p.exercises) return null;
    return { ...fresh(), ...p };
  } catch {
    return null;
  }
}

export function recordAttempt(p: Progress, id: string, correct: boolean): Progress {
  const st = p.exercises[id] ?? { attempts: 0, errors: 0, done: false };
  const next = {
    attempts: st.attempts + 1,
    errors: st.errors + (correct ? 0 : 1),
    done: st.done || correct,
  };
  return {
    ...p,
    exercises: { ...p.exercises, [id]: next },
    xp: p.xp + (correct && !st.done ? 10 : 0),
  };
}

// Repetição espaçada simples (sistema de caixas de Leitner com intervalos crescentes).
export function scheduleCard(p: Progress, cardId: string, remembered: boolean): Progress {
  const cur = p.srs[cardId] ?? { box: 0, due: Date.now(), seen: 0, lapses: 0 };
  const box = remembered ? Math.min(cur.box + 1, INTERVALS_DAYS.length - 1) : 0;
  const days = INTERVALS_DAYS[box];
  const due = Date.now() + days * 24 * 60 * 60 * 1000 + (remembered ? 0 : 10 * 60 * 1000);
  return {
    ...p,
    srs: {
      ...p.srs,
      [cardId]: { box, due, seen: cur.seen + 1, lapses: cur.lapses + (remembered ? 0 : 1) },
    },
    xp: p.xp + (remembered ? 2 : 0),
  };
}

export function activateCards(p: Progress, ids: string[]): Progress {
  const srs = { ...p.srs };
  for (const id of ids) {
    if (!srs[id]) srs[id] = { box: 0, due: Date.now() + 12 * 60 * 60 * 1000, seen: 0, lapses: 0 };
  }
  return { ...p, srs };
}

export function dueCards(p: Progress): string[] {
  const now = Date.now();
  return Object.entries(p.srs)
    .filter(([, s]) => s.due <= now)
    .map(([id]) => id);
}

// Nível de dificuldade adaptativa (0 = fácil, 1 = médio, 2 = difícil), baseado na taxa de erro recente
export function difficultyFor(p: Progress, prefix: string): number {
  const stats = Object.entries(p.exercises).filter(([id]) => id.startsWith(prefix));
  if (stats.length < 3) return 0;
  const attempts = stats.reduce((a, [, s]) => a + s.attempts, 0);
  const errors = stats.reduce((a, [, s]) => a + s.errors, 0);
  const rate = errors / Math.max(1, attempts);
  if (rate > 0.4) return 0;
  if (rate > 0.2) return 1;
  return 2;
}

export function weakSpots(p: Progress): { id: string; rate: number; errors: number }[] {
  return Object.entries(p.exercises)
    .map(([id, s]) => ({ id, rate: s.errors / Math.max(1, s.attempts), errors: s.errors }))
    .filter((x) => x.errors >= 2)
    .sort((a, b) => b.rate - a.rate)
    .slice(0, 8);
}
