export type GateKind = 'NOT' | 'AND' | 'OR' | 'NAND' | 'NOR' | 'XOR';

export interface McOption {
  t: string;
  ok?: boolean;
  fb: string; // feedback específico para essa opção
}

export type Exercise =
  | {
      type: 'mc';
      id: string;
      q: string;
      options: McOption[];
      explain: string; // explicação exibida após acertar
    }
  | {
      type: 'input';
      id: string;
      q: string;
      answer: string | string[];
      hints: string[]; // dicas progressivas, uma por erro
      explain: string;
      placeholder?: string;
    }
  | {
      type: 'bits';
      id: string;
      q: string;
      nbits: number;
      target: number;
      explain: string;
      hints: string[];
    }
  | {
      type: 'truth';
      id: string;
      q: string;
      vars: string[];
      label: string;
      fn: (v: boolean[]) => boolean;
      explain: string;
    }
  | {
      type: 'circuit';
      id: string;
      q: string;
      inputs: string[];
      target: (v: boolean[]) => boolean;
      allowed: GateKind[];
      maxGates: number;
      explain: string;
      hints: string[];
    }
  | {
      type: 'explain';
      id: string;
      q: string;
      keywords: string[][]; // cada grupo = sinônimos; precisa de pelo menos 1 de cada grupo (ou maioria)
      model: string; // resposta-modelo
      minGroups?: number;
    }
  | {
      type: 'gen';
      id: string;
      kind: 'dec2bin' | 'bin2dec' | 'hex2dec' | 'bin2hex' | 'dec2hex' | 'twos' | 'addbin';
      q: string;
      explain: string;
      count: number; // quantos acertos seguidos exigidos
    };

export interface ReviewCard {
  id: string;
  q: string;
  a: string;
  answer?: string | string[]; // se existir, usuário digita e o jogo verifica
}

export interface GlossaryEntry {
  pt: string;
  en: string;
  def: string;
  origin?: string;
}

export interface Section {
  id: string;
  title: string;
  body: string;
  exercises: Exercise[];
}

export interface Phase {
  id: string;
  num: number;
  title: string;
  subtitle: string;
  emoji: string;
  goal: string;
  sections: Section[];
  boss: { title: string; intro: string; exercises: Exercise[]; passRatio: number };
  review: ReviewCard[];
  glossary: GlossaryEntry[];
}
