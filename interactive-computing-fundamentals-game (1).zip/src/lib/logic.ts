import type { GateKind } from './types';

export const GATE_INFO: Record<GateKind, { arity: 1 | 2; pt: string; fn: (a: boolean, b?: boolean) => boolean; symbol: string }> = {
  NOT: { arity: 1, pt: 'NÃO', fn: (a) => !a, symbol: '¬' },
  AND: { arity: 2, pt: 'E', fn: (a, b) => a && !!b, symbol: '∧' },
  OR: { arity: 2, pt: 'OU', fn: (a, b) => a || !!b, symbol: '∨' },
  NAND: { arity: 2, pt: 'NÃO-E', fn: (a, b) => !(a && !!b), symbol: '⊼' },
  NOR: { arity: 2, pt: 'NÃO-OU', fn: (a, b) => !(a || !!b), symbol: '⊽' },
  XOR: { arity: 2, pt: 'OU-exclusivo', fn: (a, b) => a !== !!b, symbol: '⊕' },
};

export interface GateNode {
  kind: GateKind;
  in1: string; // id de entrada ('A','B',...) ou 'g0','g1'...
  in2: string | null;
}

// Avalia um circuito (lista ordenada de portas) para uma atribuição de entradas.
export function evalCircuit(inputs: string[], gates: GateNode[], values: boolean[]): boolean[] {
  const env: Record<string, boolean> = {};
  inputs.forEach((n, i) => (env[n] = values[i]));
  const outs: boolean[] = [];
  gates.forEach((g, i) => {
    const a = env[g.in1] ?? false;
    const b = g.in2 ? env[g.in2] ?? false : undefined;
    const v = GATE_INFO[g.kind].fn(a, b);
    env['g' + i] = v;
    outs.push(v);
  });
  return outs;
}

export function allCombos(n: number): boolean[][] {
  const res: boolean[][] = [];
  for (let i = 0; i < 1 << n; i++) {
    const row: boolean[] = [];
    for (let j = n - 1; j >= 0; j--) row.push(((i >> j) & 1) === 1);
    res.push(row);
  }
  return res;
}

export function toBin(n: number, bits: number): string {
  return (n >>> 0).toString(2).padStart(bits, '0').slice(-bits);
}

export function toTwos(n: number, bits: number): string {
  const mod = 1 << bits;
  return toBin(((n % mod) + mod) % mod, bits);
}

export function fromTwos(s: string): number {
  const bits = s.length;
  const v = parseInt(s, 2);
  return s[0] === '1' ? v - (1 << bits) : v;
}

export function normalizeAnswer(s: string): string {
  return s.trim().toLowerCase().replace(/\s+/g, ' ').replace(/,/g, '.').replace(/^0b/, '').replace(/^0x/, '');
}
