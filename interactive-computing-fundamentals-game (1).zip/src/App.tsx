import { useEffect, useState } from 'react';
import { load, save, type Progress } from './lib/storage';
import { phaseById } from './content';
import { Home, Review, Glossary, DataScreen, Guide } from './components/Screens';
import { PhaseView } from './components/PhaseView';

export default function App() {
  const [progress, setProgressState] = useState<Progress>(() => load());
  const [screen, setScreen] = useState<string>('home');

  const setProgress = (p: Progress) => { setProgressState(p); save(p); };
  useEffect(() => { save(progress); }, [progress]);

  const go = (s: string) => { setScreen(s); window.scrollTo({ top: 0 }); };

  let body: React.ReactNode;
  if (screen.startsWith('phase:')) {
    const phase = phaseById(screen.slice(6));
    body = phase ? (
      <PhaseView key={phase.id} phase={phase} progress={progress} setProgress={setProgress} onExit={() => go('home')} onPhaseComplete={() => go('home')} />
    ) : <Home progress={progress} setProgress={setProgress} go={go} />;
  } else if (screen === 'review') body = <Review progress={progress} setProgress={setProgress} back={() => go('home')} />;
  else if (screen === 'glossary') body = <Glossary progress={progress} back={() => go('home')} />;
  else if (screen === 'data') body = <DataScreen progress={progress} setProgress={setProgress} back={() => go('home')} />;
  else if (screen === 'guide') body = <Guide back={() => go('home')} />;
  else body = <Home progress={progress} setProgress={setProgress} go={go} />;

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_#0f2a3f_0%,_#0b1220_45%,_#070b14_100%)] text-slate-100">
      <nav className="sticky top-0 z-20 border-b border-slate-800/80 bg-slate-950/80 backdrop-blur">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-4 py-2 text-sm">
          <button onClick={() => go('home')} className="font-black tracking-tight text-white">💡 BITS <span className="font-normal text-slate-400">· a fundação de tudo</span></button>
          <div className="flex items-center gap-3 text-slate-300">
            {progress.name && <span className="hidden sm:inline">Olá, {progress.name}</span>}
            <span className="rounded-full bg-amber-400/20 px-2 py-0.5 font-mono text-amber-200">{progress.xp} XP</span>
            <button onClick={() => go('review')} className="hover:text-white">🔁</button>
            <button onClick={() => go('glossary')} className="hover:text-white">📖</button>
          </div>
        </div>
      </nav>
      {body}
    </div>
  );
}
