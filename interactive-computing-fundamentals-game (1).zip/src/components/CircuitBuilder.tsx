import { useMemo, useState } from 'react';
import { GATE_INFO, allCombos, evalCircuit, type GateNode } from '../lib/logic';
import type { GateKind } from '../lib/types';

interface Props {
  inputs: string[];
  target: (v: boolean[]) => boolean;
  allowed: GateKind[];
  maxGates: number;
  onResult: (ok: boolean, mismatches: number) => void;
}

export function CircuitBuilder({ inputs, target, allowed, maxGates, onResult }: Props) {
  const [gates, setGates] = useState<GateNode[]>([]);
  const [checked, setChecked] = useState<null | { ok: boolean; rows: { v: boolean[]; got: boolean; want: boolean }[] }>(null);

  const sources = (idx: number) => [...inputs, ...gates.slice(0, idx).map((_, i) => 'g' + i)];
  const combos = useMemo(() => allCombos(inputs.length), [inputs.length]);

  const add = (kind: GateKind) => {
    if (gates.length >= maxGates) return;
    const src = sources(gates.length);
    setGates([...gates, { kind, in1: src[0], in2: GATE_INFO[kind].arity === 2 ? src[Math.min(1, src.length - 1)] : null }]);
    setChecked(null);
  };
  const update = (i: number, patch: Partial<GateNode>) => { setGates(gates.map((g, j) => (j === i ? { ...g, ...patch } : g))); setChecked(null); };
  const remove = (i: number) => {
    // remove e corrige referências posteriores que apontavam para essa porta
    const next = gates.filter((_, j) => j !== i).map((g, j) => {
      const fix = (ref: string | null) => {
        if (!ref || !ref.startsWith('g')) return ref;
        const n = +ref.slice(1);
        if (n === i) return inputs[0];
        if (n > i) return 'g' + (n - 1);
        return ref;
      };
      const srcs = [...inputs, ...Array.from({ length: j }, (_, k) => 'g' + k)];
      const in1 = fix(g.in1)!; const in2 = fix(g.in2);
      return { ...g, in1: srcs.includes(in1) ? in1 : inputs[0], in2: in2 && !srcs.includes(in2) ? inputs[0] : in2 };
    });
    setGates(next); setChecked(null);
  };

  const check = () => {
    if (gates.length === 0) return;
    const rows = combos.map((v) => {
      const outs = evalCircuit(inputs, gates, v);
      return { v, got: outs[outs.length - 1], want: target(v) };
    });
    const mism = rows.filter((r) => r.got !== r.want).length;
    setChecked({ ok: mism === 0, rows });
    onResult(mism === 0, mism);
  };

  const name = (ref: string) => (ref.startsWith('g') ? `saída da porta ${+ref.slice(1) + 1}` : `entrada ${ref}`);

  return (
    <div className="rounded-xl border border-slate-600 bg-slate-900/60 p-4">
      <div className="mb-3 text-sm text-slate-300">Monte o circuito adicionando portas. A <strong className="text-white">última porta</strong> da lista é a saída final. Portas: no máximo {maxGates}.</div>
      <div className="mb-3 flex flex-wrap gap-2">
        {allowed.map((k) => <button type="button" key={k} onClick={() => add(k)} disabled={gates.length >= maxGates} className="rounded-lg bg-cyan-700 px-3 py-1.5 font-mono text-sm font-bold text-white hover:bg-cyan-600 disabled:opacity-40">+ {k} <span className="font-normal opacity-70">({GATE_INFO[k].pt})</span></button>)}
      </div>
      <div className="space-y-2">
        {gates.length === 0 && <div className="rounded-lg border border-dashed border-slate-600 p-4 text-center text-sm text-slate-500">Nenhuma porta ainda. Clique em uma acima.</div>}
        {gates.map((g, i) => {
          const src = sources(i);
          return (
            <div key={i} className={`flex flex-wrap items-center gap-2 rounded-lg px-3 py-2 font-mono text-sm ${i === gates.length - 1 ? 'border border-amber-400/60 bg-amber-400/10' : 'bg-slate-800'}`}>
              <span className="w-16 text-slate-400">porta {i + 1}</span>
              <span className="font-bold text-cyan-200">{g.kind}</span>
              <span className="text-slate-400">recebe</span>
              <select value={g.in1} onChange={(e) => update(i, { in1: e.target.value })} className="rounded border border-slate-600 bg-slate-900 px-2 py-1 text-white">{src.map((s) => <option key={s} value={s}>{name(s)}</option>)}</select>
              {GATE_INFO[g.kind].arity === 2 && <>
                <span className="text-slate-400">e</span>
                <select value={g.in2 ?? ''} onChange={(e) => update(i, { in2: e.target.value })} className="rounded border border-slate-600 bg-slate-900 px-2 py-1 text-white">{src.map((s) => <option key={s} value={s}>{name(s)}</option>)}</select>
              </>}
              {i === gates.length - 1 && <span className="ml-auto text-xs font-bold text-amber-300">← SAÍDA</span>}
              <button type="button" onClick={() => remove(i)} className="rounded px-2 text-rose-300 hover:bg-rose-500/20">✕</button>
            </div>
          );
        })}
      </div>
      <div className="mt-3 flex gap-2">
        <button type="button" onClick={check} disabled={gates.length === 0} className="rounded-lg bg-emerald-600 px-4 py-2 font-bold text-white hover:bg-emerald-500 disabled:opacity-40">Testar todas as combinações</button>
        <button type="button" onClick={() => { setGates([]); setChecked(null); }} className="rounded-lg bg-slate-700 px-4 py-2 text-white">limpar</button>
      </div>
      {checked && (
        <div className="mt-3">
          <table className="border-collapse font-mono text-sm">
            <thead><tr>{inputs.map((n) => <th key={n} className="border border-slate-600 px-3 py-1 text-amber-200">{n}</th>)}<th className="border border-slate-600 px-3 py-1 text-amber-200">seu circuito</th><th className="border border-slate-600 px-3 py-1 text-amber-200">esperado</th></tr></thead>
            <tbody>{checked.rows.map((r, i) => <tr key={i} className={r.got === r.want ? '' : 'bg-rose-500/20'}>{r.v.map((b, j) => <td key={j} className="border border-slate-700 px-3 py-1 text-center">{b ? 1 : 0}</td>)}<td className="border border-slate-700 px-3 py-1 text-center font-bold">{r.got ? 1 : 0}</td><td className="border border-slate-700 px-3 py-1 text-center">{r.want ? 1 : 0}</td><td className="px-2">{r.got === r.want ? '✅' : '❌'}</td></tr>)}</tbody>
          </table>
        </div>
      )}
    </div>
  );
}
