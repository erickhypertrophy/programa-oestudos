import { useMemo, useState } from 'react';
import type { Exercise } from '../lib/types';
import { Markdown } from './Markdown';
import { BitButton } from './Demos';
import { CircuitBuilder } from './CircuitBuilder';
import { allCombos, normalizeAnswer, toBin, toTwos } from '../lib/logic';

interface Props {
  ex: Exercise;
  difficulty: number; // 0..2
  onAttempt: (correct: boolean) => void;
  onDone: () => void;
  done: boolean;
  saveNote?: (txt: string) => void;
  savedNote?: string;
}

function Frame({ children, title, done }: { children: React.ReactNode; title: string; done: boolean }) {
  return (
    <div className={`my-6 rounded-2xl border p-5 ${done ? 'border-emerald-500/50 bg-emerald-950/20' : 'border-amber-500/40 bg-slate-900/70'}`}>
      <div className="mb-3 flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-300">{done ? '✅ concluído' : '✏️ ' + title}</div>
      {children}
    </div>
  );
}

function Feedback({ kind, text }: { kind: 'ok' | 'bad' | 'hint'; text: string }) {
  const cls = kind === 'ok' ? 'border-emerald-400/60 bg-emerald-500/10' : kind === 'bad' ? 'border-rose-400/60 bg-rose-500/10' : 'border-sky-400/60 bg-sky-500/10';
  return <div className={`mt-3 rounded-xl border px-4 py-3 text-sm ${cls}`}><Markdown text={text} /></div>;
}

export function ExerciseView(props: Props) {
  const { ex } = props;
  switch (ex.type) {
    case 'mc': return <Mc {...props} />;
    case 'input': return <Input {...props} />;
    case 'bits': return <Bits {...props} />;
    case 'truth': return <Truth {...props} />;
    case 'circuit': return <Circuit {...props} />;
    case 'explain': return <Explain {...props} />;
    case 'gen': return <Gen {...props} />;
  }
}

function Mc({ ex, onAttempt, onDone, done }: Props) {
  if (ex.type !== 'mc') return null;
  const [picked, setPicked] = useState<number | null>(null);
  const [solved, setSolved] = useState(done);
  const [wrongs, setWrongs] = useState<number[]>([]);
  const order = useMemo(() => ex.options.map((_, i) => i), [ex.id]); // eslint-disable-line react-hooks/exhaustive-deps
  const pick = (i: number) => {
    if (solved) return;
    setPicked(i);
    const ok = !!ex.options[i].ok;
    onAttempt(ok);
    if (ok) { setSolved(true); onDone(); } else setWrongs((w) => [...w, i]);
  };
  return (
    <Frame title="Escolha" done={solved}>
      <Markdown text={ex.q} />
      <div className="mt-3 space-y-2">
        {order.map((i) => {
          const o = ex.options[i];
          const isWrong = wrongs.includes(i);
          const isRight = solved && o.ok;
          return (
            <button type="button" key={i} onClick={() => pick(i)} disabled={solved || isWrong} className={`block w-full rounded-xl border px-4 py-3 text-left transition ${isRight ? 'border-emerald-400 bg-emerald-500/20 text-white' : isWrong ? 'border-rose-400/60 bg-rose-500/10 text-slate-400 line-through' : 'border-slate-600 bg-slate-800 text-slate-100 hover:border-amber-400'}`}>
              <span className="mr-2 font-mono text-amber-300">{String.fromCharCode(65 + i)}.</span>{o.t}
            </button>
          );
        })}
      </div>
      {picked !== null && !solved && <Feedback kind="bad" text={'**Ainda não.** ' + ex.options[picked].fb} />}
      {solved && <Feedback kind="ok" text={'**Isso!** ' + (picked !== null ? ex.options[picked].fb + ' ' : '') + ex.explain} />}
    </Frame>
  );
}

function Input({ ex, onAttempt, onDone, done }: Props) {
  if (ex.type !== 'input') return null;
  const [val, setVal] = useState('');
  const [solved, setSolved] = useState(done);
  const [tries, setTries] = useState(0);
  const [msg, setMsg] = useState<string | null>(null);
  const answers = (Array.isArray(ex.answer) ? ex.answer : [ex.answer]).map(normalizeAnswer);
  const submit = () => {
    if (solved || !val.trim()) return;
    const ok = answers.includes(normalizeAnswer(val));
    onAttempt(ok);
    if (ok) { setSolved(true); setMsg(null); onDone(); return; }
    const t = tries + 1; setTries(t);
    const hint = ex.hints[Math.min(t - 1, ex.hints.length - 1)];
    setMsg(hint ? `Não é \`${val}\`. **Dica ${t}:** ${hint}` : `Não é \`${val}\`. Tente de novo pensando passo a passo.`);
  };
  return (
    <Frame title="Responda" done={solved}>
      <Markdown text={ex.q} />
      <div className="mt-3 flex gap-2">
        <input value={val} onChange={(e) => setVal(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && submit()} disabled={solved} placeholder={ex.placeholder ?? 'sua resposta'} className="flex-1 rounded-lg border border-slate-600 bg-slate-800 px-3 py-2 font-mono text-white disabled:opacity-60" />
        <button type="button" onClick={submit} disabled={solved} className="rounded-lg bg-amber-500 px-4 py-2 font-bold text-slate-900 hover:bg-amber-400 disabled:opacity-40">Verificar</button>
      </div>
      {msg && !solved && <Feedback kind="hint" text={msg} />}
      {solved && <Feedback kind="ok" text={'**Correto!** ' + ex.explain} />}
    </Frame>
  );
}

function Bits({ ex, onAttempt, onDone, done }: Props) {
  if (ex.type !== 'bits') return null;
  const [bits, setBits] = useState<boolean[]>(Array(ex.nbits).fill(false));
  const [solved, setSolved] = useState(done);
  const [tries, setTries] = useState(0);
  const [msg, setMsg] = useState<string | null>(null);
  const value = bits.reduce((a, b, i) => a + (b ? 2 ** (ex.nbits - 1 - i) : 0), 0);
  const check = () => {
    if (solved) return;
    const ok = value === ex.target;
    onAttempt(ok);
    if (ok) { setSolved(true); onDone(); setMsg(null); return; }
    const t = tries + 1; setTries(t);
    const dir = value > ex.target ? 'Seu valor está **maior** que o alvo.' : 'Seu valor está **menor** que o alvo.';
    const hint = ex.hints[Math.min(t - 1, ex.hints.length - 1)] ?? '';
    setMsg(`Você montou ${value}. ${dir} ${hint}`);
  };
  return (
    <Frame title="Monte com bits" done={solved}>
      <Markdown text={ex.q} />
      <div className="mt-3 flex flex-wrap items-end gap-2">
        {bits.map((b, i) => <BitButton key={i} on={b} onClick={() => !solved && setBits(bits.map((x, j) => (j === i ? !x : x)))} label={String(2 ** (ex.nbits - 1 - i))} />)}
      </div>
      <div className="mt-3 flex items-center gap-4">
        <span className="font-mono text-slate-300">valor atual: <span className="text-xl font-bold text-white">{value}</span></span>
        <button type="button" onClick={check} disabled={solved} className="rounded-lg bg-amber-500 px-4 py-2 font-bold text-slate-900 hover:bg-amber-400 disabled:opacity-40">Verificar</button>
      </div>
      {msg && !solved && <Feedback kind="hint" text={msg} />}
      {solved && <Feedback kind="ok" text={'**Perfeito!** ' + ex.explain} />}
    </Frame>
  );
}

function Truth({ ex, onAttempt, onDone, done }: Props) {
  if (ex.type !== 'truth') return null;
  const combos = useMemo(() => allCombos(ex.vars.length), [ex.vars.length]);
  const [ans, setAns] = useState<(boolean | null)[]>(Array(combos.length).fill(null));
  const [solved, setSolved] = useState(done);
  const [wrongRows, setWrongRows] = useState<number[]>([]);
  const check = () => {
    if (ans.some((a) => a === null)) { setWrongRows([-1]); return; }
    const wrong = combos.map((c, i) => (ex.fn(c) === ans[i] ? -1 : i)).filter((i) => i >= 0);
    const ok = wrong.length === 0;
    onAttempt(ok);
    setWrongRows(wrong);
    if (ok) { setSolved(true); onDone(); }
  };
  return (
    <Frame title="Preencha a tabela-verdade" done={solved}>
      <Markdown text={ex.q} />
      <table className="mt-3 border-collapse font-mono text-sm">
        <thead><tr>{ex.vars.map((v) => <th key={v} className="border border-slate-600 px-4 py-1 text-amber-200">{v}</th>)}<th className="border border-slate-600 px-4 py-1 text-amber-200">{ex.label}</th></tr></thead>
        <tbody>
          {combos.map((c, i) => (
            <tr key={i} className={wrongRows.includes(i) ? 'bg-rose-500/20' : ''}>
              {c.map((b, j) => <td key={j} className="border border-slate-700 px-4 py-1 text-center">{b ? 1 : 0}</td>)}
              <td className="border border-slate-700 px-2 py-1">
                <div className="flex gap-1">
                  {[false, true].map((v) => <button type="button" key={String(v)} disabled={solved} onClick={() => { setAns(ans.map((a, k) => (k === i ? v : a))); setWrongRows([]); }} className={`h-8 w-8 rounded font-bold ${ans[i] === v ? 'bg-amber-400 text-slate-900' : 'bg-slate-700 text-slate-300 hover:bg-slate-600'}`}>{v ? 1 : 0}</button>)}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button type="button" onClick={check} disabled={solved} className="mt-3 rounded-lg bg-amber-500 px-4 py-2 font-bold text-slate-900 hover:bg-amber-400 disabled:opacity-40">Verificar</button>
      {wrongRows.length > 0 && wrongRows[0] === -1 && <Feedback kind="hint" text="Preencha todas as linhas antes de verificar." />}
      {wrongRows.length > 0 && wrongRows[0] !== -1 && !solved && <Feedback kind="bad" text={`${wrongRows.length} linha(s) em vermelho estão erradas. Para cada uma, releia a definição da operação e pergunte: com essas entradas exatas, qual é a saída? Não chute: raciocine linha por linha.`} />}
      {solved && <Feedback kind="ok" text={'**Tabela correta!** ' + ex.explain} />}
    </Frame>
  );
}

function Circuit({ ex, onAttempt, onDone, done }: Props) {
  if (ex.type !== 'circuit') return null;
  const [solved, setSolved] = useState(done);
  const [tries, setTries] = useState(0);
  const [msg, setMsg] = useState<string | null>(null);
  return (
    <Frame title="Construa o circuito" done={solved}>
      <Markdown text={ex.q} />
      <div className="mt-3">
        <CircuitBuilder inputs={ex.inputs} target={ex.target} allowed={ex.allowed} maxGates={ex.maxGates} onResult={(ok, mism) => {
          if (solved) return;
          onAttempt(ok);
          if (ok) { setSolved(true); onDone(); setMsg(null); }
          else { const t = tries + 1; setTries(t); setMsg(`${mism} linha(s) diferentes do esperado (em vermelho). **Dica ${t}:** ${ex.hints[Math.min(t - 1, ex.hints.length - 1)]}`); }
        }} />
      </div>
      {msg && !solved && <Feedback kind="hint" text={msg} />}
      {solved && <Feedback kind="ok" text={'**Circuito funciona em todas as combinações!** ' + ex.explain} />}
    </Frame>
  );
}

function Explain({ ex, onAttempt, onDone, done, saveNote, savedNote }: Props) {
  if (ex.type !== 'explain') return null;
  const [txt, setTxt] = useState(savedNote ?? '');
  const [solved, setSolved] = useState(done);
  const [result, setResult] = useState<{ hit: string[]; miss: string[] } | null>(null);
  const check = () => {
    const low = txt.toLowerCase();
    const hit: string[] = []; const miss: string[] = [];
    ex.keywords.forEach((grp) => (grp.some((k) => low.includes(k.toLowerCase())) ? hit : miss).push(grp[0]));
    const need = ex.minGroups ?? Math.ceil(ex.keywords.length * 0.6);
    const ok = txt.trim().split(/\s+/).length >= 12 && hit.length >= need;
    setResult({ hit, miss });
    onAttempt(ok);
    saveNote?.(txt);
    if (ok) { setSolved(true); onDone(); }
  };
  return (
    <Frame title="Explique com suas palavras" done={solved}>
      <Markdown text={ex.q} />
      <textarea value={txt} onChange={(e) => setTxt(e.target.value)} disabled={solved} rows={4} placeholder="Escreva como se estivesse explicando para um amigo que nunca ouviu falar disso. Mínimo ~12 palavras." className="mt-3 w-full rounded-lg border border-slate-600 bg-slate-800 px-3 py-2 text-white disabled:opacity-60" />
      <button type="button" onClick={check} disabled={solved || txt.trim().length < 5} className="mt-2 rounded-lg bg-amber-500 px-4 py-2 font-bold text-slate-900 hover:bg-amber-400 disabled:opacity-40">Avaliar minha explicação</button>
      {result && !solved && <Feedback kind="hint" text={`Sua explicação ainda não toca em ideias essenciais. Ela menciona: ${result.hit.length ? result.hit.join(', ') : 'nenhuma das ideias-chave'}. Faltou falar sobre: **${result.miss.join(', ')}**. Releia o trecho acima e tente incluir essas ideias (com suas palavras; a verificação procura os conceitos, não frases decoradas).`} />}
      {solved && <Feedback kind="ok" text={`**Boa explicação** (você tocou em: ${result?.hit.join(', ') ?? 'tudo'}). Compare com uma resposta-modelo — não para decorar, mas para ver se falta alguma nuance:\n\n> ${ex.model}`} />}
    </Frame>
  );
}

// Exercícios gerados aleatoriamente, com dificuldade adaptativa.
export function makeGen(kind: string, difficulty: number): { prompt: string; answer: string[]; solution: string } {
  const r = (n: number) => Math.floor(Math.random() * n);
  const bits = difficulty === 0 ? 4 : difficulty === 1 ? 6 : 8;
  switch (kind) {
    case 'dec2bin': { const n = r(2 ** bits); const b = toBin(n, bits); return { prompt: `Converta **${n}** (decimal) para binário.`, answer: [b, b.replace(/^0+(?=\d)/, '')], solution: `Pesos de ${2 ** (bits - 1)} até 1: ${b.split('').map((d, i) => (d === '1' ? 2 ** (bits - 1 - i) : null)).filter((x) => x !== null).join(' + ') || '0'} = ${n}, logo **${b}**.` }; }
    case 'bin2dec': { const n = r(2 ** bits); const b = toBin(n, bits); return { prompt: `Converta **${b}** (binário) para decimal.`, answer: [String(n)], solution: `${b.split('').map((d, i) => (d === '1' ? 2 ** (bits - 1 - i) : null)).filter((x) => x !== null).join(' + ') || '0'} = **${n}**.` }; }
    case 'hex2dec': { const n = r(difficulty === 0 ? 16 : 256); return { prompt: `Converta **${n.toString(16).toUpperCase()}** (hexadecimal) para decimal.`, answer: [String(n)], solution: n < 16 ? `Um dígito só: **${n}**.` : `${Math.floor(n / 16)}×16 + ${n % 16} = **${n}**.` }; }
    case 'bin2hex': { const n = r(256); const b = toBin(n, 8); const h = n.toString(16).toUpperCase().padStart(2, '0'); return { prompt: `Converta **${b}** (binário, 8 bits) para hexadecimal (2 dígitos).`, answer: [h, h.toLowerCase(), h.replace(/^0/, ''), h.toLowerCase().replace(/^0/, '')], solution: `Separe em grupos de 4: ${b.slice(0, 4)} | ${b.slice(4)} → ${h[0]} | ${h[1]} = **${h}**.` }; }
    case 'dec2hex': { const n = r(256); const h = n.toString(16).toUpperCase(); return { prompt: `Converta **${n}** (decimal) para hexadecimal.`, answer: [h, h.toLowerCase(), h.padStart(2, '0'), h.toLowerCase().padStart(2, '0')], solution: `${n} ÷ 16 = ${Math.floor(n / 16)} resto ${n % 16} → **${h}**.` }; }
    case 'twos': { const n = r(256) - 128; const b = toTwos(n, 8); return { prompt: `Escreva **${n}** em complemento de dois com 8 bits.`, answer: [b], solution: n >= 0 ? `Positivo: binário normal com 8 bits → **${b}**.` : `Pegue ${-n} = ${toBin(-n, 8)}, inverta todos os bits = ${toBin(255 + n, 8)}, some 1 → **${b}**. (Conferindo: -128×${b[0]} + ${b.slice(1).split('').map((d, i) => (d === '1' ? 2 ** (6 - i) : null)).filter((x) => x !== null).join(' + ') || '0'} = ${n}.)` }; }
    case 'addbin': { const x = r(2 ** (bits - 1)); const y = r(2 ** (bits - 1)); const s = toBin(x + y, bits); return { prompt: `Some em binário: **${toBin(x, bits)} + ${toBin(y, bits)}** (responda com ${bits} bits).`, answer: [s, s.replace(/^0+(?=\d)/, '')], solution: `${x} + ${y} = ${x + y} → **${s}**. Coluna por coluna da direita para a esquerda, lembrando que 1+1 = 0 e vai um.` }; }
  }
  return { prompt: '?', answer: [''], solution: '' };
}

function Gen({ ex, onAttempt, onDone, done, difficulty }: Props) {
  if (ex.type !== 'gen') return null;
  const [cur, setCur] = useState(() => makeGen(ex.kind, difficulty));
  const [streak, setStreak] = useState(0);
  const [val, setVal] = useState('');
  const [solved, setSolved] = useState(done);
  const [msg, setMsg] = useState<{ k: 'ok' | 'bad'; t: string } | null>(null);
  const submit = () => {
    if (solved || !val.trim()) return;
    const ok = cur.answer.map(normalizeAnswer).includes(normalizeAnswer(val));
    onAttempt(ok);
    if (ok) {
      const s = streak + 1;
      if (s >= ex.count) { setSolved(true); onDone(); setMsg({ k: 'ok', t: `**${ex.count} acertos seguidos!** ${ex.explain}` }); return; }
      setStreak(s); setMsg({ k: 'ok', t: `Certo! (${s}/${ex.count}) ${cur.solution}` });
    } else {
      setStreak(0); setMsg({ k: 'bad', t: `Errado — a sequência volta a zero (é assim que se constrói domínio). Resposta: ${cur.solution}` });
    }
    setCur(makeGen(ex.kind, difficulty)); setVal('');
  };
  return (
    <Frame title={`Treino gerado (acerte ${ex.count} seguidos) · nível ${['fácil', 'médio', 'difícil'][difficulty]}`} done={solved}>
      <Markdown text={ex.q} />
      {!solved && <div className="mt-3 rounded-lg bg-slate-800 p-3"><Markdown text={cur.prompt} /></div>}
      <div className="mt-2 flex items-center gap-2">
        <input value={val} onChange={(e) => setVal(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && submit()} disabled={solved} className="flex-1 rounded-lg border border-slate-600 bg-slate-800 px-3 py-2 font-mono text-white disabled:opacity-60" placeholder="resposta" />
        <button type="button" onClick={submit} disabled={solved} className="rounded-lg bg-amber-500 px-4 py-2 font-bold text-slate-900 hover:bg-amber-400 disabled:opacity-40">Verificar</button>
        <span className="font-mono text-sm text-slate-400">{Array.from({ length: ex.count }, (_, i) => (i < streak || solved ? '●' : '○')).join(' ')}</span>
      </div>
      {msg && <Feedback kind={msg.k} text={msg.t} />}
    </Frame>
  );
}
