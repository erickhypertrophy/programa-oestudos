import React from 'react';
import { Demo } from './Demos';

function inline(text: string): React.ReactNode[] {
  // **bold**, `code`, *italic*
  const parts: React.ReactNode[] = [];
  const re = /(\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let k = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    const tok = m[0];
    if (tok.startsWith('**')) parts.push(<strong key={k++} className="font-semibold text-amber-200">{tok.slice(2, -2)}</strong>);
    else if (tok.startsWith('`')) parts.push(<code key={k++} className="rounded bg-slate-800 px-1.5 py-0.5 font-mono text-[0.92em] text-emerald-300">{tok.slice(1, -1)}</code>);
    else parts.push(<em key={k++} className="italic text-slate-200">{tok.slice(1, -1)}</em>);
    last = m.index + tok.length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts;
}

const CALLOUT: Record<string, { cls: string; label: string }> = {
  '💡': { cls: 'border-amber-400/50 bg-amber-400/10', label: 'Ideia-chave' },
  '⚠️': { cls: 'border-rose-400/50 bg-rose-400/10', label: 'Atenção / simplificação' },
  '🔤': { cls: 'border-sky-400/50 bg-sky-400/10', label: 'Termo em inglês' },
  '🧪': { cls: 'border-emerald-400/50 bg-emerald-400/10', label: 'Tente antes de ler' },
  '📜': { cls: 'border-violet-400/50 bg-violet-400/10', label: 'História' },
  '🔁': { cls: 'border-fuchsia-400/50 bg-fuchsia-400/10', label: 'Lembra?' },
};

export function Markdown({ text }: { text: string }) {
  const lines = text.split('\n');
  const out: React.ReactNode[] = [];
  let i = 0;
  let k = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (line.trim() === '') { i++; continue; }
    if (line.startsWith('```')) {
      const buf: string[] = [];
      i++;
      while (i < lines.length && !lines[i].startsWith('```')) { buf.push(lines[i]); i++; }
      i++;
      out.push(<pre key={k++} className="my-4 overflow-x-auto rounded-xl border border-slate-700 bg-slate-900/80 p-4 font-mono text-sm leading-relaxed text-emerald-200">{buf.join('\n')}</pre>);
      continue;
    }
    const demo = line.match(/^\[\[demo:([a-z0-9-]+)\]\]$/);
    if (demo) { out.push(<Demo key={k++} name={demo[1]} />); i++; continue; }
    if (line.startsWith('## ')) { out.push(<h2 key={k++} className="mt-10 mb-3 text-2xl font-bold text-white">{inline(line.slice(3))}</h2>); i++; continue; }
    if (line.startsWith('### ')) { out.push(<h3 key={k++} className="mt-7 mb-2 text-lg font-semibold text-amber-100">{inline(line.slice(4))}</h3>); i++; continue; }
    if (line.trim() === '---') { out.push(<hr key={k++} className="my-8 border-slate-700" />); i++; continue; }
    if (line.startsWith('> ')) {
      const buf: string[] = [];
      while (i < lines.length && lines[i].startsWith('> ')) { buf.push(lines[i].slice(2)); i++; }
      const first = buf[0];
      const icon = Object.keys(CALLOUT).find((ic) => first.startsWith(ic));
      const conf = icon ? CALLOUT[icon] : { cls: 'border-slate-500/50 bg-slate-700/30', label: '' };
      if (icon) buf[0] = first.slice(icon.length).trim();
      out.push(
        <div key={k++} className={`my-5 rounded-xl border-l-4 px-5 py-4 ${conf.cls}`}>
          {conf.label && <div className="mb-1 text-xs font-bold uppercase tracking-wider text-slate-300">{icon} {conf.label}</div>}
          {buf.map((b, j) => <p key={j} className="leading-relaxed text-slate-100">{inline(b)}</p>)}
        </div>,
      );
      continue;
    }
    if (line.startsWith('|')) {
      const rows: string[][] = [];
      while (i < lines.length && lines[i].startsWith('|')) {
        const cells = lines[i].split('|').slice(1, -1).map((c) => c.trim());
        if (!cells.every((c) => /^:?-+:?$/.test(c))) rows.push(cells);
        i++;
      }
      out.push(
        <div key={k++} className="my-5 overflow-x-auto">
          <table className="min-w-[280px] border-collapse font-mono text-sm">
            <thead><tr>{rows[0].map((c, j) => <th key={j} className="border border-slate-600 bg-slate-800 px-3 py-2 text-amber-200">{inline(c)}</th>)}</tr></thead>
            <tbody>{rows.slice(1).map((r, ri) => <tr key={ri}>{r.map((c, j) => <td key={j} className="border border-slate-700 px-3 py-1.5 text-center text-slate-100">{inline(c)}</td>)}</tr>)}</tbody>
          </table>
        </div>,
      );
      continue;
    }
    if (/^(-|\d+\.) /.test(line)) {
      const items: string[] = [];
      const ordered = /^\d+\./.test(line);
      while (i < lines.length && /^(-|\d+\.) /.test(lines[i])) { items.push(lines[i].replace(/^(-|\d+\.) /, '')); i++; }
      const Tag = ordered ? 'ol' : 'ul';
      out.push(<Tag key={k++} className={`my-3 ml-6 space-y-1.5 ${ordered ? 'list-decimal' : 'list-disc'} text-slate-200`}>{items.map((it, j) => <li key={j} className="leading-relaxed">{inline(it)}</li>)}</Tag>);
      continue;
    }
    out.push(<p key={k++} className="my-3 leading-relaxed text-slate-200">{inline(line)}</p>);
    i++;
  }
  return <div className="prose-custom max-w-none text-[1.02rem]">{out}</div>;
}
