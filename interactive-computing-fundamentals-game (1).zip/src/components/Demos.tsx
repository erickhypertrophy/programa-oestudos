import { useEffect, useState } from 'react';
import { GATE_INFO, allCombos, toBin, toTwos, fromTwos } from '../lib/logic';
import type { GateKind } from '../lib/types';

function Box({ title, children, hint }: { title: string; children: React.ReactNode; hint?: string }) {
  return (
    <div className="my-6 rounded-2xl border border-cyan-500/40 bg-slate-900/70 p-5 shadow-lg shadow-cyan-900/20">
      <div className="mb-3 flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-cyan-300">🕹️ Laboratório interativo — {title}</div>
      {children}
      {hint && <p className="mt-3 text-sm text-slate-400">{hint}</p>}
    </div>
  );
}

export function BitButton({ on, onClick, label, size = 'md' }: { on: boolean; onClick?: () => void; label?: string; size?: 'sm' | 'md' | 'lg' }) {
  const sz = size === 'lg' ? 'h-16 w-16 text-2xl' : size === 'sm' ? 'h-9 w-9 text-sm' : 'h-12 w-12 text-lg';
  return (
    <div className="flex flex-col items-center gap-1">
      <button
        type="button"
        onClick={onClick}
        className={`${sz} rounded-xl border-2 font-mono font-bold transition-all ${on ? 'border-amber-300 bg-amber-400 text-slate-900 shadow-[0_0_18px_rgba(251,191,36,0.6)]' : 'border-slate-600 bg-slate-800 text-slate-400 hover:border-slate-400'} ${onClick ? 'cursor-pointer active:scale-95' : 'cursor-default'}`}
      >
        {on ? '1' : '0'}
      </button>
      {label !== undefined && <span className="font-mono text-xs text-slate-400">{label}</span>}
    </div>
  );
}

function BitSwitch() {
  const [on, setOn] = useState(false);
  return (
    <Box title="Uma lâmpada, duas possibilidades" hint="Clique na lâmpada. Note que não existe 'meio aceso'. É isso que torna o bit confiável.">
      <div className="flex items-center gap-6">
        <button type="button" onClick={() => setOn(!on)} className={`text-7xl transition-transform active:scale-90 ${on ? 'drop-shadow-[0_0_25px_rgba(251,191,36,0.9)]' : 'opacity-50 grayscale'}`}>💡</button>
        <div>
          <div className="text-sm text-slate-400">Estado atual:</div>
          <div className="font-mono text-3xl font-bold text-amber-300">{on ? 'ACESA · SIM · 1' : 'APAGADA · NÃO · 0'}</div>
          <div className="mt-1 text-sm text-slate-400">Informação transmitida: <strong className="text-white">1 bit</strong></div>
        </div>
      </div>
    </Box>
  );
}

function BinaryCounter({ nbits = 8 }: { nbits?: number }) {
  const [bits, setBits] = useState<boolean[]>(Array(nbits).fill(false));
  const value = bits.reduce((acc, b, i) => acc + (b ? 2 ** (nbits - 1 - i) : 0), 0);
  const toggle = (i: number) => setBits(bits.map((b, j) => (j === i ? !b : b)));
  const inc = () => {
    const v = (value + 1) % 2 ** nbits;
    setBits(Array.from({ length: nbits }, (_, i) => ((v >> (nbits - 1 - i)) & 1) === 1));
  };
  return (
    <Box title={`Contador de ${nbits} bits`} hint="Clique nos bits para ligar/desligar, ou use '+1' para ver como a contagem avança e 'vai um' acontece.">
      <div className="flex flex-wrap items-end gap-2">
        {bits.map((b, i) => <BitButton key={i} on={b} onClick={() => toggle(i)} label={String(2 ** (nbits - 1 - i))} />)}
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-4">
        <div className="font-mono text-lg text-slate-300">Soma: {bits.map((b, i) => (b ? 2 ** (nbits - 1 - i) : null)).filter((x) => x !== null).join(' + ') || '0'} = <span className="text-3xl font-bold text-emerald-300">{value}</span></div>
        <button type="button" onClick={inc} className="rounded-lg bg-cyan-600 px-4 py-2 font-bold text-white hover:bg-cyan-500">+1</button>
        <button type="button" onClick={() => setBits(Array(nbits).fill(false))} className="rounded-lg bg-slate-700 px-4 py-2 text-white hover:bg-slate-600">zerar</button>
      </div>
    </Box>
  );
}

function TextBits() {
  const [txt, setTxt] = useState('Oi');
  const codes = Array.from(txt).map((ch) => ({ ch, code: ch.codePointAt(0) ?? 0 }));
  return (
    <Box title="Texto vira bits" hint="Cada letra é só um número combinado (tabela ASCII/Unicode); cada número vira bits. Experimente maiúsculas, minúsculas, acentos e emojis.">
      <input value={txt} onChange={(e) => setTxt(e.target.value.slice(0, 12))} className="mb-3 w-full rounded-lg border border-slate-600 bg-slate-800 px-3 py-2 font-mono text-lg text-white" />
      <div className="space-y-1 font-mono text-sm">
        {codes.map((c, i) => (
          <div key={i} className="flex flex-wrap gap-3 rounded bg-slate-800/60 px-3 py-1.5">
            <span className="w-8 text-amber-300">{c.ch === ' ' ? '␣' : c.ch}</span>
            <span className="w-24 text-slate-300">código {c.code}</span>
            <span className="text-emerald-300">{c.code < 256 ? toBin(c.code, 8) : c.code.toString(2)}</span>
            {c.code > 127 && <span className="text-xs text-rose-300">fora do ASCII → Unicode (precisa de mais de 1 byte em UTF-8)</span>}
          </div>
        ))}
      </div>
    </Box>
  );
}

function ColorBits() {
  const [r, setR] = useState(255);
  const [g, setG] = useState(140);
  const [b, setB] = useState(0);
  const hex = (n: number) => n.toString(16).padStart(2, '0').toUpperCase();
  return (
    <Box title="Cor vira bits" hint="Uma cor na tela = 3 números de 0 a 255 (vermelho, verde, azul) = 3 bytes = 24 bits. Em hexadecimal, cada byte vira 2 dígitos.">
      <div className="flex flex-wrap items-center gap-6">
        <div className="h-28 w-28 rounded-2xl border-2 border-white/30" style={{ background: `rgb(${r},${g},${b})` }} />
        <div className="flex-1 space-y-2 font-mono text-sm">
          {[['R (vermelho)', r, setR, 'accent-red-500'], ['G (verde)', g, setG, 'accent-green-500'], ['B (azul)', b, setB, 'accent-blue-500']].map(([lab, v, set, cls]) => (
            <div key={lab as string} className="flex items-center gap-3">
              <span className="w-28 text-slate-300">{lab as string}</span>
              <input type="range" min={0} max={255} value={v as number} onChange={(e) => (set as (n: number) => void)(+e.target.value)} className={`flex-1 ${cls as string}`} />
              <span className="w-10 text-right text-white">{v as number}</span>
              <span className="w-24 text-emerald-300">{toBin(v as number, 8)}</span>
            </div>
          ))}
          <div className="pt-2 text-lg">Hex: <span className="text-amber-300">#{hex(r)}{hex(g)}{hex(b)}</span> · 24 bits</div>
        </div>
      </div>
    </Box>
  );
}

function GatePlayground({ kinds }: { kinds: GateKind[] }) {
  const [kind, setKind] = useState<GateKind>(kinds[0]);
  const [a, setA] = useState(false);
  const [b, setB] = useState(false);
  const info = GATE_INFO[kind];
  const out = info.fn(a, b);
  return (
    <Box title="Bancada de portas lógicas" hint="Escolha uma porta e ligue/desligue as entradas. Compare com a tabela-verdade que se preenche ao lado.">
      <div className="mb-4 flex flex-wrap gap-2">
        {kinds.map((kd) => <button type="button" key={kd} onClick={() => setKind(kd)} className={`rounded-lg px-3 py-1.5 font-mono text-sm font-bold ${kind === kd ? 'bg-amber-400 text-slate-900' : 'bg-slate-700 text-slate-200 hover:bg-slate-600'}`}>{kd} <span className="font-normal opacity-70">({GATE_INFO[kd].pt})</span></button>)}
      </div>
      <div className="flex flex-wrap items-center gap-8">
        <div className="flex items-center gap-4">
          <div className="flex flex-col gap-3">
            <BitButton on={a} onClick={() => setA(!a)} label="A" />
            {info.arity === 2 && <BitButton on={b} onClick={() => setB(!b)} label="B" />}
          </div>
          <div className="text-2xl text-slate-500">→</div>
          <div className="rounded-xl border-2 border-cyan-400 bg-slate-800 px-5 py-4 text-center font-mono"><div className="text-xl font-bold text-cyan-200">{kind}</div><div className="text-xs text-slate-400">{info.pt}</div></div>
          <div className="text-2xl text-slate-500">→</div>
          <BitButton on={out} label="saída" size="lg" />
        </div>
        <table className="border-collapse font-mono text-sm">
          <thead><tr><th className="border border-slate-600 px-3 py-1 text-amber-200">A</th>{info.arity === 2 && <th className="border border-slate-600 px-3 py-1 text-amber-200">B</th>}<th className="border border-slate-600 px-3 py-1 text-amber-200">saída</th></tr></thead>
          <tbody>
            {allCombos(info.arity).map((row, i) => {
              const active = row[0] === a && (info.arity === 1 || row[1] === b);
              return <tr key={i} className={active ? 'bg-amber-400/20' : ''}>{row.map((v, j) => <td key={j} className="border border-slate-700 px-3 py-1 text-center">{v ? 1 : 0}</td>)}<td className="border border-slate-700 px-3 py-1 text-center font-bold text-emerald-300">{info.fn(row[0], row[1]) ? 1 : 0}</td></tr>;
            })}
          </tbody>
        </table>
      </div>
    </Box>
  );
}

function Adder({ nbits }: { nbits: number }) {
  const [x, setX] = useState(nbits === 1 ? 1 : 100);
  const [y, setY] = useState(nbits === 1 ? 1 : 200);
  const max = 2 ** nbits - 1;
  const sum = x + y;
  const carry = sum > max;
  const kept = sum % 2 ** nbits;
  const bx = toBin(x, nbits), by = toBin(y, nbits), bs = toBin(kept, nbits);
  // vai-uns por coluna
  const carries: number[] = [];
  let c = 0;
  for (let i = nbits - 1; i >= 0; i--) { const s = +bx[i] + +by[i] + c; c = s >= 2 ? 1 : 0; carries[i] = c; }
  return (
    <Box title={`Somador de ${nbits} bit${nbits > 1 ? 's' : ''}`} hint={nbits === 1 ? 'Com 1 bit: 1 + 1 = 10 (zero, e vai um). A saída precisa de DOIS fios: soma e vai-um (carry).' : 'Mude os números e observe os "vai-um" (linha de cima). Se a soma passar do máximo, o último vai-um "cai fora": é o overflow.'}>
      <div className="mb-3 flex flex-wrap gap-4 font-mono text-sm">
        <label className="flex items-center gap-2">X: <input type="number" min={0} max={max} value={x} onChange={(e) => setX(Math.min(max, Math.max(0, +e.target.value || 0)))} className="w-24 rounded border border-slate-600 bg-slate-800 px-2 py-1 text-white" /></label>
        <label className="flex items-center gap-2">Y: <input type="number" min={0} max={max} value={y} onChange={(e) => setY(Math.min(max, Math.max(0, +e.target.value || 0)))} className="w-24 rounded border border-slate-600 bg-slate-800 px-2 py-1 text-white" /></label>
      </div>
      <pre className="overflow-x-auto rounded-lg bg-slate-800 p-3 font-mono text-base leading-7">
        <span className="text-fuchsia-300">{'vai-um  '}{carries.map((_, i) => (i === nbits - 1 ? '0' : String(carries[i + 1] ?? 0))).join(' ')}{'   ← carry que entra em cada coluna'}</span>{'\n'}
        <span className="text-slate-200">{'X     = '}{bx.split('').join(' ')}{'   ('}{x}{')'}</span>{'\n'}
        <span className="text-slate-200">{'Y     = '}{by.split('').join(' ')}{'   ('}{y}{')'}</span>{'\n'}
        <span className="text-slate-500">{'        '}{'-'.repeat(nbits * 2 - 1)}</span>{'\n'}
        <span className="text-emerald-300">{'soma  = '}{bs.split('').join(' ')}{'   ('}{kept}{')'}</span>{carry && <span className="text-rose-300">{'   ⚠ overflow! o vai-um final (valor '}{2 ** nbits}{') não cabe. Soma real: '}{sum}</span>}
      </pre>
    </Box>
  );
}

function TwosDemo() {
  const [n, setN] = useState(-5);
  const bits = toTwos(n, 8);
  return (
    <Box title="Complemento de dois (8 bits)" hint="Arraste de -128 a 127. Observe: o bit mais à esquerda vale -128 (negativo!) e os outros valem o normal. Some os pesos ligados.">
      <input type="range" min={-128} max={127} value={n} onChange={(e) => setN(+e.target.value)} className="w-full accent-amber-400" />
      <div className="mt-2 flex flex-wrap items-end gap-2">
        {bits.split('').map((b, i) => <BitButton key={i} on={b === '1'} label={i === 0 ? '-128' : String(2 ** (7 - i))} />)}
      </div>
      <div className="mt-3 font-mono text-slate-200">{bits.split('').map((b, i) => (b === '1' ? (i === 0 ? -128 : 2 ** (7 - i)) : null)).filter((v) => v !== null).join(' + ') || '0'} = <span className="text-2xl font-bold text-emerald-300">{fromTwos(bits)}</span></div>
    </Box>
  );
}

function SRLatch() {
  const [q, setQ] = useState(false);
  const [log, setLog] = useState<string[]>([]);
  const act = (what: 'S' | 'R') => {
    if (what === 'S') { setQ(true); setLog((l) => ['Pulso em S (set): Q vira 1 e FICA 1 mesmo depois que S volta a 0.', ...l].slice(0, 4)); }
    else { setQ(false); setLog((l) => ['Pulso em R (reset): Q vira 0 e FICA 0.', ...l].slice(0, 4)); }
  };
  return (
    <Box title="Latch SR — a primeira memória" hint="Depois de apertar S e soltar, o circuito continua lembrando '1'. Nada externo está segurando esse valor: ele se sustenta pela realimentação das duas portas NOR.">
      <div className="flex flex-wrap items-center gap-6">
        <button type="button" onClick={() => act('S')} className="rounded-xl bg-emerald-600 px-5 py-3 font-bold text-white hover:bg-emerald-500 active:scale-95">pulso S (set = gravar 1)</button>
        <button type="button" onClick={() => act('R')} className="rounded-xl bg-rose-600 px-5 py-3 font-bold text-white hover:bg-rose-500 active:scale-95">pulso R (reset = gravar 0)</button>
        <div className="flex items-center gap-3"><span className="text-slate-300">Q (memória):</span><BitButton on={q} size="lg" /></div>
      </div>
      <div className="mt-3 space-y-1 font-mono text-xs text-slate-400">{log.map((l, i) => <div key={i}>• {l}</div>)}</div>
    </Box>
  );
}

function ClockRegister() {
  const [d, setD] = useState(false);
  const [q, setQ] = useState(false);
  const [clk, setClk] = useState(false);
  const [auto, setAuto] = useState(false);
  useEffect(() => {
    if (!auto) return;
    const t = setInterval(() => setClk((c) => !c), 700);
    return () => clearInterval(t);
  }, [auto]);
  useEffect(() => { if (clk) setQ(d); }, [clk]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <Box title="Flip-flop D + relógio" hint="Mude D à vontade: Q só copia D no instante em que o relógio sobe (0→1). Entre as batidas, Q guarda o valor antigo. Isso sincroniza o computador inteiro.">
      <div className="flex flex-wrap items-center gap-8">
        <BitButton on={d} onClick={() => setD(!d)} label="D (dado de entrada)" />
        <div className="flex flex-col items-center gap-1">
          <button type="button" onClick={() => setClk(!clk)} className={`h-12 w-28 rounded-xl border-2 font-mono font-bold ${clk ? 'border-cyan-300 bg-cyan-400 text-slate-900' : 'border-slate-600 bg-slate-800 text-slate-300'}`}>CLK {clk ? '▔' : '▁'}</button>
          <span className="text-xs text-slate-400">relógio (clique para pulsar)</span>
        </div>
        <BitButton on={q} label="Q (guardado)" size="lg" />
        <label className="flex items-center gap-2 text-sm text-slate-300"><input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} /> relógio automático</label>
      </div>
    </Box>
  );
}

// Mini-CPU: 4 registradores? Simples: acumulador A, memória de 8 células, instruções.
type Instr = { op: 'CARREGA' | 'SOMA' | 'GUARDA' | 'PULA_SE_ZERO' | 'PARA' | 'SUB'; arg: number };
const OPCODES: Record<Instr['op'], string> = { CARREGA: '000', SOMA: '001', SUB: '010', GUARDA: '011', PULA_SE_ZERO: '100', PARA: '111' };
function TinyCpu() {
  const program: Instr[] = [
    { op: 'CARREGA', arg: 5 }, // A = mem[5]
    { op: 'SOMA', arg: 6 },    // A = A + mem[6]
    { op: 'GUARDA', arg: 7 },  // mem[7] = A
    { op: 'PARA', arg: 0 },
  ];
  const [mem, setMem] = useState<number[]>([0, 0, 0, 0, 0, 3, 4, 0]);
  const [pc, setPc] = useState(0);
  const [acc, setAcc] = useState(0);
  const [halted, setHalted] = useState(false);
  const [trace, setTrace] = useState<string[]>([]);
  const step = () => {
    if (halted || pc >= program.length) return;
    const ins = program[pc];
    let line = `PC=${pc}: ${OPCODES[ins.op]} ${toBin(ins.arg, 5)}  →  ${ins.op} ${ins.arg}. `;
    let npc = pc + 1;
    if (ins.op === 'CARREGA') { setAcc(mem[ins.arg]); line += `A recebe mem[${ins.arg}] = ${mem[ins.arg]}.`; }
    if (ins.op === 'SOMA') { setAcc(acc + mem[ins.arg]); line += `A = ${acc} + ${mem[ins.arg]} = ${acc + mem[ins.arg]}.`; }
    if (ins.op === 'SUB') { setAcc(acc - mem[ins.arg]); line += `A = ${acc} - ${mem[ins.arg]}.`; }
    if (ins.op === 'GUARDA') { const m = [...mem]; m[ins.arg] = acc; setMem(m); line += `mem[${ins.arg}] recebe ${acc}.`; }
    if (ins.op === 'PULA_SE_ZERO') { if (acc === 0) npc = ins.arg; line += acc === 0 ? `A é zero: pula para ${ins.arg}.` : 'A não é zero: segue.'; }
    if (ins.op === 'PARA') { setHalted(true); line += 'Máquina para.'; }
    setPc(npc);
    setTrace((t) => [...t, line]);
  };
  const reset = () => { setMem([0, 0, 0, 0, 0, 3, 4, 0]); setPc(0); setAcc(0); setHalted(false); setTrace([]); };
  return (
    <Box title="Máquina mínima — executando bits como instruções" hint="Edite mem[5] e mem[6] (os dados), depois clique 'passo'. O programa (4 instruções, cada uma codificada em bits) soma os dois e guarda em mem[7].">
      <div className="grid gap-4 md:grid-cols-2">
        <div>
          <div className="mb-1 text-xs font-bold uppercase text-slate-400">Programa (instruções em bits)</div>
          <div className="space-y-1 font-mono text-sm">
            {program.map((ins, i) => <div key={i} className={`rounded px-2 py-1 ${i === pc && !halted ? 'bg-amber-400/30 text-amber-100' : 'bg-slate-800 text-slate-300'}`}>{i}: <span className="text-emerald-300">{OPCODES[ins.op]} {toBin(ins.arg, 5)}</span>  = {ins.op} {ins.arg}</div>)}
          </div>
          <div className="mt-3 flex items-center gap-3 font-mono text-sm"><span className="rounded bg-slate-800 px-2 py-1">PC = {pc}</span><span className="rounded bg-slate-800 px-2 py-1">A (acumulador) = {acc}</span></div>
          <div className="mt-3 flex gap-2"><button type="button" onClick={step} disabled={halted} className="rounded-lg bg-cyan-600 px-4 py-2 font-bold text-white disabled:opacity-40">passo ▶</button><button type="button" onClick={reset} className="rounded-lg bg-slate-700 px-4 py-2 text-white">reiniciar</button></div>
        </div>
        <div>
          <div className="mb-1 text-xs font-bold uppercase text-slate-400">Memória (8 células de 8 bits)</div>
          <div className="space-y-1 font-mono text-sm">
            {mem.map((v, i) => <div key={i} className="flex items-center gap-2 rounded bg-slate-800 px-2 py-1"><span className="w-14 text-slate-400">mem[{i}]</span><input type="number" value={v} disabled={i < 5 || i === 7} onChange={(e) => { const m = [...mem]; m[i] = Math.max(0, Math.min(255, +e.target.value || 0)); setMem(m); }} className="w-16 rounded border border-slate-600 bg-slate-900 px-1 text-white disabled:opacity-50" /><span className="text-emerald-300">{toBin(v, 8)}</span></div>)}
          </div>
        </div>
      </div>
      <div className="mt-3 max-h-36 space-y-1 overflow-y-auto rounded bg-slate-950/60 p-2 font-mono text-xs text-slate-300">{trace.length === 0 ? <span className="text-slate-500">(o rastro da execução aparece aqui)</span> : trace.map((t, i) => <div key={i}>{t}</div>)}</div>
    </Box>
  );
}

function PowersTable() {
  return (
    <Box title="Potências de 2 — os pesos das casas" hint="Decore essas. Elas são as 'notas' do dinheiro binário. Clique numa para ver a composição.">
      <div className="grid grid-cols-4 gap-2 font-mono text-sm sm:grid-cols-8">
        {Array.from({ length: 16 }, (_, i) => <div key={i} className="rounded-lg bg-slate-800 p-2 text-center"><div className="text-xs text-slate-400">2^{i}</div><div className="text-lg font-bold text-amber-300">{2 ** i}</div></div>)}
      </div>
    </Box>
  );
}

function MuxDemo() {
  const [a, setA] = useState(false);
  const [b, setB] = useState(true);
  const [sel, setSel] = useState(false);
  const out = sel ? b : a;
  return (
    <Box title="Multiplexador (MUX) — o 'seletor'" hint="SEL escolhe qual entrada passa para a saída. Com isso o computador decide: 'use este valor ou aquele'. É a base do 'se... então'.">
      <div className="flex flex-wrap items-center gap-6">
        <BitButton on={a} onClick={() => setA(!a)} label="entrada A" />
        <BitButton on={b} onClick={() => setB(!b)} label="entrada B" />
        <BitButton on={sel} onClick={() => setSel(!sel)} label="SEL (0=A, 1=B)" />
        <span className="text-2xl text-slate-500">→</span>
        <BitButton on={out} label="saída" size="lg" />
      </div>
      <p className="mt-2 font-mono text-xs text-slate-400">saída = (NOT SEL AND A) OR (SEL AND B)</p>
    </Box>
  );
}

export function Demo({ name }: { name: string }) {
  switch (name) {
    case 'bit-switch': return <BitSwitch />;
    case 'counter-4': return <BinaryCounter nbits={4} />;
    case 'counter-8': return <BinaryCounter nbits={8} />;
    case 'text-bits': return <TextBits />;
    case 'color-bits': return <ColorBits />;
    case 'gates-basic': return <GatePlayground kinds={['NOT', 'AND', 'OR']} />;
    case 'gates-all': return <GatePlayground kinds={['NOT', 'AND', 'OR', 'XOR', 'NAND', 'NOR']} />;
    case 'gates-nand': return <GatePlayground kinds={['NAND']} />;
    case 'adder-1': return <Adder nbits={1} />;
    case 'adder-8': return <Adder nbits={8} />;
    case 'twos': return <TwosDemo />;
    case 'sr-latch': return <SRLatch />;
    case 'dff': return <ClockRegister />;
    case 'mux': return <MuxDemo />;
    case 'cpu': return <TinyCpu />;
    case 'powers': return <PowersTable />;
    default: return <div className="text-rose-400">demo desconhecida: {name}</div>;
  }
}
