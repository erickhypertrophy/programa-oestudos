import { useMemo, useState } from 'react';
import { PHASES, ALL_CARDS, ALL_GLOSSARY, totalExercises } from '../content';
import type { Progress } from '../lib/storage';
import { dueCards, scheduleCard, weakSpots, exportJson, importJson, fresh, INTERVALS_DAYS } from '../lib/storage';
import { Markdown } from './Markdown';
import { normalizeAnswer } from '../lib/logic';

export function Home({ progress, setProgress, go }: { progress: Progress; setProgress: (p: Progress) => void; go: (s: string) => void }) {
  const due = dueCards(progress).length;
  const weak = weakSpots(progress);
  const [name, setName] = useState(progress.name);
  return (
    <div className="mx-auto max-w-4xl px-4 pb-24 pt-8">
      <header className="mb-8">
        <div className="text-xs font-bold uppercase tracking-[0.3em] text-cyan-300">Curso jogável · do zero ao processador</div>
        <h1 className="mt-2 text-4xl font-black text-white sm:text-5xl">BITS: <span className="text-amber-300">a fundação de tudo</span></h1>
        <p className="mt-3 max-w-2xl text-slate-300">Uma jornada de 8 fases pela camada mais baixa da computação: do bit à máquina que executa programas. Cada fase só abre depois que você derrota o chefe da anterior. Seu progresso é salvo automaticamente neste navegador.</p>
      </header>

      {!progress.name && (
        <div className="mb-6 rounded-2xl border border-amber-400/40 bg-amber-400/10 p-5">
          <div className="font-bold text-amber-200">Antes de começar: como devo te chamar?</div>
          <div className="mt-2 flex gap-2"><input value={name} onChange={(e) => setName(e.target.value)} placeholder="seu nome" className="rounded-lg border border-slate-600 bg-slate-800 px-3 py-2 text-white" /><button onClick={() => setProgress({ ...progress, name: name || 'Aprendiz' })} className="rounded-lg bg-amber-500 px-4 py-2 font-bold text-slate-900">Salvar</button></div>
          <p className="mt-3 text-sm text-slate-300">Recomendo ler primeiro o <button onClick={() => go('guide')} className="underline">Guia</button>: explica como o jogo funciona, por que foi desenhado assim (com as fontes) e como instalar/rodar.</p>
        </div>
      )}

      <div className="mb-8 grid gap-3 sm:grid-cols-4">
        <Stat label="XP" value={String(progress.xp)} />
        <Stat label="Fases vencidas" value={`${Object.keys(progress.bossPassed).length}/8`} />
        <Stat label="Fichas para revisar" value={String(due)} accent={due > 0} onClick={() => go('review')} />
        <Stat label="Exercícios feitos" value={String(Object.values(progress.exercises).filter((e) => e.done).length)} />
      </div>

      {progress.lastPhase && !progress.bossPassed[progress.lastPhase] && (
        <button onClick={() => go('phase:' + progress.lastPhase)} className="mb-6 w-full rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 p-4 text-left font-bold text-slate-900 shadow-lg hover:brightness-110">▶ Continuar de onde parei: {PHASES.find((p) => p.id === progress.lastPhase)?.title}</button>
      )}

      <h2 className="mb-3 text-xl font-bold text-white">Mapa das fases</h2>
      <div className="space-y-3">
        {PHASES.map((p) => {
          const unlocked = p.num <= progress.unlockedPhase;
          const passed = !!progress.bossPassed[p.id];
          const secs = p.sections.filter((s) => progress.completedSections[`${p.id}/${s.id}`]).length;
          const done = Object.entries(progress.exercises).filter(([id, s]) => id.startsWith(p.id + '-') && s.done).length;
          return (
            <button key={p.id} disabled={!unlocked} onClick={() => go('phase:' + p.id)} className={`flex w-full items-center gap-4 rounded-2xl border p-4 text-left transition ${passed ? 'border-emerald-500/50 bg-emerald-950/20' : unlocked ? 'border-amber-400/50 bg-slate-800/70 hover:border-amber-300' : 'border-slate-700 bg-slate-900/50 opacity-50'}`}>
              <div className="text-4xl">{unlocked ? p.emoji : '🔒'}</div>
              <div className="flex-1">
                <div className="text-xs uppercase tracking-wider text-slate-400">Fase {p.num}</div>
                <div className="text-lg font-bold text-white">{p.title}</div>
                <div className="text-sm text-slate-300">{p.subtitle}</div>
                <div className="mt-2 flex items-center gap-3 text-xs text-slate-400">
                  <span>{secs}/{p.sections.length} seções</span>
                  <span>{done}/{totalExercises(p)} exercícios</span>
                  {passed && <span className="text-emerald-300">✓ chefe derrotado</span>}
                  {!passed && progress.bossAttempts[p.id] ? <span className="text-rose-300">chefe: {progress.bossAttempts[p.id]} tentativa(s)</span> : null}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {weak.length > 0 && (
        <div className="mt-8 rounded-2xl border border-rose-500/40 bg-rose-950/20 p-5">
          <h3 className="font-bold text-rose-200">Onde você tem mais dificuldade (o jogo usa isso para ajustar o nível)</h3>
          <ul className="mt-2 space-y-1 text-sm text-slate-300">
            {weak.map((w) => { const ph = PHASES.find((p) => w.id.startsWith(p.id + '-')); return <li key={w.id}>• Fase {ph?.num} ({ph?.title}): exercício <code className="text-rose-200">{w.id}</code>, {w.errors} erro(s), taxa {Math.round(w.rate * 100)}%</li>; })}
          </ul>
        </div>
      )}

      <div className="mt-8 flex flex-wrap gap-2 text-sm">
        <button onClick={() => go('review')} className="rounded-lg bg-fuchsia-700 px-4 py-2 font-bold text-white hover:bg-fuchsia-600">🔁 Revisão espaçada {due > 0 && `(${due})`}</button>
        <button onClick={() => go('glossary')} className="rounded-lg bg-sky-700 px-4 py-2 font-bold text-white hover:bg-sky-600">📖 Glossário PT/EN</button>
        <button onClick={() => go('guide')} className="rounded-lg bg-slate-700 px-4 py-2 font-bold text-white hover:bg-slate-600">📋 Guia, método e fontes</button>
        <button onClick={() => go('data')} className="rounded-lg bg-slate-700 px-4 py-2 font-bold text-white hover:bg-slate-600">💾 Salvar/restaurar progresso</button>
      </div>
    </div>
  );
}

function Stat({ label, value, accent, onClick }: { label: string; value: string; accent?: boolean; onClick?: () => void }) {
  return <button onClick={onClick} className={`rounded-2xl border p-4 text-left ${accent ? 'border-fuchsia-400 bg-fuchsia-950/30' : 'border-slate-700 bg-slate-800/60'}`}><div className="text-xs uppercase tracking-wider text-slate-400">{label}</div><div className="text-2xl font-black text-white">{value}</div></button>;
}

export function Review({ progress, setProgress, back }: { progress: Progress; setProgress: (p: Progress) => void; back: () => void }) {
  const due = useMemo(() => dueCards(progress), [progress]);
  const [queue, setQueue] = useState<string[]>(due);
  const [show, setShow] = useState(false);
  const [typed, setTyped] = useState('');
  const [typedOk, setTypedOk] = useState<boolean | null>(null);
  const cur = queue[0] ? ALL_CARDS[queue[0]] : null;
  const total = Object.keys(progress.srs).length;
  const rate = (remembered: boolean) => {
    if (!cur) return;
    setProgress(scheduleCard(progress, cur.id, remembered));
    setQueue(queue.slice(1)); setShow(false); setTyped(''); setTypedOk(null);
  };
  const next = Object.values(progress.srs).map((s) => s.due).filter((d) => d > Date.now()).sort((a, b) => a - b)[0];
  return (
    <div className="mx-auto max-w-2xl px-4 pb-24 pt-6">
      <button onClick={back} className="mb-4 rounded-lg border border-slate-600 px-3 py-1.5 text-sm text-slate-300">← Mapa</button>
      <h1 className="text-3xl font-bold text-white">🔁 Revisão espaçada</h1>
      <p className="mt-2 text-sm text-slate-300">Fichas ativas: {total}. Intervalos: {INTERVALS_DAYS.join(', ')} dias. Cada acerto sobe a ficha de caixa; cada erro a devolve ao início. Tente responder <strong>antes</strong> de revelar: o esforço de lembrar é o que fixa (efeito de teste, Roediger & Karpicke 2006).</p>
      {!cur ? (
        <div className="mt-8 rounded-2xl border border-emerald-500/40 bg-emerald-950/20 p-6 text-slate-200">
          {total === 0 ? 'Nenhuma ficha ainda. Complete seções das fases para ativar fichas.' : <>Nada para revisar agora. 🎉 {next && <>Próxima ficha em {Math.max(1, Math.round((next - Date.now()) / 3600000))} hora(s).</>}</>}
        </div>
      ) : (
        <div className="mt-6 rounded-2xl border border-fuchsia-500/40 bg-slate-900/70 p-6">
          <div className="text-xs uppercase tracking-wider text-fuchsia-300">Fase {PHASES.find((p) => p.id === cur.phase)?.num} · caixa {progress.srs[cur.id]?.box ?? 0} · restam {queue.length}</div>
          <div className="mt-2 text-xl text-white">{cur.q}</div>
          {cur.answer && !show && (
            <div className="mt-3 flex gap-2">
              <input value={typed} onChange={(e) => setTyped(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { const ok = (Array.isArray(cur.answer) ? cur.answer : [cur.answer!]).map(normalizeAnswer).includes(normalizeAnswer(typed)); setTypedOk(ok); setShow(true); } }} placeholder="digite a resposta" className="flex-1 rounded-lg border border-slate-600 bg-slate-800 px-3 py-2 font-mono text-white" />
              <button onClick={() => { const ok = (Array.isArray(cur.answer) ? cur.answer : [cur.answer!]).map(normalizeAnswer).includes(normalizeAnswer(typed)); setTypedOk(ok); setShow(true); }} className="rounded-lg bg-amber-500 px-4 py-2 font-bold text-slate-900">Conferir</button>
            </div>
          )}
          {!show ? <button onClick={() => setShow(true)} className="mt-4 rounded-lg bg-fuchsia-700 px-4 py-2 font-bold text-white">Revelar resposta</button> : (
            <>
              {typedOk !== null && <div className={`mt-3 font-bold ${typedOk ? 'text-emerald-300' : 'text-rose-300'}`}>{typedOk ? '✅ Sua resposta está correta.' : '❌ Sua resposta não bate.'}</div>}
              <div className="mt-3 rounded-lg bg-slate-800 p-3 text-emerald-100"><Markdown text={cur.a} /></div>
              <div className="mt-4 flex gap-2">
                <button onClick={() => rate(false)} className="flex-1 rounded-lg bg-rose-600 px-4 py-3 font-bold text-white">Não lembrei / errei</button>
                <button onClick={() => rate(true)} className="flex-1 rounded-lg bg-emerald-600 px-4 py-3 font-bold text-white">Lembrei bem</button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}

export function Glossary({ progress, back }: { progress: Progress; back: () => void }) {
  const [q, setQ] = useState('');
  const items = ALL_GLOSSARY.filter((g) => g.num <= progress.unlockedPhase && (q === '' || (g.pt + g.en + g.def).toLowerCase().includes(q.toLowerCase())));
  return (
    <div className="mx-auto max-w-3xl px-4 pb-24 pt-6">
      <button onClick={back} className="mb-4 rounded-lg border border-slate-600 px-3 py-1.5 text-sm text-slate-300">← Mapa</button>
      <h1 className="text-3xl font-bold text-white">📖 Glossário português / inglês</h1>
      <p className="mt-2 text-sm text-slate-300">O glossário cresce conforme você desbloqueia fases (termos de fases futuras ficam ocultos para não aparecerem antes de serem explicados). {items.length} termos visíveis.</p>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="buscar termo..." className="mt-4 w-full rounded-lg border border-slate-600 bg-slate-800 px-3 py-2 text-white" />
      <div className="mt-4 space-y-2">
        {items.map((g, i) => (
          <div key={i} className="rounded-xl border border-slate-700 bg-slate-900/60 p-4">
            <div className="flex flex-wrap items-baseline gap-2"><span className="text-lg font-bold text-amber-200">{g.pt}</span><span className="font-mono text-sm text-sky-300">{g.en}</span><span className="ml-auto text-xs text-slate-500">Fase {g.num}</span></div>
            <div className="mt-1 text-slate-200"><Markdown text={g.def} /></div>
            {g.origin && <div className="mt-1 text-sm text-slate-400">Origem: {g.origin}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}

export function DataScreen({ progress, setProgress, back }: { progress: Progress; setProgress: (p: Progress) => void; back: () => void }) {
  const [txt, setTxt] = useState('');
  const [msg, setMsg] = useState('');
  return (
    <div className="mx-auto max-w-2xl px-4 pb-24 pt-6">
      <button onClick={back} className="mb-4 rounded-lg border border-slate-600 px-3 py-1.5 text-sm text-slate-300">← Mapa</button>
      <h1 className="text-3xl font-bold text-white">💾 Progresso</h1>
      <p className="mt-2 text-slate-300">Seu progresso é salvo automaticamente no armazenamento local deste navegador (localStorage). Para levar para outro computador ou fazer backup, exporte o JSON abaixo e importe lá.</p>
      <div className="mt-4 flex flex-wrap gap-2">
        <button onClick={() => { const blob = new Blob([exportJson(progress)], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'progresso-bits.json'; a.click(); }} className="rounded-lg bg-emerald-600 px-4 py-2 font-bold text-white">Baixar arquivo de progresso</button>
        <button onClick={() => { navigator.clipboard?.writeText(exportJson(progress)); setMsg('Copiado para a área de transferência.'); }} className="rounded-lg bg-slate-700 px-4 py-2 font-bold text-white">Copiar JSON</button>
        <button onClick={() => { if (confirm('Apagar TODO o progresso? Isso não pode ser desfeito.')) { setProgress(fresh()); setMsg('Progresso zerado.'); } }} className="rounded-lg bg-rose-700 px-4 py-2 font-bold text-white">Zerar progresso</button>
      </div>
      <textarea value={txt} onChange={(e) => setTxt(e.target.value)} rows={6} placeholder="cole aqui um JSON exportado para restaurar" className="mt-4 w-full rounded-lg border border-slate-600 bg-slate-800 p-3 font-mono text-xs text-white" />
      <button onClick={() => { const p = importJson(txt); if (p) { setProgress(p); setMsg('Progresso restaurado!'); } else setMsg('JSON inválido.'); }} className="mt-2 rounded-lg bg-amber-500 px-4 py-2 font-bold text-slate-900">Restaurar a partir do JSON</button>
      {msg && <p className="mt-3 text-emerald-300">{msg}</p>}
      <h2 className="mt-8 text-xl font-bold text-white">Suas explicações salvas</h2>
      <p className="text-sm text-slate-400">Tudo o que você escreveu nos exercícios "explique com suas palavras". Reler suas próprias explicações antigas é uma ótima forma de perceber o quanto evoluiu.</p>
      <div className="mt-3 space-y-2">{Object.entries(progress.notes).map(([id, t]) => <div key={id} className="rounded-lg bg-slate-800 p-3 text-sm"><div className="font-mono text-xs text-slate-400">{id}</div><div className="text-slate-200">{t}</div></div>)}{Object.keys(progress.notes).length === 0 && <div className="text-sm text-slate-500">(ainda nenhuma)</div>}</div>
    </div>
  );
}

const GUIDE = `
## O que é este jogo

**BITS: a fundação de tudo** é um curso jogável sobre uma única coisa: a camada mais baixa da computação, que vai do **bit** até a **máquina que executa instruções**. São 8 fases, 30 seções, mais de 150 exercícios, 8 chefes e um sistema de revisão espaçada.

## Por que ESSA é a base (e não "lógica de programação" ou "algoritmos")

Toda linguagem de programação, sistema operacional, banco de dados ou rede neural é, no fim, bits sendo movidos e combinados por lógica booleana em hardware. Isso não é opinião: é o modelo de camadas usado por todo currículo sério de ciência da computação (a sequência "sistemas digitais → arquitetura → sistemas operacionais → linguagens"). O curso **Nand2Tetris** (Nisan & Schocken, Hebrew University; livro *The Elements of Computing Systems*, MIT Press, 2005/2021) é a demonstração mais concreta: parte de uma única porta NAND e constrói um computador completo que roda Tetris, provando que nada mais é necessário. O livro *Code* de Charles Petzold (1999/2022) conta a mesma história para leigos. Este jogo segue o mesmo caminho, em português, com exercícios interativos e sem pressupor nada.

Abaixo do bit está a física dos semicondutores, que não é computação. Acima do ciclo busca-decodifica-executa está o software, que é organização de bits usando as peças que você aprende aqui. Por isso a base começa no bit e termina no programa.

## Como o jogo foi desenhado (ciência da aprendizagem)

- **Prática de recuperação em vez de releitura.** Toda seção termina com exercícios que exigem produzir a resposta, não reconhecê-la. Roediger & Karpicke (2006, *Psychological Science*) mostraram que testar-se retém mais que reler (61% vs 40% após uma semana); Karpicke & Roediger (2008, *Science*) mostraram que repetir a recuperação melhora a retenção em mais de 100% em relação a repetir o estudo.
- **Feedback corretivo imediato e específico.** Cada alternativa errada tem uma explicação própria de *por que* está errada; respostas digitadas recebem dicas progressivas. Butler & Roediger (2008) e a meta-análise de Rowland (2014) mostram que feedback aproximadamente dobra o efeito da prática de recuperação.
- **Repetição espaçada.** Ao concluir seções, fichas entram num sistema de caixas (Leitner) com intervalos de 1, 3, 7, 14 e 30 dias. Karpicke & Roediger (2010) mostraram que o formato exato do espaçamento importa pouco; o que importa é repetir a recuperação ao longo do tempo. Além disso, cada seção começa com fichas "Lembra?" de fases anteriores (prática intercalada).
- **Aprendizagem por domínio.** Você só avança após completar todos os exercícios da seção, e só desbloqueia a próxima fase ao acertar ≥80% do chefe na primeira tentativa. Bloom (1984) mostrou que mastery learning com feedback aproxima o desempenho médio do de alunos com tutor individual.
- **Erro produtivo.** Várias seções têm caixas "Tente antes de ler" (Kapur, *productive failure*): tentar resolver antes da explicação cria estrutura mental onde a explicação se encaixa.
- **Explicar com as próprias palavras.** Exercícios de "explique" verificam se sua explicação toca nos conceitos essenciais e depois mostram uma resposta-modelo para comparação (auto-explicação; Chi et al., 1994).
- **Dificuldade adaptativa.** Exercícios gerados (conversões, somas) observam sua taxa de erro e ajustam o tamanho dos números.
- **Construir em camadas.** Nenhum termo é usado antes de ser explicado; o glossário só mostra termos das fases já desbloqueadas.

## Como instalar e rodar (passo a passo, assumindo zero experiência)

Você está vendo esta página, então já está rodando. Se recebeu só os arquivos do projeto:

1. Instale o **Node.js** (versão 18 ou mais nova): acesse nodejs.org, baixe o instalador "LTS" para o seu sistema e instale com as opções padrão.
2. Abra um terminal: no Windows, aperte a tecla Windows, digite "PowerShell" e abra; no Mac, abra "Terminal" (Cmd+Espaço, digite Terminal); no Linux, Ctrl+Alt+T.
3. Navegue até a pasta do projeto: digite \`cd\` seguido de espaço e arraste a pasta do projeto para a janela do terminal; aperte Enter.
4. Digite \`npm install\` e aperte Enter. Espere terminar (baixa as dependências; pode levar 1–2 minutos).
5. Digite \`npm run dev\` e aperte Enter. Vai aparecer um endereço como \`http://localhost:5173\`. Abra esse endereço no navegador.
6. Para parar, volte ao terminal e aperte Ctrl+C.

Alternativa sem terminal: rode \`npm run build\` uma vez; o arquivo \`dist/index.html\` gerado funciona abrindo diretamente no navegador (é um arquivo único).

**Seu progresso** fica salvo no navegador (localStorage). Use "Salvar/restaurar progresso" para fazer backup em arquivo.

## Como estudar com o jogo

- Sessões de 25–45 minutos. Uma seção por sessão é um bom ritmo; uma fase por semana, confortável.
- **Nunca pule os exercícios de "explique".** Eles são os que mais revelam lacunas.
- Volte diariamente por alguns minutos para a **Revisão espaçada**. É aí que o conhecimento vira permanente.
- Se um chefe te derrotar, ótimo: releia as seções sugeridas e volte. A derrota com feedback vale mais que a vitória por sorte.
- Tenha papel e caneta. Converter números e montar tabelas à mão fixa mais do que só clicar.

## Honestidade sobre simplificações

Em cada fase, caixas marcadas com ⚠️ avisam o que foi simplificado (transistores como interruptores ideais, somador de ondulação, máquina de 8 instruções, etc.). A última seção da Fase 7 lista todas as simplificações e os próximos passos.

## Fontes principais

- Nisan, N. & Schocken, S. *The Elements of Computing Systems* (MIT Press, 2ª ed. 2021); nand2tetris.org; artigo "Nand to Tetris: Building a Modern Computer System from First Principles", *Communications of the ACM*, 2024.
- Petzold, C. *Code: The Hidden Language of Computer Hardware and Software* (2ª ed., 2022).
- Shannon, C. *A Symbolic Analysis of Relay and Switching Circuits* (1938) e *A Mathematical Theory of Communication* (1948).
- Roediger, H. & Karpicke, J. "Test-Enhanced Learning", *Psychological Science* 17(3), 2006.
- Karpicke, J. & Roediger, H. "The Critical Importance of Retrieval for Learning", *Science* 319, 2008.
- Karpicke, J. & Roediger, H. "Is expanding retrieval a superior method for learning text materials?", *Memory & Cognition* 38, 2010.
- Rowland, C. "The effect of testing versus restudy on retention: A meta-analytic review", *Psychological Bulletin* 140, 2014.
- Bloom, B. "The 2 Sigma Problem", *Educational Researcher* 13(6), 1984.
- Kapur, M. "Productive Failure", *Cognition and Instruction* 26(3), 2008.
- Chi, M. et al. "Eliciting self-explanations improves understanding", *Cognitive Science* 18, 1994.
`;

export function Guide({ back }: { back: () => void }) {
  return (
    <div className="mx-auto max-w-3xl px-4 pb-24 pt-6">
      <button onClick={back} className="mb-4 rounded-lg border border-slate-600 px-3 py-1.5 text-sm text-slate-300">← Mapa</button>
      <h1 className="text-3xl font-bold text-white">📋 Guia, método e fontes</h1>
      <Markdown text={GUIDE} />
    </div>
  );
}
