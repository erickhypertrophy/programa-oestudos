import { useEffect, useMemo, useState } from 'react';
import type { Phase } from '../lib/types';
import type { Progress } from '../lib/storage';
import { recordAttempt, difficultyFor, activateCards } from '../lib/storage';
import { Markdown } from './Markdown';
import { ExerciseView } from './Exercise';
import { ALL_CARDS } from '../content';

interface Props {
  phase: Phase;
  progress: Progress;
  setProgress: (p: Progress) => void;
  onExit: () => void;
  onPhaseComplete: () => void;
}

export function PhaseView({ phase, progress, setProgress, onExit, onPhaseComplete }: Props) {
  const startIdx = progress.lastSection[phase.id] ?? 0;
  const [idx, setIdx] = useState(Math.min(startIdx, phase.sections.length)); // sections.length == boss
  const isBoss = idx === phase.sections.length;
  const section = isBoss ? null : phase.sections[idx];
  const [doneIds, setDoneIds] = useState<Set<string>>(new Set());
  const [bossFirst, setBossFirst] = useState<Record<string, boolean>>({}); // id -> acertou na 1ª tentativa
  const [bossSeen, setBossSeen] = useState<Set<string>>(new Set());
  const [bossResult, setBossResult] = useState<null | { ok: boolean; ratio: number }>(null);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setDoneIds(new Set());
    setProgress({ ...progress, lastPhase: phase.id, lastSection: { ...progress.lastSection, [phase.id]: idx } });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idx, phase.id]);

  const sectionKey = (i: number) => `${phase.id}/${phase.sections[i]?.id}`;
  const exercises = isBoss ? phase.boss.exercises : section!.exercises;
  const allDone = exercises.every((e) => doneIds.has(e.id) || progress.exercises[e.id]?.done);
  const diff = useMemo(() => difficultyFor(progress, phase.id), [progress, phase.id]);

  const dueReview = useMemo(() => {
    // Lembra? — fichas de fases anteriores para revisão intercalada no início de cada seção
    const prev = Object.entries(progress.srs).filter(([id]) => ALL_CARDS[id] && ALL_CARDS[id].phase !== phase.id);
    if (prev.length === 0) return [];
    const seed = idx * 7 + phase.num * 13;
    return prev.slice(seed % prev.length, (seed % prev.length) + 2).map(([id]) => ALL_CARDS[id]);
  }, [idx, phase.id, phase.num, progress.srs]);

  const onAttempt = (id: string, correct: boolean) => {
    let p = recordAttempt(progress, id, correct);
    if (isBoss && !bossSeen.has(id)) {
      setBossSeen(new Set([...bossSeen, id]));
      setBossFirst({ ...bossFirst, [id]: correct });
    }
    setProgress(p);
  };
  const onDone = (id: string) => setDoneIds(new Set([...doneIds, id]));

  const finishSection = () => {
    const key = sectionKey(idx);
    let p = { ...progress, completedSections: { ...progress.completedSections, [key]: true } };
    // ativa fichas de revisão desta fase gradualmente (proporcional às seções concluídas)
    const per = Math.ceil(phase.review.length / phase.sections.length);
    p = activateCards(p, phase.review.slice(0, per * (idx + 1)).map((c) => c.id));
    setProgress(p);
    setIdx(idx + 1);
  };

  const finishBoss = () => {
    const ids = phase.boss.exercises.map((e) => e.id);
    const hits = ids.filter((id) => bossFirst[id]).length;
    const ratio = hits / ids.length;
    const ok = ratio >= phase.boss.passRatio;
    setBossResult({ ok, ratio });
    let p = { ...progress, bossAttempts: { ...progress.bossAttempts, [phase.id]: (progress.bossAttempts[phase.id] ?? 0) + 1 } };
    if (ok) {
      p = { ...p, bossPassed: { ...p.bossPassed, [phase.id]: true }, unlockedPhase: Math.max(p.unlockedPhase, phase.num + 1), xp: p.xp + 100 };
      p = activateCards(p, phase.review.map((c) => c.id));
    }
    setProgress(p);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const retryBoss = () => { setBossFirst({}); setBossSeen(new Set()); setBossResult(null); setDoneIds(new Set()); setIdx(0); };

  const weak = isBoss && bossResult && !bossResult.ok
    ? phase.boss.exercises.filter((e) => !bossFirst[e.id]).map((e) => e.id)
    : [];

  return (
    <div className="mx-auto max-w-3xl px-4 pb-24 pt-6">
      <div className="mb-6 flex items-center justify-between gap-3">
        <button onClick={onExit} className="rounded-lg border border-slate-600 px-3 py-1.5 text-sm text-slate-300 hover:bg-slate-800">← Mapa</button>
        <div className="text-right">
          <div className="text-xs uppercase tracking-wider text-slate-400">Fase {phase.num} · {phase.emoji}</div>
          <div className="font-bold text-white">{phase.title}</div>
        </div>
      </div>

      {/* progresso dentro da fase */}
      <div className="mb-8 flex flex-wrap gap-1.5">
        {phase.sections.map((s, i) => (
          <button key={s.id} onClick={() => i <= idx || progress.completedSections[sectionKey(i)] ? setIdx(i) : null} title={s.title} className={`h-2.5 flex-1 rounded-full ${progress.completedSections[sectionKey(i)] ? 'bg-emerald-500' : i === idx ? 'bg-amber-400' : 'bg-slate-700'}`} />
        ))}
        <button title="Chefe" onClick={() => phase.sections.every((_, i) => progress.completedSections[sectionKey(i)]) && setIdx(phase.sections.length)} className={`h-2.5 w-8 rounded-full ${progress.bossPassed[phase.id] ? 'bg-emerald-500' : isBoss ? 'bg-rose-400' : 'bg-slate-700'}`} />
      </div>

      {!isBoss && section && (
        <>
          <div className="mb-2 text-sm text-amber-300">Seção {idx + 1} de {phase.sections.length}</div>
          <h1 className="mb-6 text-3xl font-bold text-white">{section.title}</h1>

          {dueReview.length > 0 && (
            <div className="mb-8 rounded-2xl border border-fuchsia-500/40 bg-fuchsia-950/20 p-5">
              <div className="mb-2 text-xs font-bold uppercase tracking-wider text-fuchsia-300">🔁 Antes de começar: lembra? (revisão de fases anteriores)</div>
              {dueReview.map((c) => <ReviewInline key={c.id} q={c.q} a={c.a} />)}
            </div>
          )}

          <Markdown text={section.body} />

          <div className="mt-10 border-t border-slate-700 pt-6">
            <h2 className="mb-1 text-xl font-bold text-white">✏️ Pratique agora</h2>
            <p className="mb-4 text-sm text-slate-400">Só é possível avançar depois de completar todos os exercícios. Errar é parte do método: leia o feedback com atenção.</p>
            {exercises.map((ex) => (
              <ExerciseView key={ex.id} ex={ex} difficulty={diff} done={!!progress.exercises[ex.id]?.done && !!doneIds.has(ex.id)} onAttempt={(c) => onAttempt(ex.id, c)} onDone={() => onDone(ex.id)} saveNote={(t) => setProgress({ ...progress, notes: { ...progress.notes, [ex.id]: t } })} savedNote={progress.notes[ex.id]} />
            ))}
          </div>

          <div className="mt-8 flex items-center justify-between">
            <button disabled={idx === 0} onClick={() => setIdx(idx - 1)} className="rounded-lg border border-slate-600 px-4 py-2 text-slate-300 disabled:opacity-30">← Seção anterior</button>
            <button disabled={!allDone} onClick={finishSection} className="rounded-xl bg-emerald-500 px-6 py-3 font-bold text-slate-900 shadow-lg shadow-emerald-900/40 hover:bg-emerald-400 disabled:opacity-30">
              {idx === phase.sections.length - 1 ? 'Enfrentar o Chefe →' : 'Próxima seção →'}
            </button>
          </div>
          {!allDone && <p className="mt-2 text-right text-xs text-slate-500">Faltam {exercises.filter((e) => !doneIds.has(e.id)).length} exercício(s).</p>}
        </>
      )}

      {isBoss && (
        <>
          <div className="mb-6 rounded-2xl border-2 border-rose-500/60 bg-gradient-to-br from-rose-950/40 to-slate-900 p-6">
            <div className="text-xs font-bold uppercase tracking-widest text-rose-300">⚔️ Chefe de fase</div>
            <h1 className="mt-1 text-3xl font-bold text-white">{phase.boss.title}</h1>
            <p className="mt-3 text-slate-200">{phase.boss.intro}</p>
            <p className="mt-2 text-sm text-slate-400">Critério: acertar na primeira tentativa pelo menos {Math.round(phase.boss.passRatio * 100)}% das {phase.boss.exercises.length} questões. Tentativas anteriores: {progress.bossAttempts[phase.id] ?? 0}.</p>
          </div>

          {bossResult ? (
            <div className={`rounded-2xl border p-6 ${bossResult.ok ? 'border-emerald-400 bg-emerald-950/30' : 'border-rose-400 bg-rose-950/30'}`}>
              <h2 className="text-2xl font-bold text-white">{bossResult.ok ? '🏆 Chefe derrotado!' : '💀 Ainda não.'}</h2>
              <p className="mt-2 text-slate-200">Acertos de primeira: {Math.round(bossResult.ratio * 100)}%.</p>
              {bossResult.ok ? (
                <>
                  <p className="mt-2 text-slate-200">Você demonstrou domínio da Fase {phase.num}. As fichas de revisão desta fase entraram no seu ciclo de repetição espaçada: elas vão reaparecer em 1, 3, 7, 14 e 30 dias. {phase.num < 7 ? 'A próxima fase está desbloqueada.' : 'Você completou o curso inteiro. Leia a última seção da Fase 7 para os próximos passos.'}</p>
                  <button onClick={onPhaseComplete} className="mt-4 rounded-xl bg-emerald-500 px-6 py-3 font-bold text-slate-900 hover:bg-emerald-400">Voltar ao mapa →</button>
                </>
              ) : (
                <>
                  <p className="mt-2 text-slate-200">Isso é normal e esperado: a pesquisa mostra que errar e corrigir fortalece a memória mais do que acertar de primeira (Butler & Roediger). Você errou de primeira em: <strong className="text-white">{weak.length}</strong> questão(ões).</p>
                  <p className="mt-2 text-slate-300">Sugestão: releia as seções abaixo e tente de novo. As respostas completas já apareceram no feedback de cada questão.</p>
                  <ul className="mt-2 list-disc pl-6 text-slate-300">{phase.sections.map((s, i) => <li key={s.id}><button className="underline hover:text-white" onClick={() => { setBossResult(null); setBossFirst({}); setBossSeen(new Set()); setIdx(i); }}>{i + 1}. {s.title}</button></li>)}</ul>
                  <button onClick={retryBoss} className="mt-4 rounded-xl bg-amber-500 px-6 py-3 font-bold text-slate-900 hover:bg-amber-400">Revisar desde o início da fase</button>
                </>
              )}
            </div>
          ) : (
            <>
              {exercises.map((ex) => (
                <ExerciseView key={ex.id + (progress.bossAttempts[phase.id] ?? 0)} ex={ex} difficulty={Math.max(1, diff)} done={doneIds.has(ex.id)} onAttempt={(c) => onAttempt(ex.id, c)} onDone={() => onDone(ex.id)} saveNote={(t) => setProgress({ ...progress, notes: { ...progress.notes, [ex.id]: t } })} savedNote={progress.notes[ex.id]} />
              ))}
              <div className="mt-8 text-right">
                <button disabled={!exercises.every((e) => doneIds.has(e.id))} onClick={finishBoss} className="rounded-xl bg-rose-500 px-6 py-3 font-bold text-white shadow-lg hover:bg-rose-400 disabled:opacity-30">Encerrar o confronto</button>
                {!exercises.every((e) => doneIds.has(e.id)) && <p className="mt-2 text-xs text-slate-500">Complete todas as questões (mesmo após errar) para encerrar.</p>}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}

function ReviewInline({ q, a }: { q: string; a: string }) {
  const [show, setShow] = useState(false);
  return (
    <div className="mb-2 rounded-lg bg-slate-900/60 p-3">
      <div className="text-slate-100">{q}</div>
      {show ? <div className="mt-1 text-sm text-emerald-200"><Markdown text={a} /></div> : <button onClick={() => setShow(true)} className="mt-1 text-xs text-fuchsia-300 underline">Tente responder de cabeça, depois clique para conferir</button>}
    </div>
  );
}
