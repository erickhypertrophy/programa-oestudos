import type { Phase } from '../lib/types';

export const phase5: Phase = {
  id: 'f5',
  num: 5,
  emoji: '➕',
  title: 'Máquinas que fazem contas',
  subtitle: 'Do meio-somador ao somador de 8 bits; números negativos sem sinal de menos; e o que acontece quando o resultado não cabe',
  goal: 'Ao final desta fase você vai ter construído um somador a partir de portas, entendido o complemento de dois (como computadores representam negativos e subtraem usando o somador), e saberá explicar overflow e por que ele causa bugs reais.',
  sections: [
    {
      id: 's1',
      title: 'Somar um bit: o meio-somador',
      body: `
## A tabela da soma de dois bits

Vamos somar dois bits, A e B. Só há quatro casos:

- 0 + 0 = 0
- 0 + 1 = 1
- 1 + 0 = 1
- 1 + 1 = 10 (em binário: "zero, e vai um")

O último caso é a chave: o resultado **precisa de dois bits**. Chamamos o bit da direita de **soma** (S) e o da esquerda de **vai-um** (C, de *carry*).

| A | B | C (vai-um) | S (soma) |
|---|---|---|---|
| 0 | 0 | 0 | 0 |
| 0 | 1 | 0 | 1 |
| 1 | 0 | 0 | 1 |
| 1 | 1 | 1 | 0 |

Agora olhe a coluna S: 0, 1, 1, 0. **É o XOR.** E a coluna C: 0, 0, 0, 1. **É o AND.**

> 💡 Você não precisou "inventar" nada. A aritmética binária de 1 bit **já era** lógica booleana. S = A XOR B. C = A AND B. Duas portas. Esse circuito se chama **meio-somador** (*half adder*).

\`\`\`
meio-somador:
  S = A XOR B
  C = A AND B
\`\`\`

[[demo:adder-1]]

## Por que "meio"?

Porque ele só soma dois bits. Mas quando somamos números de vários bits, a partir da segunda coluna precisamos somar **três** coisas: o bit de A, o bit de B e o **vai-um que veio da coluna anterior**. Veja 3 + 3 em binário:

\`\`\`
  vai-um:  1 1
      A:   0 1 1   (3)
      B:   0 1 1   (3)
          -------
      S:   1 1 0   (6)
\`\`\`

Coluna da direita: 1 + 1 = 0, vai 1. Coluna do meio: 1 + 1 + **1 (vai-um)** = 11, ou seja, 1 e vai 1. Coluna da esquerda: 0 + 0 + 1 = 1.

Então precisamos de um bloco que some **três bits** e produza soma e vai-um. Esse é o **somador completo** (*full adder*), próxima seção.

## Pausa: a importância do que acabou de acontecer

Vale respirar. Desde a Fase 0 você vem construindo: bit → números binários → lógica booleana → portas físicas. E agora, a primeira "conta" apareceu **de graça**, como consequência direta das tabelas. Isso não é coincidência: é o motivo de Boole e binário se encaixarem tão bem (lembra da Fase 0?). A soma de bits é literalmente XOR e AND.
`,
      exercises: [
        {
          type: 'truth', id: 'f5-s1-e1',
          q: 'Preencha a coluna **S (soma)** do meio-somador: o bit da direita de A + B.',
          vars: ['A', 'B'], label: 'S', fn: (v) => v[0] !== v[1],
          explain: 'S = A XOR B. 1+1 = 10, cujo bit da direita é 0.',
        },
        {
          type: 'truth', id: 'f5-s1-e2',
          q: 'Preencha a coluna **C (vai-um)** do meio-somador.',
          vars: ['A', 'B'], label: 'C', fn: (v) => v[0] && v[1],
          explain: 'C = A AND B. Só há vai-um quando ambos são 1.',
        },
        {
          type: 'circuit', id: 'f5-s1-e3',
          q: 'Construa a saída **S** do meio-somador usando **só NAND** (4 portas). Você já fez isso na Fase 4, sob outro nome.',
          inputs: ['A', 'B'], target: (v) => v[0] !== v[1], allowed: ['NAND'], maxGates: 4,
          hints: ['S é XOR. XOR com NAND: g1=NAND(A,B), g2=NAND(A,g1), g3=NAND(B,g1), g4=NAND(g2,g3).'],
          explain: 'O somador, no fundo, é NAND. Toda a aritmética do seu computador é feita com a mesma peça repetida.',
        },
        {
          type: 'mc', id: 'f5-s1-e4',
          q: 'Por que o meio-somador não basta para somar números de vários bits?',
          options: [
            { t: 'Porque ele só funciona com números pequenos.', fb: 'Não é questão de tamanho. Pense no que cada coluna, a partir da segunda, precisa somar.' },
            { t: 'Porque, a partir da segunda coluna, há três coisas a somar: os dois bits e o vai-um da coluna anterior, e o meio-somador só tem duas entradas.', ok: true, fb: 'Exato. Precisamos de um somador de três entradas: o somador completo.' },
            { t: 'Porque XOR não funciona com mais de dois bits.', fb: 'XOR funciona com qualquer número de entradas (dá 1 para número ímpar de 1s). O problema é a falta de uma entrada para o vai-um.' },
          ],
          explain: 'O vai-um encadeia as colunas: cada coluna depende da anterior. Isso vai ter consequências para a velocidade, como veremos.',
        },
      ],
    },
    {
      id: 's2',
      title: 'O somador completo e o somador de 8 bits',
      body: `
## Três bits de entrada

O somador completo recebe A, B e Cin (*carry in*, o vai-um que entra) e produz S e Cout (*carry out*, o vai-um que sai). Vamos montar a tabela contando quantos 1s há nas entradas:

| A | B | Cin | total de 1s | Cout | S |
|---|---|---|---|---|---|
| 0 | 0 | 0 | 0 | 0 | 0 |
| 0 | 0 | 1 | 1 | 0 | 1 |
| 0 | 1 | 0 | 1 | 0 | 1 |
| 0 | 1 | 1 | 2 | 1 | 0 |
| 1 | 0 | 0 | 1 | 0 | 1 |
| 1 | 0 | 1 | 2 | 1 | 0 |
| 1 | 1 | 0 | 2 | 1 | 0 |
| 1 | 1 | 1 | 3 | 1 | 1 |

A lógica: o total de 1s (0 a 3) escrito em binário com 2 bits é "Cout S". 0 → 00, 1 → 01, 2 → 10, 3 → 11.

Agora identifique os padrões:

- **S** é 1 quando o total de 1s é **ímpar** (1 ou 3). Isso é XOR de três entradas: **S = A XOR B XOR Cin**.
- **Cout** é 1 quando há **pelo menos dois** 1s. Isso é... o **detector de maioria** da Fase 3! **Cout = (A AND B) OR (A AND Cin) OR (B AND Cin)**.

Você já construiu as duas peças. Em forma de lista:

\`\`\`
somador completo:
  g1 = A XOR B
  S  = g1 XOR Cin
  g2 = A AND B
  g3 = g1 AND Cin
  Cout = g2 OR g3
\`\`\`

(Essa versão de Cout, (A∧B) ∨ ((A⊕B)∧Cin), é equivalente à de maioria e usa menos portas: confira pela tabela se quiser. É dois meio-somadores + um OR, e por isso o nome "meio": dois meios fazem um inteiro.)

## Encadeando: o somador de ondulação

Para somar dois números de 8 bits, use **8 somadores completos**, um por coluna. O Cout de cada um vira o Cin do próximo (da direita para a esquerda). O Cin da primeira coluna é 0.

\`\`\`
  A7 B7     A6 B6     A5 B5           A0 B0
   │ │       │ │       │ │             │ │
  ┌┴─┴┐ C6  ┌┴─┴┐ C5  ┌┴─┴┐    ...    ┌┴─┴┐ Cin=0
  │FA │◀────│FA │◀────│FA │◀───  ◀────│FA │◀──
  └─┬─┘     └─┬─┘     └─┬─┘           └─┬─┘
Cout S7       S6        S5              S0
\`\`\`

Esse circuito se chama **somador de ondulação** (*ripple-carry adder*), porque o vai-um "ondula" da direita para a esquerda. Ele tem um defeito: a coluna 7 só pode terminar depois que o vai-um da coluna 6 chegar, que depende da 5, e assim por diante. Para 64 bits, são 64 atrasos em sequência. Processadores reais usam truques (como o *carry-lookahead*, que calcula vai-uns em paralelo com mais portas) para acelerar. Mas o **princípio** é este, e funciona.

Teste com números reais:

[[demo:adder-8]]

## O que o somador já nos dá

Com um somador você também consegue:

- **Incrementar** (somar 1): some com 00000001. É o que faz o "contador de programa" avançar para a próxima instrução (Fase 7).
- **Multiplicar por constantes** via deslocamentos e somas: 5 × A = (4 × A) + A = (A deslocado 2 casas) + A.
- **Comparar**: A − B (veremos como subtrair na próxima seção); se o resultado é zero, são iguais; se é negativo, A < B.

Multiplicação e divisão genéricas são feitas com circuitos mais elaborados (ou com repetição de somas e deslocamentos), mas sempre a partir dessas peças.

## O preço de cada bit

Um somador completo usa cerca de 5 portas (ou ~9 NANDs). Um somador de 64 bits, ~600 NANDs. Um processador moderno tem bilhões de transistores e dezenas de somadores. Mas lembre: **cada um deles é essa tabelinha de 8 linhas, repetida.**
`,
      exercises: [
        {
          type: 'truth', id: 'f5-s2-e1',
          q: 'Preencha a coluna **S** do somador completo (A + B + Cin). Dica: S é 1 quando o número de 1s nas entradas é ímpar.',
          vars: ['A', 'B', 'Cin'], label: 'S', fn: (v) => (v[0] !== v[1]) !== v[2],
          explain: 'S = A XOR B XOR Cin: 1 para 1 ou 3 entradas ligadas.',
        },
        {
          type: 'truth', id: 'f5-s2-e2',
          q: 'Preencha a coluna **Cout** do somador completo. Dica: é o detector de maioria.',
          vars: ['A', 'B', 'Cin'], label: 'Cout', fn: (v) => (v[0] ? 1 : 0) + (v[1] ? 1 : 0) + (v[2] ? 1 : 0) >= 2,
          explain: 'Cout = maioria(A, B, Cin). Há vai-um quando pelo menos duas entradas são 1.',
        },
        {
          type: 'circuit', id: 'f5-s2-e3',
          q: 'Construa a saída **S** do somador completo: A XOR B XOR C.',
          inputs: ['A', 'B', 'C'], target: (v) => (v[0] !== v[1]) !== v[2], allowed: ['XOR', 'AND', 'OR', 'NOT'], maxGates: 2,
          hints: ['XOR(A,B), depois XOR do resultado com C.'],
          explain: 'Dois XORs em cadeia. XOR é associativo: a ordem dos parênteses não importa.',
        },
        {
          type: 'circuit', id: 'f5-s2-e4',
          q: 'Construa a saída **Cout** do somador completo: 1 quando pelo menos duas de A, B, C são 1. Use a versão econômica: (A AND B) OR ((A XOR B) AND C).',
          inputs: ['A', 'B', 'C'], target: (v) => (v[0] ? 1 : 0) + (v[1] ? 1 : 0) + (v[2] ? 1 : 0) >= 2, allowed: ['XOR', 'AND', 'OR', 'NOT'], maxGates: 5,
          hints: ['g1 = AND(A,B). g2 = XOR(A,B). g3 = AND(g2, C). Saída = OR(g1, g3).', 'Ou a versão maioria: três ANDs e dois ORs.'],
          explain: 'Você construiu um somador completo inteiro (S + Cout). Encadeie 8 e você tem o somador de um processador de 8 bits.',
        },
        {
          type: 'gen', id: 'f5-s2-g1', kind: 'addbin', count: 3,
          q: 'Some em binário à mão, coluna por coluna, da direita para a esquerda, anotando os vai-uns, exatamente como o circuito faz.',
          explain: 'Você está executando o algoritmo do somador de ondulação com a cabeça. É o mesmo que o silício faz, só que bilhões de vezes por segundo.',
        },
      ],
    },
    {
      id: 's3',
      title: 'Números negativos sem sinal de menos: complemento de dois',
      body: `
## O problema

Até agora, nossos bits só representam números de 0 para cima (**sem sinal**, *unsigned*). Mas precisamos de negativos. Onde colocar o sinal de "−"? Só temos 0 e 1.

> 🧪 **Tente antes de ler.** Com 4 bits, você tem 16 padrões. Invente um jeito de usá-los para representar números de −8 a +7 (ou −7 a +7). Pense por um minuto. Qual problema a sua ideia tem na hora de somar?

## Tentativa 1: sinal e magnitude

Ideia óbvia: usar o bit mais à esquerda como sinal (0 = positivo, 1 = negativo) e os demais como valor. Com 4 bits: 0101 = +5, 1101 = −5.

Problemas:
1. Há **dois zeros**: 0000 (+0) e 1000 (−0). Desperdício e confusão.
2. **Somar não funciona com o somador comum.** 0101 (+5) + 1101 (−5) deveria dar 0, mas o somador dá 10010 → 0010 = 2. Errado. Você precisaria de um circuito separado para subtrair, com comparação de magnitudes. Caro e lento.

## A ideia genial: deixar o somador fazer o trabalho

Pergunta: existe algum padrão de 4 bits que, **somado a 0101 (5) no somador comum**, dê 0000?

Sim! 1011. Confira: 0101 + 1011 = 10000. São 5 bits, mas só temos 4: o 1 da frente **cai fora** (é o Cout final, que ignoramos). Sobram 0000. Zero!

Então, se definirmos **1011 = −5**, a soma 5 + (−5) = 0 funciona **sem nenhum circuito novo**. O mesmo somador que soma positivos soma negativos. Essa representação se chama **complemento de dois** (*two's complement*) e é usada por todos os computadores modernos.

## Como calcular o complemento de dois de um número

Para obter −N a partir de N (com um número fixo de bits):

1. Escreva N em binário.
2. **Inverta todos os bits** (0↔1). Isso é o "complemento de um".
3. **Some 1.**

Exemplo, −5 com 4 bits: 5 = 0101 → inverte: 1010 → soma 1: **1011**. ✓ (Bate com o que achamos.)

Exemplo, −1 com 8 bits: 1 = 00000001 → inverte: 11111110 → soma 1: **11111111**. Então −1 é "tudo 1". Isso vai aparecer em programação: quando você vê 0xFFFFFFFF, frequentemente é −1.

**Por que funciona?** Inverter todos os bits de N dá (2ⁿ − 1) − N (porque "tudo 1" é 2ⁿ − 1 e subtrair N de tudo 1 é só inverter). Somando 1: 2ⁿ − N. E N + (2ⁿ − N) = 2ⁿ, que em n bits é 0 com um vai-um que cai fora. Não é truque: é aritmética modular (aritmética "de relógio", em que 12 + 1 = 1).

## Lendo um número em complemento de dois

A regra mais simples: **o bit mais à esquerda tem peso negativo**. Com 8 bits, os pesos são:

| bit | 7 | 6 | 5 | 4 | 3 | 2 | 1 | 0 |
|---|---|---|---|---|---|---|---|---|
| peso | **−128** | 64 | 32 | 16 | 8 | 4 | 2 | 1 |

Então 11111011 = −128 + 64 + 32 + 16 + 8 + 2 + 1 = −5. ✓ E 01111111 = 127 (máximo positivo). E 10000000 = −128 (mínimo).

Com 8 bits em complemento de dois, a faixa é **−128 a +127**. Note: há um negativo a mais que positivos, e um único zero. Com 32 bits: −2.147.483.648 a +2.147.483.647 (lembra do YouTube?).

[[demo:twos]]

## Consequências importantes

- **O bit mais à esquerda diz o sinal**: 1 = negativo, 0 = não negativo. Mas os outros bits NÃO são a magnitude. 1011 é −5, não −3.
- **Subtrair é somar o negativo**: A − B = A + (−B) = A + (NOT B) + 1. Então um subtrator é só um somador com inversores na entrada B e Cin = 1. O processador não tem um "circuito de subtração" separado.
- **Os mesmos bits, duas leituras**: 11111011 é 251 (sem sinal) ou −5 (com sinal). Os bits são idênticos; a diferença está em **como você interpreta**, exatamente como na Fase 2. Em programação, isso é \`unsigned char\` vs \`signed char\`, ou \`uint8\` vs \`int8\`.
- **O somador não sabe nem precisa saber** se você está usando com ou sem sinal. Ele faz os mesmos bits. Quem interpreta é você (ou o compilador).

> 📜 John von Neumann recomendou o complemento de dois no relatório do EDVAC em 1945. Antes, máquinas usavam sinal-magnitude ou complemento de um, com seus dois zeros e circuitos extras. O complemento de dois venceu porque economiza hardware.
`,
      exercises: [
        {
          type: 'input', id: 'f5-s3-e1',
          q: 'Escreva **−3** em complemento de dois com **4 bits**.',
          answer: '1101',
          hints: ['3 = 0011. Inverta todos os bits.', '1100. Agora some 1.'],
          explain: '0011 → 1100 → 1101. Confira pelos pesos: −8 + 4 + 1 = −3. ✓',
        },
        {
          type: 'input', id: 'f5-s3-e2',
          q: 'O byte **11110000** está sendo interpretado como complemento de dois (8 bits). Qual é o valor em decimal?',
          answer: '-16',
          hints: ['Pesos: −128, 64, 32, 16, 8, 4, 2, 1. Some os ligados.', '−128 + 64 + 32 + 16 = ?'],
          explain: '−128 + 64 + 32 + 16 = −16. Sem sinal, o mesmo byte seria 240. Mesmos bits, duas interpretações.',
        },
        {
          type: 'mc', id: 'f5-s3-e3',
          q: 'Por que o complemento de dois foi adotado em vez de "sinal e magnitude"?',
          options: [
            { t: 'Porque é mais fácil para humanos lerem.', fb: 'É mais difícil de ler para humanos! (1011 = −5 não é óbvio.) A vantagem é para a máquina.' },
            { t: 'Porque o mesmo somador funciona para positivos e negativos sem circuito extra, e há um único zero.', ok: true, fb: 'Exato: a subtração vira soma, e não se desperdiça o padrão do "−0".' },
            { t: 'Porque permite representar mais números.', fb: 'Ambos representam 2ⁿ padrões. O complemento de dois ganha um valor útil só por não desperdiçar o −0. A razão principal é o hardware.' },
          ],
          explain: 'Economia de hardware decidiu. É um tema recorrente: a representação "feia" para humanos costuma ser a bonita para o circuito.',
        },
        {
          type: 'gen', id: 'f5-s3-g1', kind: 'twos', count: 3,
          q: 'Converta para complemento de dois com 8 bits. Para negativos: escreva o positivo, inverta, some 1. Confira pelos pesos (−128, 64, ...).',
          explain: 'Complemento de dois dominado. Você agora lê 0xFF como −1 ou 255 conforme o contexto, como um programador experiente.',
        },
        {
          type: 'input', id: 'f5-s3-e5',
          q: 'Compute **7 − 5** usando SÓ soma em 4 bits: 0111 + (complemento de dois de 0101). Dê o resultado de 4 bits (ignore o vai-um que sai).',
          answer: '0010',
          hints: ['−5 em 4 bits é 1011.', '0111 + 1011 = 10010. Descarte o 5º bit.'],
          explain: '0111 + 1011 = 1 0010 → 0010 = 2. ✓ O somador subtraiu sem saber que estava subtraindo.',
        },
      ],
    },
    {
      id: 's4',
      title: 'Overflow: quando o resultado não cabe',
      body: `
## O ponto cego de todo número fixo

Um somador de 8 bits produz 8 bits. Se o resultado verdadeiro precisa de 9, **o bit extra se perde**. Chamamos isso de **overflow** ("transbordamento"). Não é um erro do circuito: ele fez o que podia. É uma limitação da representação, e é responsabilidade de quem usa (o programador, o compilador) detectar ou evitar.

## Overflow sem sinal

200 + 100 = 300. Em 8 bits sem sinal (máximo 255): 11001000 + 01100100 = 1 00101100. O 1 da frente cai fora. Resultado: 00101100 = **44**. O computador "acha" que 200 + 100 = 44.

Como detectar: o **Cout do último somador é 1**. Processadores têm um "sinalizador de carry" (*carry flag*) exatamente para isso, e linguagens de baixo nível permitem testá-lo.

## Overflow com sinal

Agora em complemento de dois (−128 a 127). 100 + 50 = 150, que não cabe (máximo 127):

01100100 (100) + 00110010 (50) = 10010110. Lendo com sinal: −128 + 16 + 4 + 2 = **−106**. Somamos dois positivos e deu negativo. Isso é um overflow com sinal.

Detecção: **se os dois operandos têm o mesmo sinal e o resultado tem sinal diferente, houve overflow.** (Positivo + positivo nunca deveria dar negativo; negativo + negativo nunca deveria dar positivo. Positivo + negativo nunca transborda.) Processadores têm um "sinalizador de overflow" (*overflow flag*) que calcula exatamente isso com um XOR dos vai-uns das duas últimas colunas.

> ⚠️ Note que **o mesmo padrão de bits** pode ser overflow numa interpretação e não na outra. 10010110 é um overflow para "100 + 50 com sinal", mas 150 está perfeitamente correto se os bytes são sem sinal. O circuito não sabe qual você quis. Ele levanta as duas bandeiras e você escolhe qual olhar.

## Bugs históricos causados por overflow

- **Ariane 5 (1996)**: um foguete europeu de US$ 370 milhões explodiu 37 segundos após o lançamento. Um valor de velocidade de 64 bits foi convertido para 16 bits com sinal; o valor não cabia; overflow; o sistema de navegação travou. Código reaproveitado do Ariane 4, onde a velocidade nunca chegava tão alto.
- **Gangnam Style (2014)**: o contador de visualizações do YouTube era um inteiro de 32 bits com sinal; ao passar de 2.147.483.647, mostrou negativo. O YouTube migrou para 64 bits.
- **Pac-Man (1980)**: o nível era guardado em um byte. No nível 256 (que seria 0 após overflow), uma rotina que desenhava frutas usando esse valor desenhava 256 frutas, corrompendo metade da tela. O jogo fica injogável. É o famoso "nível 256" ou *kill screen*.
- **Boeing 787 (2015)**: um contador de centésimos de segundo em 32 bits com sinal transbordava após 248 dias ligado, podendo desligar os geradores elétricos em voo. Solução temporária: reiniciar o avião antes disso.
- **Problema do ano 2038**: sistemas Unix contam segundos desde 1/1/1970 em 32 bits com sinal. Em 19 de janeiro de 2038, às 03:14:07 UTC, o contador transborda e vira 13 de dezembro de 1901. Sistemas estão migrando para 64 bits.

Em linguagens como C, overflow de inteiros com sinal é "comportamento indefinido": o compilador pode fazer qualquer coisa. Em Python, inteiros crescem sem limite (a linguagem gerencia isso por software, mais devagar). Em JavaScript, números são de ponto flutuante de 64 bits, com outros problemas. Em Rust, overflow causa erro em modo de depuração. **Toda linguagem precisa decidir o que fazer com o fato de que bits são finitos.** Agora você sabe por quê.

## Multiplicação e o resto da aritmética

Não vamos construir o multiplicador em portas (é longo), mas o princípio é o mesmo da escola: multiplicar A por cada bit de B, deslocar e somar. Como cada bit de B é 0 ou 1, "multiplicar por um bit" é só um AND. Então um multiplicador é uma pilha de ANDs e somadores. Divisão é parecida, com subtrações. Números com vírgula (ponto flutuante, o padrão IEEE 754) usam uma representação tipo notação científica em bits: um sinal, um expoente e uma mantissa. É assunto para depois, mas tudo é construído com as mesmas peças desta fase.

> 💡 O bloco que reúne somador, subtrator, operações lógicas bit a bit (AND, OR, XOR, NOT) e deslocamentos, com um seletor (MUX!) para escolher qual operação fazer, chama-se **ULA**: Unidade Lógica e Aritmética (*ALU*, *Arithmetic Logic Unit*). É o "músculo" do processador, e você já construiu todas as suas peças.
`,
      exercises: [
        {
          type: 'input', id: 'f5-s4-e1',
          q: 'Em 8 bits **sem sinal**, qual é o resultado que o somador entrega para **250 + 10**?',
          answer: '4',
          hints: ['250 + 10 = 260. O máximo em 8 bits é 255. O que acontece com o excesso?', '260 − 256 = ?'],
          explain: '260 em binário é 1 00000100; o 1 da frente cai fora, sobra 00000100 = 4. É como um relógio: depois de 255 vem 0.',
        },
        {
          type: 'mc', id: 'f5-s4-e2',
          q: 'Em 8 bits com sinal (complemento de dois), somamos **−100 + (−50)**. O resultado verdadeiro, −150, não cabe (mínimo −128). O que o somador entrega?',
          options: [
            { t: '−128, o mínimo possível.', fb: 'O somador não "satura" (não para no limite). Ele dá a volta. −150 + 256 = ?' },
            { t: '106, um número positivo.', ok: true, fb: '−150 + 256 = 106. Dois negativos somados deram positivo: overflow com sinal.' },
            { t: 'Um erro, e o programa trava.', fb: 'O circuito nunca trava: ele apenas produz os 8 bits que consegue e acende o sinalizador de overflow. Quem decide o que fazer é o software.' },
          ],
          explain: 'Detecção: mesmo sinal nos operandos, sinal diferente no resultado → overflow.',
        },
        {
          type: 'mc', id: 'f5-s4-e3',
          q: 'Um programa guarda a idade de uma pessoa em um byte **sem sinal** (0–255). O que acontece se somar 1 à idade de alguém com 255 anos?',
          options: [
            { t: 'A idade vira 256.', fb: '256 precisa de 9 bits (100000000). Em 8 bits não cabe.' },
            { t: 'A idade vira 0.', ok: true, fb: '11111111 + 1 = 1 00000000 → 00000000. Deu a volta. Esse é o mecanismo do "nível 256" do Pac-Man.' },
            { t: 'A idade continua 255.', fb: 'Isso seria "saturação", que somadores comuns não fazem. Eles dão a volta (aritmética modular).' },
          ],
          explain: 'Overflow não é exótico: acontece em contadores, idades, níveis de jogos, datas. Programadores precisam escolher tamanhos de inteiros com margem.',
        },
        {
          type: 'explain', id: 'f5-s4-e4',
          q: 'Explique a um colega por que "o computador não sabe se um byte é positivo ou negativo" e como isso se relaciona com o que você aprendeu na Fase 2.',
          keywords: [['interpret', 'convenção', 'contexto', 'como se lê', 'leitura'], ['mesmo', 'iguais', 'idêntic'], ['sinal', 'negativo', 'complemento'], ['somador', 'circuito', 'hardware', 'bits'], ['tipo', 'unsigned', 'signed', 'programa']],
          minGroups: 3,
          model: 'O byte 11111011 é só um padrão de bits. Interpretado sem sinal, vale 251; interpretado em complemento de dois, vale −5. O somador produz os mesmos bits em ambos os casos e não precisa saber a interpretação; ele apenas acende sinalizadores (carry e overflow) e deixa a decisão para o software. Isso é a mesma lição da Fase 2: bits não têm significado próprio; a convenção (o "tipo" com ou sem sinal) é que dá significado.',
        },
      ],
    },
  ],
  boss: {
    title: 'Chefe da Fase 5: O Contador de Ondulação',
    intro: 'O Contador testa se você consegue somar, subtrair e detectar transbordamentos como o circuito faz. Trabalhe coluna a coluna e confira pelos pesos.',
    passRatio: 0.8,
    exercises: [
      { type: 'input', id: 'f5-b1', q: 'Some em binário: **01101011 + 00110110** (8 bits).', answer: ['10100001'], hints: ['107 + 54 = 161.', '161 = 128 + 32 + 1.'], explain: '10100001 = 161.' },
      { type: 'input', id: 'f5-b2', q: 'Escreva **−100** em complemento de dois com 8 bits.', answer: '10011100', hints: ['100 = 01100100. Inverta: 10011011. Some 1.'], explain: '10011100. Confira: −128 + 16 + 8 + 4 = −100.' },
      { type: 'input', id: 'f5-b3', q: 'O byte **10000001**, lido em complemento de dois, vale quanto?', answer: '-127', hints: ['−128 + 1.'], explain: '−127. Sem sinal seria 129.' },
      { type: 'truth', id: 'f5-b4', q: 'Preencha **Cout** do somador completo (sem olhar).', vars: ['A', 'B', 'Cin'], label: 'Cout', fn: (v) => (v[0] ? 1 : 0) + (v[1] ? 1 : 0) + (v[2] ? 1 : 0) >= 2, explain: 'Maioria de três.' },
      {
        type: 'mc', id: 'f5-b5', q: 'Em 8 bits com sinal, **120 + 10** dá qual resultado no somador?',
        options: [{ t: '130', fb: '130 não cabe em complemento de dois de 8 bits (máximo 127). O bit 7 acende e vira negativo.' }, { t: '−126', ok: true, fb: '130 − 256 = −126. Overflow com sinal: positivo + positivo = negativo.' }, { t: '127', fb: 'Somadores não saturam; dão a volta.' }],
        explain: 'Overflow com sinal.',
      },
      {
        type: 'mc', id: 'f5-b6', q: 'Como um processador subtrai A − B usando apenas um somador?',
        options: [{ t: 'Soma A com (NOT B) e usa Cin = 1.', ok: true, fb: 'NOT B + 1 é o complemento de dois de B, ou seja, −B. A + (−B) = A − B.' }, { t: 'Inverte A e soma B.', fb: 'Isso daria (−A − 1) + B, que não é A − B.' }, { t: 'Não é possível; precisa de um circuito de subtração.', fb: 'É exatamente o que o complemento de dois evita: um circuito separado.' }],
        explain: 'Subtração = soma com B invertido e carry-in 1.',
      },
      { type: 'gen', id: 'f5-b7', kind: 'twos', count: 3, q: 'Rodada final de complemento de dois (8 bits).', explain: 'O Contador aprova.' },
      {
        type: 'explain', id: 'f5-b8', q: 'Explique por que o somador de ondulação fica mais lento quanto mais bits tem, e o que isso tem a ver com "caminho crítico".',
        keywords: [['vai-um', 'carry', 'vai um'], ['espera', 'depend', 'anterior', 'sequên', 'cadeia', 'propag'], ['atraso', 'tempo', 'lento', 'demora'], ['coluna', 'bit', 'somador']],
        minGroups: 3,
        model: 'Cada coluna do somador precisa do vai-um da coluna à direita para calcular sua soma e seu próprio vai-um. Assim, o vai-um propaga em cadeia da coluna 0 até a última, e cada etapa adiciona o atraso de algumas portas. Com 64 bits, são 64 atrasos em sequência: esse é o caminho crítico do circuito, e define o tempo mínimo de um ciclo. Por isso processadores reais usam somadores com antecipação de vai-um (carry-lookahead), que gastam mais portas para calcular os vai-uns em paralelo.',
      },
    ],
  },
  review: [
    { id: 'f5-r1', q: 'Quais portas formam o meio-somador?', a: 'S = A XOR B; C = A AND B.' },
    { id: 'f5-r2', q: 'Fórmulas do somador completo?', a: 'S = A ⊕ B ⊕ Cin; Cout = maioria(A, B, Cin) = (A∧B) ∨ (A∧Cin) ∨ (B∧Cin).' },
    { id: 'f5-r3', q: 'Como obter −N em complemento de dois?', a: 'Escreva N, inverta todos os bits, some 1.' },
    { id: 'f5-r4', q: 'Faixa de 8 bits em complemento de dois?', a: '−128 a +127.' },
    { id: 'f5-r5', q: 'Qual o peso do bit mais à esquerda em complemento de dois de 8 bits?', a: '−128 (negativo!).', answer: ['-128'] },
    { id: 'f5-r6', q: 'Como detectar overflow COM sinal?', a: 'Operandos com mesmo sinal e resultado com sinal oposto.' },
    { id: 'f5-r7', q: 'Como detectar overflow SEM sinal?', a: 'O carry-out do último somador é 1.' },
    { id: 'f5-r8', q: 'O que é a ULA (ALU)?', a: 'Unidade Lógica e Aritmética: bloco com somador, subtrator, operações lógicas e deslocamentos, com um MUX escolhendo a operação.' },
    { id: 'f5-r9', q: '−1 em 8 bits (complemento de dois) é?', a: '11111111 (0xFF).', answer: ['11111111', 'ff', '0xff'] },
  ],
  glossary: [
    { pt: 'meio-somador', en: 'half adder', def: 'Soma dois bits: S = XOR, C = AND.' },
    { pt: 'somador completo', en: 'full adder', def: 'Soma três bits (A, B, Cin) produzindo S e Cout.' },
    { pt: 'vai-um de entrada / saída', en: 'carry in (Cin) / carry out (Cout)', def: 'Vai-um que entra de uma coluna anterior / que sai para a próxima.' },
    { pt: 'somador de ondulação', en: 'ripple-carry adder', def: 'Somadores completos encadeados; o carry "ondula" da direita para a esquerda.' },
    { pt: 'antecipação de vai-um', en: 'carry-lookahead', def: 'Técnica que calcula os vai-uns em paralelo para acelerar a soma.' },
    { pt: 'sem sinal / com sinal', en: 'unsigned / signed', def: 'Interpretação de bits só como não negativos / incluindo negativos.' },
    { pt: 'complemento de dois', en: "two's complement", def: 'Representação de negativos em que −N = NOT(N) + 1; o bit mais à esquerda tem peso −2ⁿ⁻¹.' },
    { pt: 'transbordamento', en: 'overflow', def: 'Resultado que não cabe no número de bits disponível; os bits excedentes se perdem.' },
    { pt: 'sinalizador', en: 'flag', def: 'Bit de estado do processador (carry, overflow, zero, negativo) atualizado após operações.' },
    { pt: 'aritmética modular', en: 'modular arithmetic', def: 'Aritmética "de relógio": em n bits, tudo é feito módulo 2ⁿ.' },
    { pt: 'ULA', en: 'ALU (Arithmetic Logic Unit)', def: 'Bloco do processador que executa operações aritméticas e lógicas.' },
    { pt: 'ponto flutuante', en: 'floating point (IEEE 754)', def: 'Representação de números com vírgula em bits (sinal, expoente, mantissa).' },
  ],
};
