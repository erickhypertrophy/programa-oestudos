import type { Phase } from '../lib/types';

export const phase3: Phase = {
  id: 'f3',
  num: 3,
  emoji: '⚖️',
  title: 'A lógica de Boole',
  subtitle: 'E, OU, NÃO: as três operações que, combinadas, decidem qualquer coisa. Tabelas-verdade, XOR, NAND e as leis que permitem simplificar',
  goal: 'Ao final desta fase você vai raciocinar com valores verdadeiro/falso como quem faz contas, montar e ler tabelas-verdade, conhecer as operações AND, OR, NOT, XOR, NAND, NOR, e usar leis da álgebra booleana para transformar expressões.',
  sections: [
    {
      id: 's1',
      title: 'Raciocínio vira conta: as três operações',
      body: `
## Uma pergunta com duas respostas pode ser combinada com outra

Você já sabe que um bit responde uma pergunta de sim/não. Agora vamos **combinar** respostas. Considere:

- A = "está chovendo" (1 se sim, 0 se não)
- B = "estou com guarda-chuva" (1 se sim, 0 se não)

Pergunta nova: "vou me molhar?" Eu me molho se está chovendo **E** eu não tenho guarda-chuva. Isso é uma **fórmula** envolvendo A e B. Dado qualquer valor de A e B, a fórmula dá uma resposta 0 ou 1.

> 📜 Em 1847 e 1854, o matemático inglês **George Boole**, filho de sapateiro e autodidata, publicou obras mostrando que o raciocínio lógico podia ser tratado como **álgebra**: com símbolos, operações e leis, como a aritmética. Por quase um século isso foi curiosidade filosófica. Em 1937, Claude Shannon mostrou que circuitos elétricos realizam exatamente essa álgebra. Hoje ela se chama **álgebra booleana**, e todo processador do planeta é uma gigantesca expressão booleana.

Na álgebra booleana há **dois valores** (0/falso e 1/verdadeiro) e três operações básicas. Vamos defini-las com precisão, uma de cada vez, sempre com a **tabela-verdade**: uma tabela que lista *todas* as combinações de entradas e a saída de cada uma. Como as entradas são bits, a tabela é sempre finita e completa: com n entradas, tem 2ⁿ linhas (você já sabe de onde vem isso).

## NÃO (NOT): inverter

A operação mais simples. Tem **uma** entrada e devolve o contrário.

| A | NOT A |
|---|---|
| 0 | 1 |
| 1 | 0 |

Notações: NOT A, ¬A, !A (em programação), Ā (barra em cima). Lemos "não A". Se A = "está chovendo", NOT A = "não está chovendo".

## E (AND): só quando todas são verdadeiras

Duas entradas. A saída é 1 **somente se as duas** forem 1.

| A | B | A AND B |
|---|---|---|
| 0 | 0 | 0 |
| 0 | 1 | 0 |
| 1 | 0 | 0 |
| 1 | 1 | 1 |

Notações: A AND B, A ∧ B, A · B, AB, A && B (programação). Leia: "A e B".

Repare: a tabela de AND é igual à **multiplicação** de 0 e 1! 0×0=0, 0×1=0, 1×0=0, 1×1=1. Por isso a notação A·B. Pense em AND como "o mais exigente": basta um 0 para derrubar tudo.

Exemplo: "Posso dirigir" = (tenho habilitação) AND (não bebi). As duas precisam ser verdadeiras.

## OU (OR): basta uma ser verdadeira

Duas entradas. A saída é 1 se **pelo menos uma** for 1.

| A | B | A OR B |
|---|---|---|
| 0 | 0 | 0 |
| 0 | 1 | 1 |
| 1 | 0 | 1 |
| 1 | 1 | 1 |

Notações: A OR B, A ∨ B, A + B, A || B (programação). Leia: "A ou B".

> ⚠️ **Armadilha de linguagem natural**: em português, "ou" às vezes quer dizer "um ou outro, não ambos" ("você quer café ou chá?"). O OR da lógica é **inclusivo**: se ambos forem verdadeiros, o resultado é verdadeiro. "Tenho desconto se sou estudante OU idoso": quem é estudante idoso tem desconto. Para o "ou exclusivo" existe outra operação, o XOR, que veremos na próxima seção.

A notação A + B é por analogia com a soma (0+0=0, 0+1=1, 1+0=1), mas **com uma diferença crucial**: 1 + 1 = 1 em OR (não 2, nem 10). OR não é soma. É "pelo menos um".

Brinque com as três:

[[demo:gates-basic]]

## Combinando: a fórmula do guarda-chuva

"Vou me molhar" = A AND (NOT B), com A = chove, B = tenho guarda-chuva.

Vamos construir a tabela-verdade **passo a passo**. Esse método (coluna intermediária para cada subexpressão) é o jeito seguro de nunca errar:

| A (chove) | B (guarda-chuva) | NOT B | A AND (NOT B) |
|---|---|---|---|
| 0 | 0 | 1 | 0 |
| 0 | 1 | 0 | 0 |
| 1 | 0 | 1 | **1** |
| 1 | 1 | 0 | 0 |

Só me molho numa situação: chove e não tenho guarda-chuva. Faz sentido. A fórmula **captura** o raciocínio.

## Ordem das operações

Assim como na aritmética (× antes de +), na lógica booleana há precedência: **NOT primeiro, depois AND, depois OR**. Então A OR B AND C significa A OR (B AND C). Quando houver dúvida, **use parênteses**. Em programação, isso é fonte de bugs famosos; parênteses são de graça.

## Por que isso é "a base de tudo"?

Toda decisão que um programa toma ("se o usuário está logado e tem permissão, mostre o botão") é uma expressão booleana. Toda condição de \`if\`, todo \`while\`, toda busca e filtro. E, como você verá nas Fases 4 e 5, até a **soma de números** é feita com essas operações. Aprender a pensar em AND/OR/NOT é aprender a língua nativa da máquina.
`,
      exercises: [
        {
          type: 'truth', id: 'f3-s1-e1',
          q: 'Preencha a tabela-verdade de **A AND B**.',
          vars: ['A', 'B'], label: 'A AND B', fn: (v) => v[0] && v[1],
          explain: 'AND é 1 só quando todas as entradas são 1. É "o mais exigente". Equivale à multiplicação.',
        },
        {
          type: 'truth', id: 'f3-s1-e2',
          q: 'Preencha a tabela-verdade de **A OR B**. Cuidado com a última linha.',
          vars: ['A', 'B'], label: 'A OR B', fn: (v) => v[0] || v[1],
          explain: 'OR é 1 quando pelo menos uma entrada é 1, incluindo o caso em que ambas são 1 (OR é inclusivo).',
        },
        {
          type: 'truth', id: 'f3-s1-e3',
          q: 'Preencha a tabela-verdade de **(NOT A) OR B**. Dica: calcule NOT A mentalmente para cada linha antes de aplicar o OR.',
          vars: ['A', 'B'], label: '(NOT A) OR B', fn: (v) => !v[0] || v[1],
          explain: 'Essa expressão é 0 apenas quando A=1 e B=0. Ela é chamada de "implicação" (A → B, "se A então B"): a única forma de "se chove então levo guarda-chuva" ser falsa é chover e eu não levar.',
        },
        {
          type: 'mc', id: 'f3-s1-e4',
          q: 'Uma loja dá desconto se o cliente "é estudante OU tem mais de 60 anos". Maria é estudante e tem 65 anos. Pela lógica booleana, ela tem desconto?',
          options: [
            { t: 'Não, porque ela se encaixa nas duas categorias, e o "ou" exige só uma.', fb: 'Isso seria o OU exclusivo (XOR). O OR lógico é inclusivo: "pelo menos uma". Ambas verdadeiras → verdadeiro.' },
            { t: 'Sim, porque o OR é inclusivo: basta pelo menos uma condição ser verdadeira, e ambas serem verdadeiras também conta.', ok: true, fb: 'Correto. 1 OR 1 = 1.' },
            { t: 'Depende da vontade do gerente.', fb: 'Na lógica booleana não há "depende": a tabela-verdade de OR é fixa e a linha (1, 1) dá 1.' },
          ],
          explain: 'Em programação, `estudante || idoso` é verdadeiro para Maria. Confundir OR inclusivo com exclusivo é um erro de lógica clássico em código.',
        },
      ],
    },
    {
      id: 's2',
      title: 'As outras operações: XOR, NAND, NOR, e a família completa',
      body: `
## Quantas operações de 2 entradas existem?

Uma operação de 2 entradas é definida pela sua tabela-verdade, que tem 4 linhas. Cada linha pode dar 0 ou 1. Então existem 2⁴ = **16 operações possíveis** com duas entradas. Dessas, poucas têm nome e uso prático. Vamos conhecer as três que faltam.

## XOR (OU exclusivo): "diferentes?"

| A | B | A XOR B |
|---|---|---|
| 0 | 0 | 0 |
| 0 | 1 | 1 |
| 1 | 0 | 1 |
| 1 | 1 | **0** |

Notações: A XOR B, A ⊕ B, A ^ B (programação). Leia: "A ou-exclusivo B".

> 🔤 **XOR** = *eXclusive OR*, "ou exclusivo". É o "ou" do café-ou-chá: um ou outro, mas não ambos.

Três formas de enxergar o XOR, todas equivalentes e úteis:

1. **"As entradas são diferentes?"** XOR dá 1 quando A ≠ B.
2. **Soma sem vai-um**: 0+0=0, 0+1=1, 1+0=1, 1+1=0 (o "0" de "10"). Por isso XOR é a peça central do somador que construiremos na Fase 5.
3. **Inversor controlado**: A XOR 0 = A (não muda); A XOR 1 = NOT A (inverte). B funciona como um "botão de inverter".

E uma propriedade mágica: **(A XOR B) XOR B = A**. Aplicar XOR com a mesma chave duas vezes desfaz a operação. Essa propriedade é a base de criptografia simples, de detecção de erros e de muitos truques de programação.

## NAND (NÃO-E): o AND invertido

| A | B | A AND B | A NAND B |
|---|---|---|---|
| 0 | 0 | 0 | 1 |
| 0 | 1 | 0 | 1 |
| 1 | 0 | 0 | 1 |
| 1 | 1 | 1 | **0** |

NAND = NOT (A AND B). É 0 apenas quando ambas são 1. Parece uma operação boba, mas na Fase 4 você vai descobrir que **ela sozinha consegue construir todas as outras**, e que é a porta mais barata de fabricar com transistores. Por isso o curso Nand2Tetris, da Universidade Hebraica de Jerusalém, começa com ela e constrói um computador inteiro só com NANDs.

> 🔤 **NAND** = *Not AND*. **NOR** = *Not OR*.

## NOR (NÃO-OU): o OR invertido

| A | B | A OR B | A NOR B |
|---|---|---|---|
| 0 | 0 | 0 | **1** |
| 0 | 1 | 1 | 0 |
| 1 | 0 | 1 | 0 |
| 1 | 1 | 1 | 0 |

NOR = NOT (A OR B). É 1 apenas quando ambas são 0. Também é **universal** (constrói todas as outras), e será a peça da nossa primeira memória na Fase 6.

## Resumo visual

| A | B | AND | OR | XOR | NAND | NOR |
|---|---|---|---|---|---|---|
| 0 | 0 | 0 | 0 | 0 | 1 | 1 |
| 0 | 1 | 0 | 1 | 1 | 1 | 0 |
| 1 | 0 | 0 | 1 | 1 | 1 | 0 |
| 1 | 1 | 1 | 1 | 0 | 0 | 0 |

Dicas para memorizar sem decorar:

- **AND**: só a última linha é 1 ("tudo ligado").
- **OR**: só a primeira linha é 0 ("tudo desligado").
- **XOR**: as linhas do meio são 1 ("diferentes").
- **NAND** e **NOR**: inverta AND e OR.

[[demo:gates-all]]

## Com mais de duas entradas

AND e OR funcionam com qualquer número de entradas: A AND B AND C é 1 só se todas forem 1. A OR B OR C é 1 se qualquer uma for 1. XOR com 3 entradas dá 1 quando há um número **ímpar** de 1s (isso é usado para detectar erros de transmissão: o "bit de paridade").

Uma tabela com 3 entradas tem 2³ = 8 linhas. Para listar todas sem esquecer nenhuma, conte em binário de 000 a 111. Você já sabe fazer isso.
`,
      exercises: [
        {
          type: 'truth', id: 'f3-s2-e1',
          q: 'Preencha a tabela de **A XOR B**.',
          vars: ['A', 'B'], label: 'A XOR B', fn: (v) => v[0] !== v[1],
          explain: 'XOR = "são diferentes?". Note a última linha: 1 XOR 1 = 0. É a soma binária sem o vai-um.',
        },
        {
          type: 'truth', id: 'f3-s2-e2',
          q: 'Preencha a tabela de **A NAND B**.',
          vars: ['A', 'B'], label: 'A NAND B', fn: (v) => !(v[0] && v[1]),
          explain: 'NAND = NOT(AND). Só é 0 quando tudo é 1. Guarde esta tabela: na próxima fase ela vai construir todas as outras.',
        },
        {
          type: 'input', id: 'f3-s2-e3',
          q: 'Calcule: **1011 XOR 0110** (bit a bit, cada posição separadamente). Responda com 4 bits.',
          answer: '1101',
          hints: ['Compare cada coluna: se os bits são diferentes, 1; se iguais, 0.', '1≠0→1, 0≠1→1, 1=1→0, 1≠0→1.'],
          explain: '1101. XOR bit a bit é uma operação que processadores fazem em uma única instrução, e é usada em criptografia, checksums e gráficos.',
        },
        {
          type: 'input', id: 'f3-s2-e4',
          q: 'Uma mensagem **M = 1100** foi "embaralhada" com uma chave **K = 1010** fazendo C = M XOR K = 0110. Para recuperar M a partir de C, qual operação você faz? Dê o resultado de **C XOR K** (4 bits).',
          answer: '1100',
          hints: ['Aplicar XOR com a mesma chave duas vezes desfaz a operação.', '0110 XOR 1010: 0≠1→1, 1=0... cuidado: 1≠0→1, 1≠1→0, 0=0→0.'],
          explain: 'C XOR K = 0110 XOR 1010 = 1100 = M. Essa é a essência da cifra "one-time pad", a única cifra matematicamente inquebrável (se a chave for aleatória, secreta e usada uma vez só).',
        },
        {
          type: 'mc', id: 'f3-s2-e5',
          q: 'Quantas operações booleanas diferentes de 2 entradas existem no total (contando as sem nome)?',
          options: [
            { t: '4', fb: '4 é o número de LINHAS da tabela. Cada linha pode ter saída 0 ou 1. Quantas tabelas diferentes isso gera?' },
            { t: '16', ok: true, fb: '2⁴ = 16: cada uma das 4 linhas tem 2 saídas possíveis. A mesma regra da Fase 0!' },
            { t: '6 (AND, OR, NOT, XOR, NAND, NOR)', fb: 'Essas são as 6 COM NOME. Mas existem mais (ex.: "sempre 0", "sempre 1", "só A", implicação...). Conte: 4 linhas, 2 opções cada.' },
          ],
          explain: 'Você aplicou a regra 2ⁿ a um objeto novo (tabelas-verdade). Esse tipo de transferência é sinal de entendimento real.',
        },
      ],
    },
    {
      id: 's3',
      title: 'Leis da álgebra booleana: simplificar sem mudar o significado',
      body: `
## Por que leis?

Duas expressões booleanas são **equivalentes** se têm a mesma tabela-verdade. Por exemplo, A AND A é equivalente a A (confira: 0 AND 0 = 0, 1 AND 1 = 1). Isso significa que, num circuito, você pode trocar uma pela outra e **nada muda externamente**, mas uma pode ser mais barata, mais rápida ou mais clara.

Engenheiros de chips usam essas leis para reduzir milhões de portas. Programadores usam para simplificar condições de \`if\` e deixar o código legível e sem bugs. Vamos às leis mais importantes. **Para cada uma, confira ao menos uma com tabela-verdade**: isso é mais valioso que decorar.

## Leis "de identidade" e "de anulação"

| lei | AND | OR |
|---|---|---|
| identidade | A AND 1 = A | A OR 0 = A |
| anulação | A AND 0 = 0 | A OR 1 = 1 |
| idempotência | A AND A = A | A OR A = A |
| complemento | A AND (NOT A) = 0 | A OR (NOT A) = 1 |
| dupla negação | NOT (NOT A) = A | |

Interpretação: "A AND 1 = A" significa que a entrada 1 "não atrapalha" o AND (como ×1). "A OR 1 = 1" significa que um 1 "domina" o OR (basta um). "A AND (NOT A) = 0": uma coisa e seu contrário nunca são verdade ao mesmo tempo.

## Leis comutativa, associativa e distributiva

- **Comutativa**: A AND B = B AND A; A OR B = B OR A. A ordem não importa.
- **Associativa**: (A AND B) AND C = A AND (B AND C). Os parênteses entre operações iguais não importam.
- **Distributiva**: A AND (B OR C) = (A AND B) OR (A AND C). Igual à aritmética: a × (b + c) = ab + ac.
- **Distributiva "estranha"**: A OR (B AND C) = (A OR B) AND (A OR C). Essa **não** tem análogo na aritmética (a + bc ≠ (a+b)(a+c) com números), mas vale na lógica. Confira com tabela: são 8 linhas.

## Absorção

- A OR (A AND B) = A
- A AND (A OR B) = A

Exemplo humano: "Levo guarda-chuva se chove, OU se (chove E está frio)". A segunda parte é redundante: se chove, já levo. Fica só "se chove". Em código, \`if (chove || (chove && frio))\` simplifica para \`if (chove)\`.

## As leis de De Morgan: as mais importantes

> 📜 **Augustus De Morgan** (1806–1871), matemático britânico, amigo de Boole, formalizou duas regras que todo programador precisa saber de cor:

**NOT (A AND B) = (NOT A) OR (NOT B)**

**NOT (A OR B) = (NOT A) AND (NOT B)**

Em palavras: *quando você nega uma expressão com AND/OR, nega cada parte e troca AND por OR (e vice-versa).*

Exemplo humano: "Não é verdade que (sou rico E famoso)" é o mesmo que "não sou rico OU não sou famoso". E "não é verdade que (chove OU neva)" é o mesmo que "não chove E não neva".

Vamos verificar a primeira com tabela, porque esta você **precisa** acreditar:

| A | B | A AND B | NOT(A AND B) | NOT A | NOT B | (NOT A) OR (NOT B) |
|---|---|---|---|---|---|---|
| 0 | 0 | 0 | 1 | 1 | 1 | 1 |
| 0 | 1 | 0 | 1 | 1 | 0 | 1 |
| 1 | 0 | 0 | 1 | 0 | 1 | 1 |
| 1 | 1 | 1 | 0 | 0 | 0 | 0 |

As colunas 4 e 7 são idênticas. Equivalentes. ✓

Por que isso importa tanto?

1. **Em programação**: \`!(a && b)\` é \`!a || !b\`. Iniciantes erram isso o tempo todo, escrevendo \`!a && !b\` (que significa outra coisa).
2. **Em hardware**: De Morgan diz que NAND = (NOT A) OR (NOT B). Então um OR pode ser feito com um NAND e dois NOTs. Isso é o começo da prova de que NAND é universal (Fase 4).

## Um exemplo completo de simplificação

Expressão: (A AND B) OR (A AND (NOT B)).

1. Distributiva ao contrário (colocar A em evidência): A AND (B OR (NOT B)).
2. Complemento: B OR (NOT B) = 1.
3. Identidade: A AND 1 = A.

Resultado: **A**. A expressão inteira, que parecia precisar de 3 portas, é só o fio A. Confira na tabela: para A=1, qualquer B dá 1; para A=0, dá 0. ✓

> 💡 Simplificar não é "truque": é descobrir que duas descrições diferentes falam da **mesma** função. A tabela-verdade é o juiz final. Sempre que duvidar, monte a tabela.
`,
      exercises: [
        {
          type: 'mc', id: 'f3-s3-e1',
          q: 'Pela lei de De Morgan, **NOT (A OR B)** é equivalente a:',
          options: [
            { t: '(NOT A) OR (NOT B)', fb: 'Quase: você negou as partes, mas esqueceu de TROCAR o operador. OR vira AND.' },
            { t: '(NOT A) AND (NOT B)', ok: true, fb: 'Correto: nega cada parte e troca OR por AND. "Nem A nem B" = "não A e não B".' },
            { t: 'NOT A OR B', fb: 'Isso nega só o A. A negação de fora se aplica à expressão inteira.' },
          ],
          explain: '"Não (chove ou neva)" = "não chove E não neva". Em código: `!(a || b)` ≡ `!a && !b`.',
        },
        {
          type: 'truth', id: 'f3-s3-e2',
          q: 'Verifique a segunda lei de De Morgan preenchendo a tabela de **(NOT A) AND (NOT B)**. Depois compare mentalmente com NOT(A OR B): só a primeira linha deve ser 1.',
          vars: ['A', 'B'], label: '(NOT A) AND (NOT B)', fn: (v) => !v[0] && !v[1],
          explain: 'Só a linha (0,0) dá 1: é exatamente a tabela do NOR = NOT(A OR B). De Morgan confirmado pela tabela.',
        },
        {
          type: 'mc', id: 'f3-s3-e3',
          q: 'Simplifique: **A OR (A AND B)**.',
          options: [
            { t: 'A', ok: true, fb: 'Lei da absorção. Se A é 1, o OR já dá 1; se A é 0, (A AND B) também é 0, então dá 0. O resultado é sempre igual a A.' },
            { t: 'B', fb: 'Teste A=0, B=1: a expressão dá 0 OR (0 AND 1) = 0, mas B = 1. Não é equivalente a B.' },
            { t: 'A AND B', fb: 'Teste A=1, B=0: a expressão dá 1 OR 0 = 1, mas A AND B = 0. Não é equivalente.' },
          ],
          explain: 'Testar com valores concretos (como fiz nos feedbacks) é a forma mais rápida de refutar uma equivalência errada. Para PROVAR a equivalência, a tabela completa.',
        },
        {
          type: 'mc', id: 'f3-s3-e4',
          q: 'Em um programa há a condição `if (!(logado && admin))`. Qual reescrita é EQUIVALENTE?',
          options: [
            { t: 'if (!logado && !admin)', fb: 'Erro clássico! Isso é "não logado E não admin", que é diferente. Aplique De Morgan: nega cada parte E troca && por ||.' },
            { t: 'if (!logado || !admin)', ok: true, fb: 'De Morgan correto: "não é (logado e admin)" = "não logado OU não admin".' },
            { t: 'if (logado || admin)', fb: 'Você esqueceu de negar as partes. A negação externa tem que entrar em cada termo.' },
          ],
          explain: 'Esse erro (trocar `!(a && b)` por `!a && !b`) aparece em código de produção o tempo todo. Você já está imune.',
        },
        {
          type: 'explain', id: 'f3-s3-e5',
          q: 'Explique, com suas palavras e um exemplo do dia a dia, a lei de De Morgan NOT(A AND B) = (NOT A) OR (NOT B).',
          keywords: [['nega', 'não', 'contrário', 'inverte'], ['troca', 'vira', 'muda'], ['ou', 'or'], ['e ', 'and'], ['exemplo', 'por exemplo', 'se ', 'quando']],
          minGroups: 3,
          model: 'Negar uma afirmação do tipo "A e B" dá o mesmo que dizer "não A ou não B": basta que uma das partes falhe para a conjunção ser falsa. Exemplo: "não é verdade que estou rico e famoso" significa "ou não estou rico, ou não estou famoso" (ou nenhum dos dois). A regra prática: ao negar, nega-se cada parte e troca-se E por OU (e OU por E).',
        },
      ],
    },
    {
      id: 's4',
      title: 'Da tabela à fórmula: qualquer função booleana pode ser escrita com AND, OR, NOT',
      body: `
## O teorema que sustenta o computador

Aqui vai um resultado que parece modesto e é, na verdade, um dos pilares de tudo: **dada qualquer tabela-verdade, com qualquer número de entradas, existe uma expressão usando apenas AND, OR e NOT que a reproduz exatamente.**

Isso significa que, se você conseguir construir fisicamente AND, OR e NOT (Fase 4), você consegue construir **qualquer** função de bits que conseguir especificar. Qualquer. Soma, multiplicação, comparação, decodificação de instruções, controle de um foguete. Tudo é tabela-verdade; toda tabela-verdade vira AND/OR/NOT.

E a prova é um método, que você vai aprender agora. Chama-se **forma normal disjuntiva** (ou "soma de produtos").

## O método, passo a passo

Suponha que alguém te dá esta tabela misteriosa e pede uma fórmula:

| A | B | C | saída |
|---|---|---|---|
| 0 | 0 | 0 | 0 |
| 0 | 0 | 1 | 1 |
| 0 | 1 | 0 | 0 |
| 0 | 1 | 1 | 0 |
| 1 | 0 | 0 | 1 |
| 1 | 0 | 1 | 0 |
| 1 | 1 | 0 | 0 |
| 1 | 1 | 1 | 1 |

**Passo 1**: olhe só para as linhas em que a saída é **1**. Aqui: linha 2 (001), linha 5 (100), linha 8 (111).

**Passo 2**: para cada uma dessas linhas, escreva um termo AND que seja verdadeiro **exatamente** naquela linha. A regra: variável com valor 1 entra direto; variável com valor 0 entra negada.

- Linha 001: (NOT A) AND (NOT B) AND C
- Linha 100: A AND (NOT B) AND (NOT C)
- Linha 111: A AND B AND C

Confira o primeiro termo: ele dá 1 só se A=0, B=0, C=1. Em qualquer outra linha, pelo menos um fator é 0 e o AND derruba tudo. ✓

**Passo 3**: junte todos os termos com OR.

saída = [(NOT A) AND (NOT B) AND C] OR [A AND (NOT B) AND (NOT C)] OR [A AND B AND C]

Pronto. Essa expressão dá 1 exatamente nas três linhas certas (porque em cada uma, um dos termos "acende") e 0 em todas as outras (porque nenhum termo acende). **Funciona para qualquer tabela.**

## Por que isso é uma prova

O método não depende da tabela ser "bonita". Para qualquer tabela com n entradas:

- cada linha com saída 1 vira um termo AND de n fatores (cada variável, direta ou negada);
- os termos se juntam com OR.

Como há um número finito de linhas, a expressão é finita. Logo, **toda função booleana é expressável com AND, OR e NOT**. Dizemos que {AND, OR, NOT} é um conjunto **funcionalmente completo**.

> 💡 Na Fase 4 vamos dar um passo a mais: mostrar que NAND sozinho constrói AND, OR e NOT. Juntando com o teorema desta seção: **NAND sozinho constrói qualquer função booleana**, e portanto qualquer computador. É exatamente a tese do Nand2Tetris.

## A expressão pode ser enorme; e daí?

A forma normal costuma ser grande e redundante. Para a tabela acima, não dá para simplificar muito. Mas para outras, as leis da seção anterior reduzem drasticamente. Existem técnicas sistemáticas (mapas de Karnaugh, algoritmo de Quine–McCluskey) e programas que fazem isso automaticamente para chips com bilhões de portas. **O ponto aqui não é eficiência: é possibilidade.** Primeiro mostramos que dá; depois otimizamos.

Esse é, aliás, um padrão de pensamento que você vai levar para a programação: **primeiro faça funcionar, depois faça rápido**.

## Um exemplo útil: o detector de maioria

Três sensores (A, B, C) votam. Queremos saída 1 quando a **maioria** (dois ou mais) está em 1. A tabela tem 1 nas linhas 011, 101, 110, 111. Pelo método:

maioria = (¬A∧B∧C) ∨ (A∧¬B∧C) ∨ (A∧B∧¬C) ∨ (A∧B∧C)

Com as leis (absorção e distributiva), isso simplifica para:

maioria = (A∧B) ∨ (A∧C) ∨ (B∧C)

Ou seja: "algum par está ligado". Muito mais legível, e é um circuito que aparece em naves espaciais (votação de computadores redundantes) e... no somador da Fase 5, para calcular o vai-um!
`,
      exercises: [
        {
          type: 'mc', id: 'f3-s4-e1',
          q: 'No método "soma de produtos", para a linha da tabela em que A=1, B=0, C=0 tem saída 1, qual é o termo AND correspondente?',
          options: [
            { t: 'A AND B AND C', fb: 'Esse termo acende só quando todas são 1, mas queremos acender quando A=1, B=0, C=0. Variáveis com valor 0 precisam entrar negadas.' },
            { t: 'A AND (NOT B) AND (NOT C)', ok: true, fb: 'Correto: A direta (valor 1), B e C negadas (valor 0). Esse termo é 1 exatamente nessa linha.' },
            { t: '(NOT A) AND B AND C', fb: 'Você inverteu tudo. A=1 entra direta; B=0 e C=0 entram negadas.' },
          ],
          explain: 'A regra: valor 1 → variável direta; valor 0 → variável negada. O AND de todas só acende naquela combinação exata.',
        },
        {
          type: 'truth', id: 'f3-s4-e2',
          q: 'Preencha a tabela do **detector de maioria** de 3 entradas: saída 1 quando pelo menos duas entradas são 1.',
          vars: ['A', 'B', 'C'], label: 'maioria', fn: (v) => (v[0] ? 1 : 0) + (v[1] ? 1 : 0) + (v[2] ? 1 : 0) >= 2,
          explain: 'Quatro linhas dão 1: 011, 101, 110, 111. Essa função, (A∧B)∨(A∧C)∨(B∧C), será o "vai-um" do somador completo na Fase 5.',
        },
        {
          type: 'mc', id: 'f3-s4-e3',
          q: 'Por que o fato de "toda tabela-verdade pode ser escrita com AND, OR e NOT" é tão importante para construir computadores?',
          options: [
            { t: 'Porque assim os computadores ficam mais rápidos.', fb: 'Não é sobre velocidade. É sobre POSSIBILIDADE. Pense: o que você precisa construir fisicamente para construir qualquer função?' },
            { t: 'Porque garante que, se conseguirmos construir fisicamente só três tipos de componente (AND, OR, NOT), conseguimos construir qualquer função de bits que especificarmos.', ok: true, fb: 'Exato. Reduz o problema "construir um computador" ao problema "construir três peças".' },
            { t: 'Porque AND, OR e NOT são as únicas operações que existem.', fb: 'Existem 16 operações de 2 entradas (você calculou). O ponto é que três delas BASTAM para gerar todas.' },
          ],
          explain: 'Chamamos {AND, OR, NOT} de conjunto "funcionalmente completo". Na próxima fase, reduziremos para um único componente: NAND.',
        },
        {
          type: 'explain', id: 'f3-s4-e4',
          q: 'Descreva o método para transformar qualquer tabela-verdade em uma fórmula com AND, OR e NOT. (Quais linhas você olha? O que faz com cada uma? Como junta?)',
          keywords: [['linha', 'linhas'], ['1', 'um', 'verdadeir'], ['and', 'e ', '∧', 'produto'], ['or', 'ou', '∨', 'soma'], ['nega', 'not', 'invert', 'zero', '0']],
          minGroups: 4,
          model: 'Olho apenas as linhas em que a saída é 1. Para cada uma, escrevo um termo AND com todas as variáveis: as que valem 1 entram diretas, as que valem 0 entram negadas (NOT). Esse termo só é verdadeiro naquela linha específica. Depois junto todos os termos com OR. A expressão resultante é 1 exatamente nas linhas desejadas e 0 nas demais, para qualquer tabela.',
        },
      ],
    },
  ],
  boss: {
    title: 'Chefe da Fase 3: O Juiz das Tabelas',
    intro: 'O Juiz só aceita respostas que a tabela-verdade confirma. Quando duvidar, monte a tabela mentalmente, linha por linha. Nada de intuição de linguagem natural: o "ou" aqui é o OR lógico.',
    passRatio: 0.8,
    exercises: [
      { type: 'truth', id: 'f3-b1', q: 'Preencha **A NOR B**.', vars: ['A', 'B'], label: 'A NOR B', fn: (v) => !(v[0] || v[1]), explain: 'Só (0,0) dá 1.' },
      { type: 'truth', id: 'f3-b2', q: 'Preencha **(A XOR B) AND C** (3 entradas).', vars: ['A', 'B', 'C'], label: '(A XOR B) AND C', fn: (v) => (v[0] !== v[1]) && v[2], explain: 'Acende quando A e B diferem E C está ligado: linhas 011 e 101.' },
      {
        type: 'mc', id: 'f3-b3', q: 'Qual expressão é equivalente a **NOT(NOT A AND B)**?',
        options: [{ t: 'A OR (NOT B)', ok: true, fb: 'De Morgan: NOT(X AND Y) = NOT X OR NOT Y, com X = NOT A (cuja negação é A) e Y = B.' }, { t: 'A AND (NOT B)', fb: 'De Morgan troca AND por OR ao negar.' }, { t: '(NOT A) OR B', fb: 'Você esqueceu de negar as partes: NOT(NOT A) = A, e NOT B.' }],
        explain: 'Dupla negação + De Morgan.',
      },
      { type: 'input', id: 'f3-b4', q: 'Calcule bit a bit: **1100 AND 1010**. (4 bits)', answer: '1000', hints: ['Coluna a coluna: 1·1=1, 1·0=0, 0·1=0, 0·0=0.'], explain: '1000. AND bit a bit é usado como "máscara" para isolar bits específicos.' },
      { type: 'input', id: 'f3-b5', q: 'Calcule bit a bit: **1100 OR 1010**. (4 bits)', answer: '1110', hints: ['Basta um 1 por coluna.'], explain: '1110. OR bit a bit é usado para "ligar" bits específicos.' },
      { type: 'input', id: 'f3-b6', q: 'Calcule bit a bit: **1100 XOR 1010**. (4 bits)', answer: '0110', hints: ['1 onde os bits diferem.'], explain: '0110. XOR bit a bit é usado para "inverter" bits específicos.' },
      {
        type: 'mc', id: 'f3-b7', q: 'Simplifique: **(A AND B) OR (A AND NOT B) OR (NOT A AND B)**.',
        options: [{ t: 'A OR B', ok: true, fb: 'Os dois primeiros termos somam A (absorvendo B). O terceiro adiciona o caso A=0,B=1. Juntos: tudo menos (0,0) = A OR B.' }, { t: 'A XOR B', fb: 'Teste A=1, B=1: a expressão dá 1 (primeiro termo), mas XOR dá 0.' }, { t: 'A', fb: 'Teste A=0, B=1: o terceiro termo dá 1, mas A = 0.' }],
        explain: 'Quando em dúvida, teste linhas concretas da tabela: refuta rápido.',
      },
      {
        type: 'mc', id: 'f3-b8', q: 'Uma tabela-verdade de 3 entradas tem saída 1 em exatamente duas linhas. Quantos termos AND terá a fórmula "soma de produtos" e quantos fatores cada termo?',
        options: [{ t: '2 termos, cada um com 3 fatores', ok: true, fb: 'Um termo por linha com saída 1; cada termo inclui todas as 3 variáveis (diretas ou negadas).' }, { t: '3 termos, cada um com 2 fatores', fb: 'Invertido: o número de termos vem das linhas com 1; o número de fatores, do número de variáveis.' }, { t: '8 termos', fb: '8 é o total de linhas. Só as linhas com saída 1 geram termos.' }],
        explain: 'Método da forma normal disjuntiva.',
      },
    ],
  },
  review: [
    { id: 'f3-r1', q: 'Tabela-verdade do AND: quando dá 1?', a: 'Só quando TODAS as entradas são 1 (1·1 = 1).' },
    { id: 'f3-r2', q: 'Tabela-verdade do OR: quando dá 0?', a: 'Só quando TODAS as entradas são 0. É inclusivo: 1 OR 1 = 1.' },
    { id: 'f3-r3', q: 'O que é XOR e qual sua relação com a soma?', a: '"Ou exclusivo": 1 quando as entradas são diferentes. É a soma binária sem o vai-um (1+1=0).' },
    { id: 'f3-r4', q: 'Enuncie as duas leis de De Morgan.', a: 'NOT(A AND B) = NOT A OR NOT B; NOT(A OR B) = NOT A AND NOT B. Nega as partes e troca o operador.' },
    { id: 'f3-r5', q: 'O que significa dizer que {AND, OR, NOT} é "funcionalmente completo"?', a: 'Qualquer tabela-verdade pode ser escrita usando só essas três operações (método soma de produtos).' },
    { id: 'f3-r6', q: 'Quantas linhas tem uma tabela-verdade com 3 entradas?', a: '2³ = 8.', answer: '8' },
    { id: 'f3-r7', q: 'O que é NAND e por que importa?', a: 'NOT(A AND B). É universal (constrói todas as outras) e barata em transistores.' },
    { id: 'f3-r8', q: '(A XOR B) XOR B = ?', a: 'A. XOR com a mesma chave duas vezes desfaz a operação.', answer: ['a'] },
  ],
  glossary: [
    { pt: 'álgebra booleana', en: 'Boolean algebra', def: 'Sistema matemático com valores 0/1 e operações AND, OR, NOT.', origin: 'George Boole (1815–1864), "An Investigation of the Laws of Thought", 1854.' },
    { pt: 'tabela-verdade', en: 'truth table', def: 'Lista de todas as combinações de entradas com a saída correspondente. 2ⁿ linhas para n entradas.' },
    { pt: 'E', en: 'AND (∧, ·, &&)', def: '1 só se todas as entradas são 1.' },
    { pt: 'OU', en: 'OR (∨, +, ||)', def: '1 se pelo menos uma entrada é 1 (inclusivo).' },
    { pt: 'NÃO', en: 'NOT (¬, !, ~)', def: 'Inverte: 0↔1.' },
    { pt: 'OU-exclusivo', en: 'XOR (⊕, ^)', def: '1 se as entradas são diferentes.', origin: '*eXclusive OR*.' },
    { pt: 'NÃO-E', en: 'NAND', def: 'NOT(A AND B). Porta universal.' },
    { pt: 'NÃO-OU', en: 'NOR', def: 'NOT(A OR B). Também universal.' },
    { pt: 'leis de De Morgan', en: "De Morgan's laws", def: 'NOT(A∧B) = ¬A∨¬B; NOT(A∨B) = ¬A∧¬B.', origin: 'Augustus De Morgan, séc. XIX.' },
    { pt: 'soma de produtos / forma normal disjuntiva', en: 'sum of products / DNF', def: 'Método para escrever qualquer tabela-verdade como OR de termos AND.' },
    { pt: 'funcionalmente completo', en: 'functionally complete', def: 'Conjunto de operações capaz de expressar qualquer função booleana.' },
    { pt: 'máscara de bits', en: 'bitmask', def: 'Uso de AND/OR/XOR bit a bit para isolar, ligar ou inverter bits específicos.' },
  ],
};
