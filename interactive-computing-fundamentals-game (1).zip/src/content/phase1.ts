import type { Phase } from '../lib/types';

export const phase1: Phase = {
  id: 'f1',
  num: 1,
  emoji: '🔢',
  title: 'Contar com dois dedos',
  subtitle: 'O sistema binário: como escrever qualquer número usando só 0 e 1, e por que isso é a mesma coisa que você já faz com dez algarismos',
  goal: 'Ao final desta fase você vai converter números entre decimal e binário com segurança, entender por que o sistema funciona (não só o "como"), contar em binário e reconhecer os padrões que todo programador conhece de cor.',
  sections: [
    {
      id: 's1',
      title: 'Você já sabe mais do que pensa: como o decimal funciona de verdade',
      body: `
## Desmontando o número 347

Você escreve "347" desde criança. Mas o que isso significa *exatamente*? Não é "três, quatro, sete". É:

**3 centenas + 4 dezenas + 7 unidades** = 3 × 100 + 4 × 10 + 7 × 1 = 347.

Repare na estrutura. Cada **posição** tem um **peso**:

| posição | 3ª (centenas) | 2ª (dezenas) | 1ª (unidades) |
|---|---|---|---|
| peso | 100 | 10 | 1 |
| algarismo | 3 | 4 | 7 |
| contribuição | 300 | 40 | 7 |

E de onde vêm os pesos 1, 10, 100? São **potências de 10**: 10⁰ = 1, 10¹ = 10, 10² = 100, 10³ = 1.000. Cada posição vale **dez vezes** a posição à direita.

Por que dez? Porque temos **dez algarismos** (0 a 9). Quando a posição das unidades chega em 9 e precisamos contar mais um, não há algarismo maior: zeramos a posição e "vai um" para a posição da esquerda. 9 → 10. 19 → 20. 99 → 100.

> 💡 Esse sistema se chama **notação posicional**: o valor de um algarismo depende da posição onde ele está. O "3" em 347 vale 300, mas o "3" em 473 vale só 3. Parece óbvio, mas levou milênios para a humanidade inventar isso. Os romanos não tinham: em "XXX", cada X vale 10, não importa onde esteja. Tente multiplicar DCCXLVII por XXIV em algarismos romanos e você entenderá por que a notação posicional foi uma revolução.

> 📜 A notação posicional com zero veio da Índia (por volta do século V) e chegou à Europa via matemáticos árabes, em especial **al-Khwarizmi** (~820 d.C.), cujo nome deu origem à palavra **algoritmo**. O título de um livro dele deu origem à palavra **álgebra**. Então sim: as palavras "algoritmo" e "álgebra" vêm de um matemático persa que escrevia sobre como fazer contas com o sistema posicional.

## A pergunta que muda tudo

Se o decimal usa dez algarismos e pesos que são potências de dez... **o que aconteceria se usássemos só dois algarismos?**

A resposta é: o sistema funciona exatamente igual, só que:

- os únicos algarismos são **0 e 1**;
- os pesos são **potências de 2**: 1, 2, 4, 8, 16, 32, 64, 128...;
- cada posição vale **o dobro** da posição à direita;
- quando uma posição chega em 1 e precisamos contar mais um, zeramos e "vai um".

Isso é o **sistema binário**. Ele não é uma invenção estranha de computadores. É o mesmo sistema que você usa, com um "estoque" menor de algarismos.

## Lendo um número binário

Vamos ler **1011** (binário). Primeiro, colocamos os pesos embaixo, da direita para a esquerda:

| posição | 4ª | 3ª | 2ª | 1ª |
|---|---|---|---|---|
| peso | 8 | 4 | 2 | 1 |
| algarismo | 1 | 0 | 1 | 1 |
| contribuição | 8 | 0 | 2 | 1 |

Soma: 8 + 0 + 2 + 1 = **11**.

Então 1011 em binário é 11 em decimal. Note que escrevemos "1011" e não "mil e onze": em binário, é melhor ler "um-zero-um-um".

> ⚠️ Ambiguidade! "10" pode ser dez (decimal) ou dois (binário). Quando houver risco de confusão, programadores escrevem o prefixo **0b** para binário: 0b10 = dois. E, em textos, usamos um subscrito: 10₂ = 2₁₀. Neste curso, vou sempre dizer qual é qual.

## Por que a posição mais à direita vale 1?

Em qualquer base, a primeira posição vale base⁰ = 1. "Qualquer número elevado a zero é 1" é uma daquelas regras que parecem arbitrárias, mas há uma lógica: ao avançar uma casa para a esquerda, multiplicamos por 2 (ou 10). Então, ao recuar uma casa para a direita, **dividimos** por 2. Se 2¹ = 2, recuando uma casa temos 2 ÷ 2 = 1 = 2⁰. Faz sentido, não é uma regra "porque sim".

Brinque com o contador abaixo. Ligue os bits e observe os pesos sendo somados.

[[demo:counter-4]]
`,
      exercises: [
        {
          type: 'input', id: 'f1-s1-e1',
          q: 'No número decimal **5.820**, quanto vale a contribuição do algarismo **8**? (Pense em posição × peso.)',
          answer: '800',
          hints: ['O 8 está na terceira posição a partir da direita (unidades, dezenas, centenas).', 'Centenas têm peso 100. 8 × 100 = ?'],
          explain: 'Notação posicional: o 8 na casa das centenas vale 8 × 100 = 800. O mesmo raciocínio (algarismo × peso da posição) é tudo o que você precisa para o binário.',
        },
        {
          type: 'input', id: 'f1-s1-e2',
          q: 'Converta o binário **0110** para decimal. Monte a tabelinha de pesos (8, 4, 2, 1) antes de responder.',
          answer: '6',
          hints: ['Pesos da esquerda para a direita: 8, 4, 2, 1. Quais estão ligados (têm 1)?', 'Estão ligados o 4 e o 2. Some.'],
          explain: '0×8 + 1×4 + 1×2 + 0×1 = 6. O zero à esquerda não muda nada, assim como 0347 = 347.',
        },
        {
          type: 'bits', id: 'f1-s1-e3',
          q: 'Ligue os bits certos para formar o número **13**. Dica: comece pelo maior peso que "cabe" em 13.',
          nbits: 4, target: 13,
          hints: ['O maior peso que cabe em 13 é 8. Ligue-o. Faltam 13 − 8 = 5.', 'Com 5 faltando: 4 cabe. Faltam 1. Ligue o 1.', '13 = 8 + 4 + 1 → 1101.'],
          explain: '13 = 8 + 4 + 1 = 1101₂. A estratégia "pegue o maior peso que cabe, subtraia, repita" sempre funciona e é chamada de método guloso.',
        },
        {
          type: 'mc', id: 'f1-s1-e4',
          q: 'Em binário, por que a posição imediatamente à esquerda das unidades vale 2 (e não 10)?',
          options: [
            { t: 'Porque computadores foram programados assim.', fb: 'Não é uma convenção arbitrária de computadores: segue da estrutura da notação posicional. Pense: o que acontece quando os algarismos "acabam"?' },
            { t: 'Porque, com só dois algarismos (0 e 1), a primeira posição "estoura" após contar 2 valores, e aí precisamos de uma nova posição que represente "um grupo de 2".', ok: true, fb: 'Exatamente. Em decimal, a posição estoura após 10 valores e a próxima vale 10. Em binário, estoura após 2 e a próxima vale 2.' },
            { t: 'Porque 2 é a metade de 4.', fb: 'Isso é verdade, mas é consequência, não causa. A causa é o número de algarismos disponíveis.' },
          ],
          explain: 'Regra geral: numa base B, a posição n (contando do zero, da direita) vale Bⁿ. Em base 10: 1, 10, 100... Em base 2: 1, 2, 4, 8...',
        },
      ],
    },
    {
      id: 's2',
      title: 'Contando em binário: o "vai um" acontece o tempo todo',
      body: `
## Vamos contar de 0 a 15

Em decimal, quando você conta, a casa das unidades gira 0,1,2,...,9 e só então a dezena avança. Em binário, a casa das unidades gira 0, 1 e **já** estoura. Veja:

| decimal | binário (4 bits) | o que aconteceu |
|---|---|---|
| 0 | 0000 | começo |
| 1 | 0001 | unidade vira 1 |
| 2 | 0010 | unidade estoura (1+1), vai um: a casa do 2 vira 1 |
| 3 | 0011 | unidade vira 1 de novo |
| 4 | 0100 | unidade estoura, vai um para a casa do 2, que também estoura, vai um para a casa do 4 |
| 5 | 0101 | |
| 6 | 0110 | |
| 7 | 0111 | três casas cheias |
| 8 | 1000 | todas estouram em cascata: só a casa do 8 fica ligada |
| 9 | 1001 | |
| 10 | 1010 | |
| 11 | 1011 | |
| 12 | 1100 | |
| 13 | 1101 | |
| 14 | 1110 | |
| 15 | 1111 | máximo com 4 bits |

Leia essa tabela em voz alta uma vez. Depois, olhe só a coluna do binário e observe os **padrões**:

- A última coluna (peso 1) alterna: 0,1,0,1,0,1... Todo número **ímpar termina em 1** e todo **par termina em 0**. Isso é importante: para saber se um número binário é par, basta olhar o último bit.
- A penúltima coluna (peso 2) alterna de 2 em 2: 00,11,00,11...
- A próxima (peso 4) alterna de 4 em 4. A do 8, de 8 em 8.
- O número 7 é 0111 e o 8 é 1000: todos os bits "viram" de uma vez. É o mesmo que 999 → 1000 em decimal.
- Quando todos os n bits estão em 1, o valor é **2ⁿ − 1**: 1111 = 15 = 16 − 1. Com 8 bits, 11111111 = 255 = 256 − 1.

> 💡 Esse último ponto responde uma dúvida comum: "por que 8 bits vão até 255 e não até 256?" Porque o zero também é um valor! De 0 a 255 há exatamente 256 valores. Esse "erro de um" (começar a contar do zero) vai te perseguir em programação, onde listas também começam no índice 0. Melhor fazer as pazes com ele agora.

Use o contador de 8 bits e aperte "+1" repetidamente. Observe a cascata de "vai um".

[[demo:counter-8]]

## Contando nos dedos até 1023

Com uma mão você conta até 5, certo? Só se cada dedo valer 1. Se cada dedo for um **bit** (abaixado = 0, levantado = 1), com os pesos 1, 2, 4, 8, 16 do polegar ao mindinho, você conta de 0 a 31 numa mão só. Com as duas mãos: 10 bits, de 0 a 1.023.

Tente agora, de verdade, com a mão: mostre 5 (polegar + dedo médio: 1 + 4). Mostre 10 (indicador + anelar: 2 + 8). Mostre 31 (todos). O corpo ajuda a memória.

## O tamanho dos números cresce devagar

Um ponto que surpreende iniciantes: números binários são **longos**. 255 em decimal tem 3 algarismos; em binário, 8. Um milhão tem 7 algarismos em decimal e 20 em binário.

A regra aproximada: cada algarismo decimal "custa" cerca de 3,3 bits. Por isso os computadores precisam de muitos bits, mas não é um problema: bits são baratíssimos. Um chip de memória comum tem dezenas de bilhões deles.

A pergunta inversa é mais útil: **quantos bits preciso para representar números até N?** É a mesma pergunta da Fase 0: o menor n tal que 2ⁿ > N. Para contar até 1.000, 10 bits (1.024). Para contar até 1 milhão, 20 bits (1.048.576). Para contar até 4 bilhões, 32 bits.
`,
      exercises: [
        {
          type: 'input', id: 'f1-s2-e1',
          q: 'Qual é o número binário que vem logo DEPOIS de **0111**? (Responda com 4 bits.)',
          answer: ['1000', '1000'],
          hints: ['0111 é 7. O próximo é 8.', 'Quando todas as casas da direita estão em 1 e você soma 1, todas viram 0 e a próxima casa vira 1 (como 999 + 1 = 1000).'],
          explain: '0111 + 1 = 1000. É a cascata de "vai um": a unidade estoura, a casa do 2 estoura, a casa do 4 estoura, e finalmente a casa do 8 acende.',
        },
        {
          type: 'mc', id: 'f1-s2-e2',
          q: 'Sem converter, apenas olhando: o número binário **10110111010** é par ou ímpar?',
          options: [
            { t: 'Par', fb: 'Olhe só o último bit (o da direita, peso 1). Se é 0, nenhuma contribuição ímpar entrou na soma, então é par. Se é 1, é ímpar. Qual é o último bit?' },
            { t: 'Ímpar', fb: 'Olhe só o último bit (o da direita, peso 1). Ele é 0. Todos os outros pesos (2, 4, 8...) são pares, então a soma é par.' },
            { t: 'Par, porque o último bit é 0 e todos os outros pesos são números pares.', ok: true, fb: 'Exatamente. Só o peso 1 pode tornar um número ímpar. Esse truque é usado o tempo todo em programação (`n & 1`).' },
          ],
          explain: 'Em binário, a paridade (par/ímpar) está inteiramente no último bit. É muito mais fácil que em decimal, onde você precisa olhar o último algarismo e lembrar quais são pares.',
        },
        {
          type: 'input', id: 'f1-s2-e3',
          q: 'Qual é o MAIOR número que cabe em **6 bits**? (Responda em decimal.)',
          answer: '63',
          hints: ['Com n bits, todos em 1, o valor é 2ⁿ − 1.', '2⁶ = 64. Menos um...'],
          explain: '111111₂ = 32 + 16 + 8 + 4 + 2 + 1 = 63 = 2⁶ − 1. De 0 a 63 são 64 valores, que é 2⁶.',
        },
        {
          type: 'bits', id: 'f1-s2-e4',
          q: 'Monte o número **200** com 8 bits. Use o método do maior peso que cabe.',
          nbits: 8, target: 200,
          hints: ['128 cabe em 200? Sim. Sobram 72.', '64 cabe em 72? Sim. Sobram 8.', '200 = 128 + 64 + 8 → 11001000.'],
          explain: '200 = 128 + 64 + 8 = 11001000₂. Veja que a maioria dos bits está em zero: isso é comum.',
        },
      ],
    },
    {
      id: 's3',
      title: 'Convertendo com método: decimal → binário e binário → decimal',
      body: `
## Binário → decimal: o método da soma de pesos

Você já faz isso. Formalizando:

1. Escreva os pesos embaixo de cada bit, da **direita** para a esquerda: 1, 2, 4, 8, 16, 32, 64, 128...
2. Some os pesos cujo bit é **1**.

Exemplo: **10100110**

| bit | 1 | 0 | 1 | 0 | 0 | 1 | 1 | 0 |
|---|---|---|---|---|---|---|---|---|
| peso | 128 | 64 | 32 | 16 | 8 | 4 | 2 | 1 |
| conta? | ✓ | | ✓ | | | ✓ | ✓ | |

128 + 32 + 4 + 2 = **166**.

> 💡 Erro mais comum: escrever os pesos da esquerda para a direita (1, 2, 4...) começando pelo bit mais à esquerda. **Os pesos sempre começam em 1 na direita.** Em decimal, as unidades também estão na direita. Mesma coisa.

## Decimal → binário, método 1: subtração dos maiores pesos (o método "guloso")

1. Encontre o maior peso (potência de 2) que seja ≤ ao número. Marque 1 nessa casa.
2. Subtraia esse peso do número.
3. Repita com o que sobrou, até chegar em zero.
4. Todas as casas não marcadas recebem 0.

Exemplo: converter **77**.

- Maior peso ≤ 77: **64**. Sobra 77 − 64 = 13.
- Maior peso ≤ 13: **8**. Sobra 5.
- Maior peso ≤ 5: **4**. Sobra 1.
- Maior peso ≤ 1: **1**. Sobra 0. Fim.

Casas marcadas: 64, 8, 4, 1. Com 8 bits: 128(0) 64(1) 32(0) 16(0) 8(1) 4(1) 2(1) 1(1) → **01001101**.

Confira voltando: 64 + 8 + 4 + 1 = 77. ✓ **Sempre confira voltando.** É rápido e elimina 90% dos erros.

## Decimal → binário, método 2: divisões sucessivas por 2

Esse método é o que os computadores (e os programadores) usam, porque é mecânico e serve para qualquer base.

1. Divida o número por 2. Anote o **resto** (0 ou 1).
2. Pegue o quociente e divida por 2 de novo. Anote o resto.
3. Repita até o quociente ser 0.
4. Leia os restos **de baixo para cima** (do último para o primeiro).

Exemplo: converter **77**.

\`\`\`
77 ÷ 2 = 38, resto 1   ← bit menos significativo (o da direita)
38 ÷ 2 = 19, resto 0
19 ÷ 2 =  9, resto 1
 9 ÷ 2 =  4, resto 1
 4 ÷ 2 =  2, resto 0
 2 ÷ 2 =  1, resto 0
 1 ÷ 2 =  0, resto 1   ← bit mais significativo (o da esquerda)
\`\`\`

Lendo de baixo para cima: **1001101**. Igual ao método 1 (sem o zero da frente). ✓

**Por que isso funciona?** Quando você divide por 2, o resto diz se o número é par (resto 0) ou ímpar (resto 1), e você já sabe que isso é exatamente o último bit. O quociente é o número "sem o último bit" (deslocado uma casa para a direita). Então você está arrancando um bit por vez, da direita para a esquerda. Não é mágica: é a própria estrutura posicional.

> 🔤 **Bit mais significativo** = *most significant bit* (**MSB**): o bit mais à esquerda, de maior peso. **Bit menos significativo** = *least significant bit* (**LSB**): o da direita, de peso 1. "Significativo" aqui quer dizer "que mais afeta o valor". Trocar o MSB de 10000000 muda o valor em 128; trocar o LSB muda em 1.

## Qual método usar?

- Para números pequenos (até 255), o método guloso é mais rápido de cabeça, desde que você saiba as potências de 2.
- Para números grandes ou para programar um conversor, as divisões sucessivas são mais seguras.
- **Sempre** confira voltando (binário → decimal).

## Treino com dificuldade adaptativa

Os exercícios abaixo são gerados aleatoriamente. O jogo observa seus acertos e erros e ajusta o tamanho dos números. Você precisa de uma sequência de acertos para passar: isso garante que não foi sorte.
`,
      exercises: [
        {
          type: 'gen', id: 'f1-s3-g1', kind: 'bin2dec', count: 4,
          q: 'Converta de binário para decimal. Escreva os pesos (1, 2, 4, 8...) da direita para a esquerda e some os ligados.',
          explain: 'Você está lendo binário com fluência. Com prática, você começa a reconhecer padrões de cara: 1111 = 15, 1010 = 10, 11111111 = 255.',
        },
        {
          type: 'gen', id: 'f1-s3-g2', kind: 'dec2bin', count: 4,
          q: 'Converta de decimal para binário. Use o método que preferir (maior peso que cabe, ou divisões por 2), e **confira voltando** antes de responder.',
          explain: 'Conversão dominada. Repare que o hábito de conferir voltando é exatamente o que um bom programador faz: testar a resposta.',
        },
        {
          type: 'mc', id: 'f1-s3-e3',
          q: 'No método das divisões sucessivas por 2, por que o PRIMEIRO resto obtido é o bit da DIREITA (menos significativo)?',
          options: [
            { t: 'É só uma convenção; poderia ser o da esquerda.', fb: 'Não é convenção. Pense: o que o resto da divisão por 2 diz sobre um número?' },
            { t: 'Porque o resto da divisão por 2 diz se o número é par ou ímpar, e par/ímpar é determinado exatamente pelo bit de peso 1, que é o da direita.', ok: true, fb: 'Isso. Cada divisão "arranca" o bit de peso 1 e desloca os demais para a direita.' },
            { t: 'Porque dividir é o contrário de somar, então a ordem inverte.', fb: 'Dividir é o contrário de multiplicar, não de somar. E o motivo é mais concreto: o que o resto representa?' },
          ],
          explain: 'Entender o porquê te permite reconstruir o método se esquecer, em vez de depender de decoreba.',
        },
      ],
    },
    {
      id: 's4',
      title: 'Padrões que todo programador conhece de cor',
      body: `
## Os números "redondos" do binário

Em decimal, 10, 100, 1.000 são redondos. Em binário, os redondos são as potências de 2: 2, 4, 8, 16, 32, 64, 128, 256, 512, 1.024... Eles aparecem **em toda parte** na computação, e agora você sabe por quê: são os valores em que um bit a mais passa a ser necessário.

- Tamanhos de memória: 4 GB, 8 GB, 16 GB, 32 GB. Nunca 10 GB.
- Resoluções e texturas em jogos: 256×256, 512×512, 1024×1024.
- Limites de valores: 255 (8 bits), 65.535 (16 bits), 4.294.967.295 (32 bits).
- O famoso "limite de 128 amigos", "32 níveis", "64 slots": sempre potências de 2, porque alguém guardou aquilo num número fixo de bits.

## Os "quase-redondos": 2ⁿ − 1

Quando todos os bits estão em 1, o valor é 2ⁿ − 1. Esses números marcam **limites máximos**:

| bits | máximo (2ⁿ − 1) | onde aparece |
|---|---|---|
| 4 | 15 | um dígito hexadecimal (Fase 2) |
| 8 | 255 | cor por canal, byte, IPv4 |
| 16 | 65.535 | portas de rede, cores "high color" |
| 31 | 2.147.483.647 | maior inteiro com sinal em 32 bits (bug do ano 2038, YouTube do Gangnam Style) |
| 32 | 4.294.967.295 | endereços IPv4 possíveis |

> 📜 Em 2014, o vídeo "Gangnam Style" ultrapassou 2.147.483.647 visualizações, e o contador do YouTube "quebrou" (mostrou número negativo), porque estava guardado em 32 bits com sinal. Eles tiveram de trocar para 64 bits. Você vai entender o "com sinal" e o número negativo na Fase 5. Por enquanto, note: **limites de bits são reais e causam bugs reais.**

## Deslocar é multiplicar

Pegue 0101 (= 5). Acrescente um zero à direita: 01010 (= 10). Mais um: 010100 (= 20). **Deslocar um número binário uma casa para a esquerda é multiplicar por 2.** Da mesma forma, em decimal, acrescentar um zero à direita multiplica por 10.

E deslocar para a direita (jogando fora o último bit) é **dividir por 2, ignorando o resto**: 1101 (13) → 110 (6).

Processadores adoram isso porque deslocar bits é uma operação fisicamente trivial (são só fios cruzados), muito mais barata que multiplicar. Programadores usam os operadores \`<<\` e \`>>\` para isso em quase todas as linguagens.

## Kilo, mega, giga: a confusão dos 1.024

Em ciência, kilo = 1.000. Mas 1.000 não é um número redondo em binário. O número redondo mais próximo é 2¹⁰ = 1.024. Por décadas, a indústria usou "1 KB" para significar 1.024 bytes, "1 MB" para 1.024 KB (= 1.048.576 bytes) e assim por diante.

Hoje existe uma norma que separa: **KiB** (kibibyte) = 1.024 bytes; **KB** (kilobyte) = 1.000 bytes. Na prática, fabricantes de HD usam 1.000 (porque dá números maiores no rótulo) e sistemas operacionais costumam usar 1.024. É por isso que um HD "de 1 TB" aparece como ~931 GB no Windows: 1.000.000.000.000 ÷ 1.024⁴ ≈ 0,909 TiB, ou 931 GiB. Ninguém te roubou; são duas definições de "giga".

> ⚠️ Fontes divergem no uso cotidiano. "KB = 1.024" ainda é muito usado informalmente. Quando a precisão importar, pergunte qual definição está em uso.
`,
      exercises: [
        {
          type: 'input', id: 'f1-s4-e1',
          q: 'O número binário **1011** vale 11. Qual é o valor de **10110** (o mesmo número deslocado uma casa para a esquerda)? Tente responder SEM converter, usando a regra do deslocamento.',
          answer: '22',
          hints: ['Deslocar uma casa para a esquerda = multiplicar por 2.', '11 × 2 = ?'],
          explain: 'Deslocar para a esquerda multiplica por 2 (como acrescentar um zero em decimal multiplica por 10). Programadores escrevem isso como `11 << 1`.',
        },
        {
          type: 'input', id: 'f1-s4-e2',
          q: 'Um jogo antigo guardava a quantidade de vidas do jogador em **4 bits**. Qual é o máximo de vidas possível?',
          answer: '15',
          hints: ['Máximo com n bits = 2ⁿ − 1.', '2⁴ = 16. Menos um.'],
          explain: '1111₂ = 15. Se o jogo tentasse dar a 16ª vida, o contador "daria a volta" e viraria 0000 = 0 vidas. Isso é um bug clássico chamado *overflow*, que estudaremos a fundo na Fase 5.',
        },
        {
          type: 'mc', id: 'f1-s4-e3',
          q: 'Por que tamanhos de memória RAM são 4, 8, 16, 32 GB, e nunca 10 ou 12 GB (em um único módulo)?',
          options: [
            { t: 'Porque os fabricantes combinaram esses tamanhos por marketing.', fb: 'Há uma razão técnica mais profunda. Pense em como cada célula de memória é localizada: por um número de bits de endereço.' },
            { t: 'Porque cada célula é localizada por um endereço de n bits, e n bits endereçam exatamente 2ⁿ células. Logo, o total é sempre uma potência de 2.', ok: true, fb: 'Isso. Com 33 fios de endereço, você acessa 2³³ = 8 Gi posições. Para ter 10 GB, sobraria um pedaço de endereços sem uso ou faltaria fio.' },
            { t: 'Porque 10 e 12 não podem ser escritos em binário.', fb: 'Qualquer número inteiro pode ser escrito em binário (10 = 1010, 12 = 1100). O motivo é outro: como as células são endereçadas.' },
          ],
          explain: 'Vamos ver endereços de memória em detalhe na Fase 6. Guarde a ideia: "n bits de endereço → 2ⁿ posições".',
        },
        {
          type: 'explain', id: 'f1-s4-e4',
          q: 'Explique com suas palavras por que o sistema binário é "o mesmo sistema" que o decimal, só com menos algarismos. Mencione pesos/posições e o que acontece quando os algarismos acabam.',
          keywords: [['posição', 'posicional', 'casa', 'peso'], ['dois', '2', 'dobro', 'dobra'], ['dez', '10'], ['vai um', 'estoura', 'zera', 'acaba', 'acabam'], ['potência', 'multiplica']],
          minGroups: 3,
          model: 'Nos dois sistemas, cada posição tem um peso, e o valor do número é a soma de (algarismo × peso). Em decimal, os pesos são potências de 10 (1, 10, 100) porque há dez algarismos: quando a casa chega em 9 e precisamos de mais um, ela zera e "vai um" para a próxima. Em binário há só dois algarismos (0 e 1), então a casa estoura depois de 1, e os pesos são potências de 2 (1, 2, 4, 8). A regra é a mesma; só muda quantos algarismos existem antes de estourar.',
        },
      ],
    },
  ],
  boss: {
    title: 'Chefe da Fase 1: A Esfinge Binária',
    intro: 'A Esfinge faz perguntas de conversão e de entendimento. Ela não aceita "quase": binário é exato. Lembre-se de conferir cada conversão voltando pelo caminho inverso.',
    passRatio: 0.8,
    exercises: [
      { type: 'input', id: 'f1-b1', q: 'Converta **10011010** (binário) para decimal.', answer: '154', hints: ['Pesos 128 64 32 16 8 4 2 1. Ligados: 128, 16, 8, 2.'], explain: '128 + 16 + 8 + 2 = 154.' },
      { type: 'input', id: 'f1-b2', q: 'Converta **93** (decimal) para binário com 8 bits.', answer: ['01011101', '1011101'], hints: ['64 cabe (sobra 29), 16 cabe (sobra 13), 8 cabe (sobra 5), 4 cabe (sobra 1), 1 cabe.'], explain: '93 = 64 + 16 + 8 + 4 + 1 = 01011101.' },
      { type: 'bits', id: 'f1-b3', q: 'Monte **170** com 8 bits. (Dica: é um padrão famoso.)', nbits: 8, target: 170, hints: ['128 + 32 + 8 + 2.', 'Alterna 1 e 0: 10101010.'], explain: '170 = 10101010₂. Programadores reconhecem 0xAA (hexadecimal, Fase 2) imediatamente.' },
      {
        type: 'mc', id: 'f1-b4', q: 'Qual é o número que vem logo após **011111** (binário)?',
        options: [{ t: '011112', fb: 'Não existe algarismo 2 em binário! Quando a casa está em 1 e recebe mais um, ela zera e vai um.' }, { t: '100000', ok: true, fb: '31 + 1 = 32 = 100000.' }, { t: '111111', fb: 'Isso é 63, bem maior. Cuidado: somar 1 a um número que termina em 1 causa cascata de "vai um".' }],
        explain: 'Cascata de vai-um: todos os 1s da direita viram 0 e o primeiro 0 vira 1.',
      },
      { type: 'input', id: 'f1-b5', q: 'Quantos bits são necessários, no mínimo, para numerar **300** salas de um hotel (de 0 a 299)?', answer: '9', hints: ['Menor n com 2ⁿ ≥ 300.', '2⁸ = 256 (pouco). 2⁹ = 512.'], explain: '8 bits dão só 256 valores; 9 bits dão 512.' },
      { type: 'input', id: 'f1-b6', q: 'O binário **110** vale 6. Qual o valor de **11000**?', answer: '24', hints: ['Duas casas para a esquerda = multiplicar por 2 duas vezes.', '6 × 4.'], explain: 'Cada deslocamento à esquerda multiplica por 2: 6 → 12 → 24.' },
      { type: 'gen', id: 'f1-b7', kind: 'bin2dec', count: 3, q: 'Rodada final de conversão binário → decimal.', explain: 'A Esfinge está satisfeita.' },
      {
        type: 'explain', id: 'f1-b8', q: 'Por que 8 bits representam valores de 0 a 255, e não de 1 a 256 nem de 0 a 256? Explique.',
        keywords: [['256', 'duzentos e cinquenta e seis'], ['zero', '0'], ['combinaç', 'possibilidade', 'valores'], ['2⁸', '2^8', '2 elevado']],
        minGroups: 3,
        model: '8 bits têm 2⁸ = 256 combinações diferentes. Uma dessas combinações (00000000) representa o zero, então as 256 combinações cobrem os valores de 0 até 255. O 256 precisaria de uma 9ª casa (100000000). Começar do zero é o que faz o máximo ser "uma potência de 2 menos um".',
      },
    ],
  },
  review: [
    { id: 'f1-r1', q: 'Quais são os pesos das 8 posições de um número binário, da direita para a esquerda?', a: '1, 2, 4, 8, 16, 32, 64, 128.' },
    { id: 'f1-r2', q: 'Converta 1101 para decimal.', a: '8 + 4 + 1 = 13.', answer: '13' },
    { id: 'f1-r3', q: 'Converta 45 para binário.', a: '32 + 8 + 4 + 1 = 101101.', answer: ['101101', '00101101'] },
    { id: 'f1-r4', q: 'Como saber, só de olhar, se um número binário é par?', a: 'Se o último bit (da direita, peso 1) é 0, é par. Se é 1, é ímpar.' },
    { id: 'f1-r5', q: 'Qual o maior valor em n bits?', a: '2ⁿ − 1 (todos os bits em 1). Com 8 bits: 255.' },
    { id: 'f1-r6', q: 'O que acontece com um número binário quando você acrescenta um 0 à direita?', a: 'Ele dobra (multiplica por 2), assim como acrescentar 0 em decimal multiplica por 10.' },
    { id: 'f1-r7', q: 'O que significam MSB e LSB?', a: 'Most/Least Significant Bit: o bit de maior peso (esquerda) e o de menor peso (direita).' },
    { id: 'f1-r8', q: 'No método das divisões por 2, em que ordem se leem os restos?', a: 'De baixo para cima: o primeiro resto é o bit da direita (LSB).' },
  ],
  glossary: [
    { pt: 'notação posicional', en: 'positional notation', def: 'Sistema em que o valor de um algarismo depende da posição em que está (peso = baseᵖᵒˢⁱçãᵒ).' },
    { pt: 'base', en: 'base / radix', def: 'Quantidade de algarismos distintos de um sistema numérico. Decimal = base 10; binário = base 2.' },
    { pt: 'bit mais significativo', en: 'most significant bit (MSB)', def: 'O bit mais à esquerda, de maior peso.' },
    { pt: 'bit menos significativo', en: 'least significant bit (LSB)', def: 'O bit mais à direita, de peso 1. Determina se o número é par ou ímpar.' },
    { pt: 'vai-um', en: 'carry', def: 'O que acontece quando uma casa "estoura" e passa 1 para a casa seguinte.' },
    { pt: 'deslocamento', en: 'shift', def: 'Mover todos os bits para a esquerda (×2) ou direita (÷2). Operadores `<<` e `>>` em linguagens de programação.' },
    { pt: 'kibibyte / kilobyte', en: 'KiB / KB', def: 'KiB = 1.024 bytes (binário). KB = 1.000 bytes (decimal). Muita gente usa KB para ambos.' },
    { pt: 'algoritmo', en: 'algorithm', def: 'Sequência precisa de passos para resolver um problema.', origin: 'Do nome do matemático persa al-Khwarizmi (~820 d.C.), que descreveu métodos de cálculo posicional.' },
  ],
};
