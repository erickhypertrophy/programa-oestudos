import type { Phase } from '../lib/types';

export const phase2: Phase = {
  id: 'f2',
  num: 2,
  emoji: '🔡',
  title: 'Tudo é bits',
  subtitle: 'Bytes, hexadecimal, texto, cores: como qualquer coisa vira sequência de 0 e 1, e por que o significado está na convenção, não nos bits',
  goal: 'Ao final desta fase você vai entender o que é um byte, ler e escrever hexadecimal com naturalidade, saber como texto e cores são codificados, e ter internalizado a ideia mais importante da computação: os mesmos bits significam coisas diferentes dependendo de como você decide interpretá-los.',
  sections: [
    {
      id: 's1',
      title: 'O byte: por que agrupamos bits de 8 em 8',
      body: `
## Bits sozinhos são incômodos

Um bit é a menor unidade, mas é pequena demais para o dia a dia. Seria como medir a distância entre cidades em milímetros. Precisamos de uma unidade "de trabalho".

> 🔤 **Byte** (pronuncia-se "báit") é um grupo de **8 bits**. O termo foi cunhado por Werner Buchholz em 1956, na IBM, e a grafia com *y* foi proposital: para não confundir com *bit* ao escrever à mão. Um grupo de 4 bits (meio byte) é chamado, com humor, de **nibble** ("mordidinha", já que *bite* é "mordida").

Um byte tem 2⁸ = **256** valores possíveis, de 0 a 255. Você já conhece esse número da Fase 0.

## Por que 8, e não 6 ou 10?

Honestamente: por história e conveniência, não por necessidade matemática. Nos anos 1950–60, máquinas diferentes usavam grupos de 6, 7, 9, até 36 bits. O IBM System/360 (1964), que foi enormemente influente, padronizou o byte de 8 bits, por alguns motivos práticos:

- 8 é uma potência de 2 (2³), o que simplifica endereçar os bits dentro de um byte com 3 bits.
- 8 bits bastam para um caractere de texto com margem (7 bits do ASCII + 1 extra).
- 8 bits se dividem em dois *nibbles*, cada um sendo exatamente um dígito hexadecimal (próxima seção), o que facilita a leitura por humanos.

Desde então, "byte = 8 bits" se tornou universal. Quando você vê "16 GB de RAM", são 16 × 2³⁰ bytes ≈ 137 bilhões de bits.

> ⚠️ Em redes e telecomunicações, você às vezes verá a palavra **octeto** (*octet*), que significa explicitamente "8 bits", justamente porque historicamente "byte" nem sempre foi 8. Hoje são sinônimos na prática.

## Palavras: grupos de bytes

Processadores trabalham com grupos maiores, chamados **palavras** (*words*). Um processador "de 64 bits" tem palavras de 8 bytes: ele faz contas e move dados de 64 em 64 bits de cada vez. Os tamanhos comuns:

| nome comum | bits | bytes | valores sem sinal | onde aparece |
|---|---|---|---|---|
| byte | 8 | 1 | 0 a 255 | um caractere ASCII, um canal de cor |
| half-word / short | 16 | 2 | 0 a 65.535 | portas de rede, áudio de CD por amostra |
| word / int | 32 | 4 | 0 a ~4,29 bilhões | inteiros comuns em programação |
| double word / long | 64 | 8 | 0 a ~1,8 × 10¹⁹ | inteiros grandes, endereços modernos |

> 💡 Quando, numa linguagem de programação, você vê tipos como \`int8\`, \`uint16\`, \`int32\`, \`int64\`: o número é a quantidade de bits, e o **u** significa *unsigned* ("sem sinal", só positivos). Agora esses nomes não são mais arbitrários para você.

## Bits em sequência: a "fita" da memória

A memória de um computador pode ser imaginada como uma fita enorme de bytes, um atrás do outro, cada um com um número (o **endereço**). Um computador com 8 GB de RAM tem cerca de 8,6 bilhões de bytes, numerados de 0 até ~8,6 bilhões.

Tudo o que o computador "sabe" — este texto, a imagem do seu papel de parede, o programa que está rodando, a música tocando — está nessa fita como sequências de bytes. Não há "tipos" de bytes: um byte com o valor 65 é só o padrão 01000001. O que ele *significa* depende de quem está lendo e de qual convenção está usando. Essa é a ideia central da fase, e vamos ver três convenções: hexadecimal (uma forma de *escrever* bytes), texto e cor.
`,
      exercises: [
        {
          type: 'input', id: 'f2-s1-e1',
          q: 'Quantos **bits** há em **3 bytes**?',
          answer: '24',
          hints: ['1 byte = 8 bits.', '3 × 8.'],
          explain: '24 bits. Esse é exatamente o tamanho de uma cor "true color" (RGB), que veremos adiante.',
        },
        {
          type: 'input', id: 'f2-s1-e2',
          q: 'Quantos valores diferentes cabem em **2 bytes** (16 bits)?',
          answer: ['65536', '65.536'],
          hints: ['2¹⁶. Você sabe 2⁸ = 256. 2¹⁶ = 256 × 256.', '256 × 256 = 65.536.'],
          explain: '2¹⁶ = 65.536 (de 0 a 65.535). Por isso existem 65.535 portas de rede possíveis e cores de 16 bits têm 65.536 tons.',
        },
        {
          type: 'mc', id: 'f2-s1-e3',
          q: 'O byte de 8 bits é padrão porque...',
          options: [
            { t: 'é matematicamente impossível construir computadores com bytes de outro tamanho.', fb: 'Já existiram máquinas com bytes de 6, 7 e 9 bits. É uma convenção, não uma lei.' },
            { t: 'é uma convenção histórica (IBM System/360, 1964) com vantagens práticas: potência de 2, cabe um caractere, divide-se em dois dígitos hexadecimais.', ok: true, fb: 'Exato. Útil + histórico = padrão.' },
            { t: 'o ser humano tem 8 dedos sem contar os polegares.', fb: 'Curioso, mas não é o motivo. Há razões técnicas (potência de 2, caractere ASCII, hexadecimal).' },
          ],
          explain: 'Saber que algo é convenção, e não necessidade, é parte do entendimento profundo. Convenções podem mudar; necessidades matemáticas, não.',
        },
      ],
    },
    {
      id: 's2',
      title: 'Hexadecimal: o jeito humano de escrever bits',
      body: `
## O problema: binário é longo e difícil de ler

Qual destes é mais fácil de ler, copiar sem erro e lembrar?

- 1101 1110 1010 1101 1011 1110 1110 1111
- DEADBEEF

São o mesmo número. O segundo está em **hexadecimal** (base 16). Programadores usam hexadecimal o tempo todo, não porque computadores "entendam" hexadecimal (eles só têm bits), mas porque é uma **abreviação perfeita** do binário para olhos humanos.

> 🔤 **Hexadecimal**, do grego *hexa* (seis) + latim *decem* (dez) = dezesseis. Programadores abreviam para **hex**. O prefixo **0x** indica hexadecimal: 0xFF, 0x1A. Em CSS, cores usam **#**: #FF8800.

## Por que 16 é a base perfeita para abreviar binário

16 = 2⁴. Isso significa que **um dígito hexadecimal corresponde exatamente a 4 bits** (um nibble). Nenhuma outra base "redonda" tem essa propriedade tão limpa (10 não é potência de 2, e 8 = 2³ dá só 3 bits por dígito, que não divide o byte ao meio).

Então um byte (8 bits) = exatamente **2 dígitos hex**. Sempre. Sem sobras.

## Os 16 algarismos

Base 16 precisa de 16 símbolos. Os dez primeiros são os que conhecemos (0–9). Para os seis seguintes, usamos as letras A–F:

| decimal | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| hex | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | A | B | C | D | E | F |
| binário | 0000 | 0001 | 0010 | 0011 | 0100 | 0101 | 0110 | 0111 | 1000 | 1001 | 1010 | 1011 | 1100 | 1101 | 1110 | 1111 |

Decore essa tabela. É pequena e é a chave para ler hexadecimal "de cara". Dica: A = 10 (**a**-dez), F = 15 (o maior, tudo ligado: 1111).

## Binário → hex: separe em grupos de 4

1. Separe o binário em grupos de 4 bits, **começando pela direita**. Se o último grupo (à esquerda) ficar incompleto, complete com zeros à esquerda.
2. Troque cada grupo pelo dígito hex correspondente.

Exemplo: 10111010 → 1011 | 1010 → B | A → **0xBA**.

Exemplo: 1100101 (7 bits) → 0110 | 0101 → 6 | 5 → **0x65**.

## Hex → binário: expanda cada dígito em 4 bits

0x3F → 3 = 0011, F = 1111 → **00111111**.

0xA0 → 1010 0000.

## Hex → decimal: pesos são potências de 16

Mesma notação posicional de sempre. Os pesos são 1, 16, 256, 4096...

0x2F = 2 × 16 + 15 × 1 = 32 + 15 = **47**.

0x1A3 = 1 × 256 + 10 × 16 + 3 × 1 = 256 + 160 + 3 = **419**.

## Decimal → hex: divisões por 16 (ou via binário)

200 ÷ 16 = 12 resto 8 → 12 é C → **0xC8**. (Conferindo: 12 × 16 + 8 = 200 ✓.)

Ou: 200 = 11001000₂ → 1100 | 1000 → C | 8 → 0xC8. Mesmo resultado.

## Onde você vai ver hexadecimal

- **Cores**: #FF0000 é vermelho puro (FF de vermelho, 00 de verde, 00 de azul).
- **Endereços de memória**: 0x7FFE3A10. Quando um programa trava, a mensagem de erro costuma mostrar endereços assim.
- **Endereços MAC** de placas de rede: 3C:22:FB:1A:9E:04.
- **Códigos de caracteres Unicode**: U+00E7 é "ç".
- **Dumps de arquivos**: ao abrir qualquer arquivo com um "editor hexadecimal", você vê os bytes crus em hex. Arquivos PNG começam com 89 50 4E 47; arquivos ZIP, com 50 4B.

> 💡 O hexadecimal é apenas uma **forma de escrever**. 255, 0xFF e 11111111 são o mesmo número, do mesmo jeito que "cinco", "5" e "V" são o mesmo número. O computador só guarda os bits.
`,
      exercises: [
        {
          type: 'input', id: 'f2-s2-e1',
          q: 'Converta o binário **11110000** para hexadecimal (2 dígitos).',
          answer: ['F0', 'f0', '0xF0', '0xf0'],
          hints: ['Separe em 1111 | 0000.', '1111 = F, 0000 = 0.'],
          explain: '0xF0. Repare como fica fácil: cada nibble vira um dígito.',
        },
        {
          type: 'input', id: 'f2-s2-e2',
          q: 'Converta **0x4D** para decimal.',
          answer: '77',
          hints: ['Peso do primeiro dígito é 16, do segundo é 1.', '4 × 16 + D(=13) × 1.'],
          explain: '4 × 16 + 13 = 64 + 13 = 77. (É o mesmo 77 que convertemos na Fase 1: 01001101 = 0100 | 1101 = 4 | D.)',
        },
        {
          type: 'gen', id: 'f2-s2-g1', kind: 'bin2hex', count: 4,
          q: 'Converta binário (8 bits) para hexadecimal. Separe em dois grupos de 4.',
          explain: 'Você agora lê bytes como um programador. 0xAA = 10101010, 0x55 = 01010101, 0xFF = tudo ligado.',
        },
        {
          type: 'gen', id: 'f2-s2-g2', kind: 'hex2dec', count: 3,
          q: 'Converta hexadecimal para decimal (pesos 16 e 1).',
          explain: 'Dominado.',
        },
        {
          type: 'mc', id: 'f2-s2-e5',
          q: 'Por que programadores preferem hexadecimal a decimal para mostrar bytes e endereços de memória?',
          options: [
            { t: 'Porque o computador processa hexadecimal mais rápido.', fb: 'O computador só processa bits. Hex é uma forma de ESCREVER para humanos; não existe "dentro" da máquina.' },
            { t: 'Porque cada dígito hex corresponde exatamente a 4 bits, então dá para enxergar os bits individuais sem fazer conta, e um byte vira sempre 2 dígitos.', ok: true, fb: 'Correto. Em decimal, "200" não te diz nada sobre os bits; "C8" te diz: 1100 1000.' },
            { t: 'Porque hexadecimal usa menos memória.', fb: 'A memória guarda bits; a representação escrita não muda o que está guardado.' },
          ],
          explain: 'Hex é uma lente: uma forma compacta e transparente de olhar para bits.',
        },
      ],
    },
    {
      id: 's3',
      title: 'Texto é número: ASCII e Unicode',
      body: `
## Como se guarda a letra "A"?

A memória só tem bits. Não há "letras" lá dentro. Então, para guardar texto, fazemos o que a sua irmã do vale fez: **combinamos** uma tabela. "Tal número significa tal letra."

> 📜 Em 1963, um comitê americano publicou a tabela **ASCII** (*American Standard Code for Information Interchange*, "Código Padrão Americano para Intercâmbio de Informação"). Ela associa 128 números (0 a 127, ou seja, 7 bits) a caracteres: letras maiúsculas e minúsculas, dígitos, pontuação e alguns "controles" (como "nova linha" e "tabulação").

Alguns valores da tabela ASCII que vale conhecer:

| caractere | decimal | hex | binário |
|---|---|---|---|
| espaço | 32 | 0x20 | 0010 0000 |
| 0 (o dígito) | 48 | 0x30 | 0011 0000 |
| 9 (o dígito) | 57 | 0x39 | 0011 1001 |
| A | 65 | 0x41 | 0100 0001 |
| B | 66 | 0x42 | 0100 0010 |
| Z | 90 | 0x5A | 0101 1010 |
| a | 97 | 0x61 | 0110 0001 |
| z | 122 | 0x7A | 0111 1010 |
| nova linha (\\n) | 10 | 0x0A | 0000 1010 |

Observe os padrões, porque eles foram projetados de propósito:

- **"A" = 65 e "a" = 97. A diferença é 32**, que é exatamente um bit (o de peso 32). Então, para transformar maiúscula em minúscula, basta ligar o bit 5. Olhe: A = 0**1**0 0001 e a = 0**1**1 0001. Só um bit muda! Isso permitia aos computadores dos anos 60 converter maiúsculas/minúsculas sem nenhuma tabela.
- **Os dígitos "0" a "9" são 48 a 57 = 0x30 a 0x39.** Os 4 bits de baixo são o próprio valor do dígito. Para converter o caractere "7" no número 7, subtraia 48. Você vai fazer isso em programação (e vai entender por que \`"7" + 1\` em algumas linguagens dá algo esquisito: o "7" é 55, não 7!).
- O caractere "0" (zero) é 48, **não** 0. O byte com valor 0 é um caractere de controle chamado NUL. Essa confusão entre "o número zero" e "o caractere zero" é fonte de incontáveis bugs de iniciantes.

## O limite do ASCII e a Torre de Babel

ASCII tem 128 códigos: suficiente para inglês. Mas e "ç", "ã", "é"? E o alfabeto cirílico, grego, árabe, os milhares de ideogramas chineses?

Nos anos 80 e 90, cada país criou sua própria extensão usando o 8º bit (valores 128–255). O Brasil usava a ISO-8859-1 ("Latin-1"), onde 231 = "ç". A Rússia usava outra tabela onde 231 era uma letra cirílica. Resultado: abrir um arquivo brasileiro num computador russo mostrava lixo. Você já deve ter visto texto como "Ã§Ã£o" em vez de "ção": isso é exatamente um arquivo lido com a tabela errada.

## Unicode: uma tabela para todos

> 📜 A partir de 1991, o consórcio **Unicode** criou uma tabela única para todos os sistemas de escrita do mundo. Hoje tem mais de 150 mil caracteres, incluindo emojis. Cada caractere tem um número chamado **code point** ("ponto de código"), escrito como U+ seguido de hex. Exemplos: U+0041 = "A" (igual ao ASCII, de propósito), U+00E7 = "ç", U+1F600 = 😀.

Mas Unicode é só a *tabela*. Falta decidir **como gravar** esses números (que vão até 0x10FFFF, mais de 1 milhão) em bytes. A forma dominante é o **UTF-8**, inventado por Ken Thompson e Rob Pike em 1992, com uma ideia genial:

- Caracteres de 0 a 127 (o ASCII) usam **1 byte**, idêntico ao ASCII. Todo arquivo ASCII antigo já é UTF-8 válido.
- Caracteres maiores usam 2, 3 ou 4 bytes, com padrões de bits que permitem saber onde cada caractere começa.

Então "ç" em UTF-8 são 2 bytes: C3 A7. "😀" são 4 bytes: F0 9F 98 80. E "A" continua sendo 1 byte: 41.

> ⚠️ **Simplificação avisada**: há detalhes que pulei (UTF-16, caracteres combinados, normalização). O essencial: texto = números (code points) + regra para virar bytes (UTF-8). Quando um programa mostra "caracteres estranhos", a causa é quase sempre uma leitura com a regra errada.

Experimente digitar texto e ver os bytes:

[[demo:text-bits]]

## Então "A" é 65?

Cuidado com a frase. O byte 01000001 **não é** a letra A. Ele é o número 65. Ele é a letra A **quando alguém o interpreta como texto ASCII**. Se outro programa interpretar o mesmo byte como um número de vidas, serão 65 vidas. Se interpretar como intensidade de vermelho, será um vermelho fraco. **Os bits não carregam o próprio significado.** Essa é a lição que vale esta fase inteira.
`,
      exercises: [
        {
          type: 'input', id: 'f2-s3-e1',
          q: 'Sabendo que "A" é 65 e as letras são consecutivas, qual é o código ASCII (decimal) da letra **"E"**?',
          answer: '69',
          hints: ['A=65, B=66, C=67, ...', 'E é a 5ª letra: 65 + 4.'],
          explain: '"E" = 69 = 0x45 = 0100 0101. Por serem consecutivas, "letra − 65" dá a posição no alfabeto (começando do 0). Isso é usado em programação o tempo todo.',
        },
        {
          type: 'input', id: 'f2-s3-e2',
          q: 'A letra "**m**" minúscula tem código 109. Qual é o código da "**M**" maiúscula?',
          answer: '77',
          hints: ['A diferença entre minúscula e maiúscula é sempre 32 (um único bit).', '109 − 32.'],
          explain: '109 − 32 = 77. Em binário: m = 0110 1101, M = 0100 1101. Só o bit de peso 32 muda.',
        },
        {
          type: 'mc', id: 'f2-s3-e3',
          q: 'Um arquivo de texto contém os bytes **48 65 6C 6C 6F** (em hex). Interpretando como ASCII, o que está escrito? (Use: 0x48=H, 0x65=e, 0x6C=l, 0x6F=o.)',
          options: [
            { t: 'Hello', ok: true, fb: 'H-e-l-l-o. Você acabou de ler bytes crus como um programador lendo um "hex dump".' },
            { t: 'Olá', fb: 'Use a tabela dada: 0x48 = H, 0x65 = e, 0x6C = l (duas vezes), 0x6F = o.' },
            { t: 'Não dá para saber: bytes não têm significado.', fb: 'Meio certo, meio errado: bytes sozinhos não têm significado, mas a pergunta DISSE a convenção (ASCII). Com a convenção, dá para ler.' },
          ],
          explain: 'Bytes + convenção = significado. Sem a convenção, 48 65 6C 6C 6F seriam apenas cinco números.',
        },
        {
          type: 'mc', id: 'f2-s3-e4',
          q: 'Por que o UTF-8 foi projetado para que os caracteres de 0 a 127 ocupem exatamente 1 byte igual ao ASCII?',
          options: [
            { t: 'Porque era impossível fazer de outro jeito.', fb: 'Era perfeitamente possível (o UTF-16 e o UTF-32 fazem diferente). Foi uma escolha. Qual a vantagem?' },
            { t: 'Para que todos os textos ASCII já existentes continuassem válidos sem conversão (compatibilidade), e textos em inglês continuassem compactos.', ok: true, fb: 'Exato. Compatibilidade com o passado é uma das forças mais poderosas em computação.' },
            { t: 'Porque emojis não existiam em 1992.', fb: 'Emojis não têm relação com essa decisão. Pense em compatibilidade com os bilhões de arquivos ASCII já existentes.' },
          ],
          explain: 'Essa decisão é uma razão central para o UTF-8 ter vencido e hoje representar mais de 98% das páginas web.',
        },
      ],
    },
    {
      id: 's4',
      title: 'Cores, imagens, som: a mesma ideia, repetida',
      body: `
## Cor é três números

Uma tela é feita de pontinhos minúsculos chamados **pixels** (*picture element*, "elemento de imagem"). Cada pixel tem três sub-pontos de luz: vermelho, verde e azul (**RGB**: *red, green, blue*). Misturando intensidades dessas três luzes, o olho humano percebe qualquer cor.

A convenção mais comum dá **1 byte para cada canal**: 0 (apagado) a 255 (máximo). São 3 bytes = 24 bits por pixel, permitindo 2²⁴ = 16.777.216 cores: o chamado *true color*.

Em hexadecimal, cada canal vira 2 dígitos, e a cor inteira, 6 dígitos:

| cor | R | G | B | hex |
|---|---|---|---|---|
| preto | 0 | 0 | 0 | #000000 |
| branco | 255 | 255 | 255 | #FFFFFF |
| vermelho puro | 255 | 0 | 0 | #FF0000 |
| verde puro | 0 | 255 | 0 | #00FF00 |
| azul puro | 0 | 0 | 255 | #0000FF |
| amarelo | 255 | 255 | 0 | #FFFF00 |
| cinza médio | 128 | 128 | 128 | #808080 |
| laranja | 255 | 140 | 0 | #FF8C00 |

Agora você entende por que cores na web são escritas como #FF8C00: não é um código misterioso, são **três bytes em hexadecimal**.

[[demo:color-bits]]

## Imagem é uma grade de cores

Uma foto de 1920×1080 pixels tem 2.073.600 pixels. A 3 bytes cada, são 6.220.800 bytes ≈ 6 MB, **sem compressão**. Formatos como JPEG e PNG usam truques matemáticos para guardar quase a mesma imagem em bem menos bytes. Mas, na hora de mostrar na tela, tudo volta a ser essa grade de bytes RGB.

## Som é uma lista de números

Som é vibração do ar. Um microfone mede a pressão do ar milhares de vezes por segundo e cada medida vira um número. Num CD de áudio: 44.100 medidas por segundo, cada uma com 16 bits (2 bytes), em 2 canais (estéreo). Isso dá 44.100 × 2 × 2 = 176.400 bytes por segundo, ≈ 10 MB por minuto. O MP3 comprime isso em ~10×.

Cada número é só um inteiro em binário, como os que você aprendeu na Fase 1. Não há nada "sonoro" nos bits.

## Programas também são bits

Aqui vem o salto que vai fechar o curso na Fase 7: **as instruções que o processador executa também são sequências de bytes**. Um arquivo .exe é uma longa lista de números, cada um dizendo ao processador "some isto", "copie aquilo", "pule para lá". O processador lê esses bytes e os interpreta como comandos, da mesma forma que um programa de texto interpreta 65 como "A".

É por isso que um computador pode rodar qualquer programa: programas são dados, e dados são bits. Essa ideia (programa guardado na memória como dados) é chamada de **arquitetura de von Neumann** e é a base de todo computador que você usou na vida.

## A grande lição: a interpretação é externa aos bits

Vamos fixar com um exemplo concreto. Considere o byte **01000001** (= 65 = 0x41):

- Como inteiro: 65.
- Como caractere ASCII: "A".
- Como intensidade de um canal de cor: um tom fraco (65 de 255).
- Como instrução de um processador x86: é o comando \`inc ecx\` ("some 1 ao registrador ecx").
- Como parte de um arquivo PNG: pode ser um pedaço de um pixel.

Os bits são **idênticos**. O que muda é o **contexto**, ou seja, a convenção usada por quem lê. Em programação, você vai ver isso aparecer como **tipos** (\`int\`, \`char\`, \`float\`, \`string\`): um tipo é exatamente a declaração de "como interpretar estes bits". Quando um programa trata bits de texto como se fossem números, ou vice-versa, acontecem bugs (e falhas de segurança). Agora você sabe a raiz disso.

> 💡 Frase para levar para a vida: **bits não têm significado; convenções dão significado a bits.**
`,
      exercises: [
        {
          type: 'input', id: 'f2-s4-e1',
          q: 'Qual é o código hexadecimal (6 dígitos, sem #) da cor com R=0, G=128, B=255?',
          answer: ['0080FF', '0080ff'],
          hints: ['Cada canal vira 2 dígitos hex. 0 → 00. 128 → ? 255 → ?', '128 = 0x80 (8 × 16). 255 = 0xFF.'],
          explain: '#0080FF, um azul-celeste. Cada byte vira dois dígitos hex: 00 | 80 | FF.',
        },
        {
          type: 'input', id: 'f2-s4-e2',
          q: 'Uma imagem de **100 × 100** pixels, sem compressão, com 3 bytes por pixel, ocupa quantos **bytes**?',
          answer: ['30000', '30.000'],
          hints: ['Número de pixels = 100 × 100.', '10.000 pixels × 3 bytes.'],
          explain: '10.000 pixels × 3 bytes = 30.000 bytes ≈ 29 KiB. Formatos como PNG reduzem isso bastante.',
        },
        {
          type: 'mc', id: 'f2-s4-e3',
          q: 'O byte 0x41 está na memória. Qual afirmação é correta?',
          options: [
            { t: 'Ele é a letra "A".', fb: 'Ele SÓ é "A" se for interpretado como ASCII. O mesmo byte pode ser 65 vidas, uma intensidade de cor ou uma instrução.' },
            { t: 'Ele é o número 65.', fb: 'Ele é 65 se interpretado como inteiro sem sinal. Mas pode ser "A" se interpretado como texto. Qual é a afirmação que vale em todos os casos?' },
            { t: 'Ele é o padrão 01000001; o significado depende da convenção de quem o lê.', ok: true, fb: 'Essa é a única afirmação sempre verdadeira. O padrão é fixo; o significado é externo.' },
          ],
          explain: 'Essa ideia é tão central que vale repetir: **tipos** em programação são exatamente a convenção de interpretação de bits.',
        },
        {
          type: 'explain', id: 'f2-s4-e4',
          q: 'Explique com suas palavras a frase "bits não têm significado; convenções dão significado a bits". Dê pelo menos dois exemplos de interpretações diferentes para o mesmo padrão de bits.',
          keywords: [['convenção', 'tabela', 'acordo', 'interpreta', 'contexto'], ['texto', 'letra', 'ascii', 'caractere'], ['número', 'inteiro', 'valor'], ['cor', 'instrução', 'som', 'programa', 'imagem'], ['mesmo', 'iguais', 'idêntic']],
          minGroups: 3,
          model: 'Um padrão de bits como 01000001 é apenas isso: oito estados ligado/desligado. Ele não "contém" um significado. O significado vem da convenção que o leitor aplica: lido como inteiro, é 65; lido como ASCII, é a letra "A"; lido como canal de cor, é uma intensidade fraca; lido por um processador, pode ser uma instrução. Os bits são idênticos em todos os casos; o que muda é o acordo sobre como interpretá-los. Em programação, os "tipos" são exatamente essas convenções.',
        },
      ],
    },
  ],
  boss: {
    title: 'Chefe da Fase 2: O Decifrador',
    intro: 'O Decifrador apresenta bytes crus e exige que você os leia sob diferentes convenções. Tenha a tabelinha hex (0–F) na cabeça.',
    passRatio: 0.8,
    exercises: [
      { type: 'input', id: 'f2-b1', q: 'Converta **0xC3** para binário (8 bits).', answer: '11000011', hints: ['C = 1100, 3 = 0011.'], explain: 'C3 → 1100 0011. (Esse é o primeiro byte do "ç" em UTF-8!)' },
      { type: 'input', id: 'f2-b2', q: 'Converta **0xC3** para decimal.', answer: '195', hints: ['12 × 16 + 3.'], explain: '192 + 3 = 195.' },
      { type: 'input', id: 'f2-b3', q: 'Converta **01011110** (binário) para hexadecimal.', answer: ['5E', '5e', '0x5E', '0x5e'], hints: ['0101 | 1110.'], explain: '5E. Em ASCII, 0x5E é o caractere "^".' },
      {
        type: 'mc', id: 'f2-b4', q: 'Os bytes **42 49 54** (hex) em ASCII formam qual palavra? (0x41=A, 0x42=B, 0x49=I, 0x54=T)',
        options: [{ t: 'BIT', ok: true, fb: 'B-I-T. Apropriado.' }, { t: 'BYT', fb: '0x49 não é Y. Confira: 0x49 = 73 = I.' }, { t: 'ABT', fb: '0x42 é B (A seria 0x41).' }],
        explain: 'Ler hex dumps é uma habilidade real de depuração.',
      },
      { type: 'input', id: 'f2-b5', q: 'Quantos **bits** há em 1 KiB (1.024 bytes)?', answer: ['8192', '8.192'], hints: ['1.024 × 8.'], explain: '8.192 bits = 2¹³.' },
      { type: 'input', id: 'f2-b6', q: 'A cor **#00FF00** é qual? Responda com uma palavra em português.', answer: ['verde'], hints: ['R=00, G=FF, B=00. Qual canal está no máximo?'], explain: 'Verde puro: só o canal G (green) está em 255.' },
      { type: 'gen', id: 'f2-b7', kind: 'dec2hex', count: 3, q: 'Rodada de decimal → hexadecimal.', explain: 'O Decifrador reconhece sua fluência.' },
      {
        type: 'mc', id: 'f2-b8', q: 'Um programa lê o byte 0x37 e mostra na tela "55" quando deveria mostrar "7". O que provavelmente aconteceu?',
        options: [{ t: 'O byte estava corrompido.', fb: 'Não há sinal de corrupção. Pense: 0x37 em ASCII é o caractere "7". E 0x37 em decimal é...' }, { t: 'O programa interpretou o caractere ASCII "7" (código 0x37 = 55) como se fosse o número 55.', ok: true, fb: 'Exato: confusão de convenção. O caractere "7" é 55; para obter o número 7, subtrai-se 48 (o código de "0").' }, { t: 'Hexadecimal não pode representar o número 7.', fb: '0x07 representa 7 perfeitamente. O problema é outro: qual convenção foi usada para ler 0x37?' }],
        explain: 'Esse é um bug REAL que você vai encontrar em programação: confundir o caractere de um dígito com o valor do dígito.',
      },
    ],
  },
  review: [
    { id: 'f2-r1', q: 'O que é um byte e quantos valores ele representa?', a: '8 bits; 256 valores (0 a 255).', answer: ['256'] },
    { id: 'f2-r2', q: 'Por que hexadecimal é prático para escrever bits?', a: 'Porque 16 = 2⁴: cada dígito hex é exatamente 4 bits; um byte = 2 dígitos.' },
    { id: 'f2-r3', q: 'Quanto vale 0xFF em decimal e em binário?', a: '255; 11111111.', answer: ['255'] },
    { id: 'f2-r4', q: 'Converta 1010 1100 para hex.', a: 'AC.', answer: ['AC', 'ac', '0xac', '0xAC'] },
    { id: 'f2-r5', q: 'Código ASCII de "A" e de "a"? Qual a relação?', a: '65 e 97; diferem em 32, ou seja, em um único bit.' },
    { id: 'f2-r6', q: 'O que é UTF-8 e por que é compatível com ASCII?', a: 'Regra para gravar code points Unicode em bytes; os 128 primeiros ocupam 1 byte igual ao ASCII, logo todo arquivo ASCII já é UTF-8 válido.' },
    { id: 'f2-r7', q: 'Quantos bits tem uma cor RGB "true color"?', a: '24 (3 bytes, um por canal).', answer: ['24'] },
    { id: 'f2-r8', q: 'Complete: "bits não têm significado; ..."', a: '... convenções dão significado a bits." Em programação, tipos são essas convenções.' },
  ],
  glossary: [
    { pt: 'byte', en: 'byte', def: 'Grupo de 8 bits. 256 valores.', origin: 'Werner Buchholz, IBM, 1956. Grafado com "y" para não confundir com "bit".' },
    { pt: 'nibble', en: 'nibble', def: 'Meio byte: 4 bits. Corresponde a um dígito hexadecimal.', origin: 'Trocadilho: *bite* = mordida; *nibble* = mordidinha.' },
    { pt: 'palavra', en: 'word', def: 'Grupo de bits com que o processador trabalha de uma vez (32 ou 64 bits, tipicamente).' },
    { pt: 'hexadecimal', en: 'hexadecimal (hex)', def: 'Base 16, dígitos 0–9 e A–F. Prefixo 0x. Cada dígito = 4 bits.', origin: 'Grego *hexa* (6) + latim *decem* (10).' },
    { pt: 'ASCII', en: 'ASCII', def: 'Tabela de 128 caracteres (7 bits) de 1963. A=65, a=97, "0"=48.', origin: 'American Standard Code for Information Interchange.' },
    { pt: 'Unicode', en: 'Unicode', def: 'Tabela universal de caracteres (>150 mil). Cada um tem um "code point" U+XXXX.' },
    { pt: 'UTF-8', en: 'UTF-8', def: 'Forma de gravar code points Unicode em 1 a 4 bytes, compatível com ASCII.', origin: 'Unicode Transformation Format, 8 bits. Thompson & Pike, 1992.' },
    { pt: 'pixel', en: 'pixel', def: 'Menor ponto de uma imagem digital; tipicamente 3 bytes (R, G, B).', origin: '*Picture element*.' },
    { pt: 'RGB', en: 'RGB', def: 'Red, Green, Blue: os três canais de cor de telas.' },
    { pt: 'tipo (de dado)', en: 'data type', def: 'Em programação, a convenção que diz como interpretar um conjunto de bits (inteiro, texto, etc.).' },
    { pt: 'arquitetura de von Neumann', en: 'von Neumann architecture', def: 'Modelo em que programas e dados ficam na mesma memória, como bits. Base de quase todo computador.' },
  ],
};
