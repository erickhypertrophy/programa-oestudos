import type { Phase } from '../lib/types';

export const phase7: Phase = {
  id: 'f7',
  num: 7,
  emoji: '🖥️',
  title: 'A máquina que obedece bits',
  subtitle: 'Juntando ULA, registradores e memória numa máquina que busca, decodifica e executa instruções: o nascimento do programa',
  goal: 'Ao final desta fase você vai entender o ciclo busca-decodifica-executa, o que é uma instrução de máquina e como ela é codificada em bits, como "pular" cria decisões e repetições, e vai estar pronto para entender o que uma linguagem de programação realmente faz.',
  sections: [
    {
      id: 's1',
      title: 'A ideia de von Neumann: o programa é dado',
      body: `
## O que falta para ser um computador

Temos uma ULA que faz contas, registradores que guardam valores e uma RAM endereçável. Mas quem **decide** qual conta fazer, com quais valores, e depois qual? Nas primeiras máquinas (como o ENIAC), isso era feito **reconfigurando fios e chaves à mão**. Mudar o "programa" levava dias.

> 📜 Em 1945, John von Neumann escreveu o *First Draft of a Report on the EDVAC*, descrevendo uma ideia que já circulava no grupo (Eckert, Mauchly e outros, com raízes no trabalho teórico de Alan Turing em 1936): **guardar as instruções na mesma memória que os dados, como números.** Para mudar o programa, basta escrever outros números na memória. Essa é a **arquitetura de von Neumann** (ou "programa armazenado"), e é o que torna um computador *universal*: a mesma máquina roda planilha, jogo ou navegador, dependendo só dos bits na memória.

Isso fecha o círculo com a Fase 2: lá dissemos que "programas também são bits". Agora vamos ver **como** uma sequência de bits vira ação.

## As partes da máquina

Vamos montar uma máquina mínima, didática, mas fiel aos princípios. Ela tem:

- **Memória**: 256 células de 8 bits (8 bits de endereço). Guarda dados **e** instruções.
- **Acumulador (A)**: um registrador de 8 bits onde as contas acontecem.
- **Contador de programa (PC)**: um registrador que guarda o **endereço da próxima instrução**. Começa em 0.
- **Registrador de instrução (IR)**: guarda a instrução que está sendo executada.
- **ULA**: soma, subtrai, compara.
- **Unidade de controle**: um circuito (decodificador + alguns flip-flops) que lê a instrução no IR e "liga os fios certos": qual registrador lê, se a ULA soma ou subtrai, se a memória grava, se o PC avança ou pula.

> ⚠️ **Simplificação avisada.** Máquinas reais têm dezenas de registradores, instruções de 16 a 64 bits, pipelines, caches, previsão de desvios, múltiplos núcleos. Mas **todas** têm PC, instruções codificadas em bits, ULA, e o ciclo que vamos ver. O Hack, computador do Nand2Tetris, é só um pouco maior que o nosso e roda Tetris. O princípio escala.

## O formato de uma instrução

Nossa instrução tem 8 bits: **3 bits de operação** (*opcode*, "código de operação") e **5 bits de endereço/argumento** (0 a 31; nossa memória útil para dados ficará nessas 32 primeiras células, por simplicidade).

| opcode | nome | significado |
|---|---|---|
| 000 | CARREGA end | A ← memória[end] |
| 001 | SOMA end | A ← A + memória[end] |
| 010 | SUB end | A ← A − memória[end] |
| 011 | GUARDA end | memória[end] ← A |
| 100 | PULA_SE_ZERO end | se A = 0, PC ← end (senão, continua) |
| 101 | PULA end | PC ← end |
| 110 | (reservado) | |
| 111 | PARA | para a máquina |

Então o byte **001 00110** significa "SOMA 6": pegue o valor da célula 6 e some ao acumulador. O byte **011 00111** é "GUARDA 7".

> 💡 Você está vendo a mesma lição da Fase 2 pela última vez: o byte 00100110 (= 38 = 0x26) é só um número. Interpretado pela unidade de controle, é a instrução SOMA 6. Interpretado como dado por outra instrução, é o número 38. **A diferença está em quem lê.** Se o PC apontar por engano para uma região de dados, a máquina tentará "executar" dados: é o que acontece em muitos travamentos e falhas de segurança (ataques de *buffer overflow* injetam dados que serão executados como código).

## O ciclo: buscar, decodificar, executar

A unidade de controle faz, **para sempre**, a cada poucos ciclos de clock:

1. **Buscar** (*fetch*): ler da memória a célula cujo endereço está no PC; colocar no IR. Somar 1 ao PC (o contador da Fase 6!).
2. **Decodificar** (*decode*): o decodificador (Fase 4) olha os 3 bits de opcode e ativa as linhas de controle da operação correspondente.
3. **Executar** (*execute*): a operação acontece: a ULA soma, o registrador carrega, a memória grava, ou o PC recebe um novo valor (pulo).
4. Voltar ao passo 1.

Isso é **tudo** o que um processador faz. Bilhões de vezes por segundo. Não há inteligência, intenção ou compreensão: há um decodificador ligando fios conforme padrões de bits, e um contador avançando. O "comportamento inteligente" que você vê na tela é a soma de bilhões desses passos tolos, organizados por quem escreveu os bits do programa.
`,
      exercises: [
        {
          type: 'input', id: 'f7-s1-e1',
          q: 'Escreva em binário (8 bits) a instrução **CARREGA 5** (opcode 000, endereço 5 em 5 bits).',
          answer: '00000101',
          hints: ['Opcode 000, depois 5 em 5 bits.', '5 = 00101.'],
          explain: '000 00101. Note que é o mesmo padrão do número 5. Só é "CARREGA 5" quando o PC aponta para ele.',
        },
        {
          type: 'input', id: 'f7-s1-e2',
          q: 'Decodifique: o byte **01100111** está no IR. Qual instrução é? (Responda no formato NOME NÚMERO, por exemplo "SOMA 3".)',
          answer: ['GUARDA 7', 'guarda 7', 'GUARDA 07'],
          hints: ['Separe: 011 | 00111.', '011 = GUARDA. 00111 = 7.'],
          explain: 'GUARDA 7: memória[7] ← A. Você acabou de fazer o trabalho da unidade de controle.',
        },
        {
          type: 'mc', id: 'f7-s1-e3',
          q: 'Qual é a ideia central da arquitetura de von Neumann?',
          options: [
            { t: 'Usar binário em vez de decimal.', fb: 'Isso também foi recomendado no relatório do EDVAC, mas não é a ideia central da ARQUITETURA.' },
            { t: 'Guardar as instruções do programa na mesma memória que os dados, como números, de modo que trocar o programa é só escrever outros números.', ok: true, fb: 'Exato: programa armazenado. É o que torna o computador universal e reprogramável.' },
            { t: 'Ter um relógio para sincronizar.', fb: 'O clock é essencial, mas é uma técnica de projeto, não a arquitetura de von Neumann.' },
          ],
          explain: 'Antes disso, "programar" era refazer fiação. Depois, virou escrever números. Depois, escrever texto que vira números (linguagens). É a história que você está prestes a entrar.',
        },
        {
          type: 'mc', id: 'f7-s1-e4',
          q: 'Por que somar 1 ao PC durante a busca é suficiente para a máquina executar instruções em sequência?',
          options: [
            { t: 'Porque instruções são sempre gravadas em células consecutivas; o PC incrementado aponta para a próxima.', ok: true, fb: 'Correto. O "fluxo normal" é só um contador. Pulos mudam o PC para outro lugar.' },
            { t: 'Porque a ULA precisa de um 1 para funcionar.', fb: 'A ULA não tem relação com isso. O incremento é sobre o endereço da próxima instrução.' },
            { t: 'Porque o PC conta quantas instruções já foram executadas.', fb: 'Ele poderia servir para isso por acaso, mas sua função é guardar o ENDEREÇO da próxima instrução, e pulos quebram essa contagem.' },
          ],
          explain: 'O PC é o registrador + somador da Fase 6. Sem pulos, um programa é só uma lista lida de cima para baixo.',
        },
      ],
    },
    {
      id: 's2',
      title: 'Executando à mão: seu primeiro programa de máquina',
      body: `
## Programa: somar dois números

Queremos somar o conteúdo da célula 5 com o da célula 6 e guardar na célula 7. Em instruções:

| endereço | bits | instrução | efeito |
|---|---|---|---|
| 0 | 000 00101 | CARREGA 5 | A ← mem[5] |
| 1 | 001 00110 | SOMA 6 | A ← A + mem[6] |
| 2 | 011 00111 | GUARDA 7 | mem[7] ← A |
| 3 | 111 00000 | PARA | fim |
| ... | | | |
| 5 | 00000011 | (dado) 3 | |
| 6 | 00000100 | (dado) 4 | |
| 7 | 00000000 | (dado) resultado | |

Repare: as células 0–3 contêm instruções; as 5–7, dados. **Para a memória, é tudo byte.** A única coisa que distingue é que o PC começa em 0 e passa por 0, 1, 2, 3.

## Rastreando

Vamos ser a unidade de controle. Estado inicial: PC = 0, A = ?.

1. **Busca**: IR ← mem[0] = 00000101. PC ← 1. **Decodifica**: 000 = CARREGA, end = 5. **Executa**: A ← mem[5] = 3.
2. **Busca**: IR ← mem[1] = 00100110. PC ← 2. **Decodifica**: 001 = SOMA, end = 6. **Executa**: A ← 3 + mem[6] = 3 + 4 = 7.
3. **Busca**: IR ← mem[2] = 01100111. PC ← 3. **Decodifica**: 011 = GUARDA, end = 7. **Executa**: mem[7] ← 7.
4. **Busca**: IR ← mem[3] = 11100000. PC ← 4. **Decodifica**: 111 = PARA. **Executa**: máquina para.

Resultado: mem[7] = 7. ✓

Execute passo a passo abaixo, mudando os dados nas células 5 e 6:

[[demo:cpu]]

## Isso é programação?

Sim. É programação no nível mais baixo que existe: **linguagem de máquina**. Os primeiros programadores (muitas delas mulheres, como as "ENIAC girls" e Grace Hopper) escreviam exatamente assim: bits, em painéis de chaves ou cartões perfurados.

Logo perceberam que era insuportável e criaram uma camada acima: a **linguagem de montagem** (*assembly*), em que se escreve "SOMA 6" em texto e um programa chamado **montador** (*assembler*) converte para 00100110. É o que a coluna "instrução" da tabela acima já é. O montador é um programa que traduz texto para bits, e ele próprio é feito de bits. (Como se escreveu o primeiro montador? Em bits, à mão. Depois, usou-se o primeiro para escrever o segundo. Esse processo se chama *bootstrapping*, "puxar-se pelas próprias botas".)

## Onde cada fase está dentro desta máquina

Faça a arqueologia:

- A memória guarda **bits** (Fase 0) agrupados em **bytes** (Fase 2).
- Os endereços e dados são **números binários** (Fase 1).
- A unidade de controle é um **decodificador** e **lógica booleana** (Fases 3–4).
- A ULA é o **somador** e o **complemento de dois** (Fase 5).
- PC, A, IR são **registradores**; o avanço do PC é um **contador**; a memória é a **RAM**; tudo sincronizado por um **clock** (Fase 6).

Não há mais nada. Essa máquina é NAND, repetida, mais a convenção sobre o que cada padrão de bits significa.
`,
      exercises: [
        {
          type: 'input', id: 'f7-s2-e1',
          q: 'Rastreie: mem[5] = 10, mem[6] = 25, programa igual ao do texto (CARREGA 5, SOMA 6, GUARDA 7, PARA). Qual será o valor final de mem[7]?',
          answer: '35',
          hints: ['A ← 10; A ← 10 + 25; mem[7] ← A.'],
          explain: '35. Você executou um programa de máquina com a cabeça.',
        },
        {
          type: 'input', id: 'f7-s2-e2',
          q: 'Agora o programa é: CARREGA 5, **SUB** 6, GUARDA 7, PARA, com mem[5] = 3 e mem[6] = 4. Qual é o valor de mem[7] lido **sem sinal** (0–255)? Lembre-se da Fase 5.',
          answer: '255',
          hints: ['3 − 4 = −1. Em 8 bits, −1 em complemento de dois é...', '11111111 = 255 sem sinal.'],
          explain: '3 − 4 = −1 = 11111111 = 255 sem sinal. A máquina não sabe se é −1 ou 255; os bits são os mesmos. Fase 5 de volta.',
        },
        {
          type: 'input', id: 'f7-s2-e3',
          q: 'Escreva o byte (8 bits) da instrução **SUB 6**.',
          answer: '01000110',
          hints: ['Opcode de SUB é 010. 6 = 00110.'],
          explain: '010 00110. Você é o montador (assembler).',
        },
        {
          type: 'mc', id: 'f7-s2-e4',
          q: 'O que acontece se o programador errar e colocar o dado "3" na célula 3 em vez da célula 5 (onde estava o PARA)?',
          options: [
            { t: 'A máquina detecta o erro e avisa.', fb: 'A máquina não tem como saber. Para ela, a célula 3 é só um byte que o PC alcançou.' },
            { t: 'Ao chegar em PC = 3, a máquina busca 00000011 e o executa como instrução: opcode 000 = CARREGA 3. Ela continua executando "lixo" até encontrar algo que a pare ou travar.', ok: true, fb: 'Exato. Dados executados como código: a origem de muitos travamentos e falhas de segurança.' },
            { t: 'Nada, porque 3 não é uma instrução válida.', fb: 'Todo byte é uma instrução "válida" para o decodificador: 00000011 decodifica como CARREGA 3.' },
          ],
          explain: 'Sistemas modernos marcam regiões de memória como "não executáveis" (bit NX) justamente para mitigar isso. Mas a raiz é esta: bits são bits.',
        },
      ],
    },
    {
      id: 's3',
      title: 'Pular: como nascem decisões e repetições',
      body: `
## Sem pulos, nada de interessante

Um programa que só vai de cima para baixo é uma calculadora de uma conta só. O poder vem de duas instruções que **mexem no PC**:

- **PULA end**: PC ← end. A próxima instrução não é a seguinte, é a do endereço dado.
- **PULA_SE_ZERO end**: se A = 0, PC ← end; senão, segue normalmente.

A segunda é um **pulo condicional**. Em hardware, é um MUX (Fase 4): a seleção é "A é zero?" (um NOR de todos os bits de A, ou um comparador), a entrada 0 é PC + 1, a entrada 1 é o endereço de destino. Uma única porta de decisão.

> 💡 **Toda** estrutura de controle de **toda** linguagem de programação (if, else, while, for, funções, exceções) é construída, no fundo, com pulos condicionais e incondicionais. Não há mágica adicional no processador. Quando você escrever seu primeiro \`if\` em Python, saiba que ele vira um "pula se" em algum lugar.

## Um "se" em linguagem de máquina

Problema: se mem[5] for zero, guardar 1 em mem[7]; senão, guardar 2.

| end | instrução | comentário |
|---|---|---|
| 0 | CARREGA 5 | A ← mem[5] |
| 1 | PULA_SE_ZERO 5 | se A = 0, vai para 5 |
| 2 | CARREGA 9 | (caso "senão") A ← mem[9] = 2 |
| 3 | GUARDA 7 | mem[7] ← 2 |
| 4 | PARA | |
| 5 | CARREGA 8 | (caso "se") A ← mem[8] = 1 |
| 6 | GUARDA 7 | mem[7] ← 1 |
| 7 | PARA | |
| 8 | (dado) 1 | |
| 9 | (dado) 2 | |

Em Python isso é \`resultado = 1 if x == 0 else 2\`. A linguagem esconde os endereços, os pulos e os dados espalhados. Mas é isso que acontece.

## Um "enquanto" em linguagem de máquina: contagem regressiva

Problema: diminuir mem[5] de 1 em 1 até chegar a zero (um laço). Precisamos de uma célula com o valor 1 para subtrair (mem[9] = 1).

| end | instrução | comentário |
|---|---|---|
| 0 | CARREGA 5 | A ← contador |
| 1 | PULA_SE_ZERO 5 | se chegou a zero, sai do laço (vai para 5) |
| 2 | SUB 9 | A ← A − 1 |
| 3 | GUARDA 5 | contador ← A |
| 4 | PULA 0 | volta ao início do laço |
| 5 | PARA | |
| 9 | (dado) 1 | |

Rastreie com mem[5] = 2: A=2 → não é zero → A=1 → guarda → pula para 0 → A=1 → não é zero → A=0 → guarda → pula para 0 → A=0 → **é zero** → pula para 5 → PARA. O laço rodou duas vezes. Em Python: \`while x != 0: x = x - 1\`.

Com laços e decisões, essa máquina de 8 instruções é, em princípio, capaz de calcular **qualquer coisa computável** (dada memória suficiente). Isso é o que Alan Turing provou em 1936 sobre máquinas desse tipo, e é chamado de **completude de Turing**. Seu celular, um supercomputador e esta maquininha são, nesse sentido teórico, equivalentes: diferem em velocidade e memória, não em *o que* podem calcular.

> 📜 Turing (1936) descreveu a máquina abstrata; von Neumann e colegas (1945) desenharam como construí-la com eletrônica; Shannon (1937) mostrou que a eletrônica realiza a lógica de Boole (1854); e tudo repousa no bit, formalizado por Shannon (1948), realizado por transistores (1947). Em 100 anos, a humanidade foi da lógica abstrata ao computador universal, e você acabou de percorrer esse caminho.

## O que as linguagens de programação fazem

Agora dá para dizer com precisão o que é uma **linguagem de programação**: uma notação para humanos, com **variáveis** (nomes para células de memória, em vez de endereços), **expressões** (contas que viram sequências de instruções de ULA), **estruturas de controle** (if/while, que viram pulos) e **funções** (trechos de código reutilizáveis, que viram pulos com retorno). Um programa chamado **compilador** traduz isso tudo para bits de máquina, e um **interpretador** faz algo parecido em tempo real.

Quando você escreve:

\`\`\`python
x = 3
y = 4
z = x + y
\`\`\`

alguma coisa, em algum nível, faz: reserve células para x, y, z; escreva 3 e 4; CARREGA x; SOMA y; GUARDA z. Você já sabe o que cada um desses passos é, fisicamente, até o transistor.
`,
      exercises: [
        {
          type: 'mc', id: 'f7-s3-e1',
          q: 'Como um pulo condicional é implementado em hardware?',
          options: [
            { t: 'Com um multiplexador que escolhe entre PC+1 e o endereço de destino, controlado por um sinal que indica se a condição vale (ex.: A = 0).', ok: true, fb: 'Exato. A decisão do programa é literalmente um MUX da Fase 4.' },
            { t: 'Com um somador especial.', fb: 'O somador calcula PC+1, mas a DECISÃO é feita por outro bloco. Qual bloco escolhe entre duas opções?' },
            { t: 'Com memória adicional.', fb: 'Não precisa de memória extra. É lógica combinacional escolhendo o próximo valor do PC.' },
          ],
          explain: 'if/while/for de qualquer linguagem = MUX no caminho do PC.',
        },
        {
          type: 'input', id: 'f7-s3-e2',
          q: 'No programa de contagem regressiva do texto, se mem[5] começa em **5**, quantas vezes a instrução **SUB 9** (endereço 2) é executada?',
          answer: '5',
          hints: ['Cada volta do laço subtrai 1 e só sai quando A é zero.', 'De 5 até 0 são 5 subtrações.'],
          explain: '5 vezes. A verificação "é zero?" acontece 6 vezes (a última sai do laço). Esse tipo de contagem "de um a mais ou a menos" é fonte clássica de bugs em programação.',
        },
        {
          type: 'input', id: 'f7-s3-e3',
          q: 'Escreva em bits (8 bits) a instrução **PULA_SE_ZERO 5** (opcode 100).',
          answer: '10000101',
          hints: ['100 | 00101.'],
          explain: '100 00101 = 0x85 = 133. Um "if" cabe em um byte.',
        },
        {
          type: 'mc', id: 'f7-s3-e4',
          q: 'O que significa dizer que nossa máquina de 8 instruções é "Turing-completa"?',
          options: [
            { t: 'Que ela é tão rápida quanto um computador moderno.', fb: 'Não é sobre velocidade. É sobre O QUE pode ser calculado.' },
            { t: 'Que, com memória suficiente, ela pode calcular qualquer coisa que qualquer outro computador pode calcular; a diferença é só velocidade e memória.', ok: true, fb: 'Correto. Turing (1936). Pulos condicionais + memória + aritmética básica bastam.' },
            { t: 'Que ela foi projetada por Alan Turing.', fb: 'Turing descreveu a máquina abstrata; o termo homenageia a prova dele, não a autoria do projeto.' },
          ],
          explain: 'É libertador: você não precisa de uma máquina "melhor" para aprender a programar; precisa de ideias melhores.',
        },
        {
          type: 'explain', id: 'f7-s3-e5',
          q: 'Explique o ciclo busca-decodifica-executa com suas palavras, dizendo qual peça das fases anteriores faz cada passo.',
          keywords: [['busca', 'fetch', 'lê', 'ler'], ['pc', 'contador de programa', 'endereço'], ['decodific', 'decode', 'opcode'], ['executa', 'ula', 'soma', 'grava', 'registrador'], ['memória', 'ram', 'célula']],
          minGroups: 4,
          model: 'Busca: o endereço no PC (um registrador, Fase 6) é enviado à RAM (Fase 6), que devolve o byte da instrução para o IR; o PC é incrementado por um somador (Fase 5). Decodificação: um decodificador (Fase 4) lê o opcode e ativa as linhas de controle. Execução: dependendo das linhas, a ULA (Fase 5) soma/subtrai, um registrador carrega, a RAM grava ou um MUX (Fase 4) troca o PC para um endereço de pulo. Tudo sincronizado pelo clock (Fase 6). Depois, recomeça.',
        },
      ],
    },
    {
      id: 's4',
      title: 'Onde você está e o que vem depois',
      body: `
## O que você construiu

Faça uma pausa e olhe para trás. Você começou com uma lamparina no vale. Hoje você sabe, **sem lacunas**, como se vai de "dois estados" até "um programa rodando":

1. **Bit**: a menor unidade de informação; dois estados físicos + convenção.
2. **Números**: notação posicional em base 2; conversões; potências de 2; MSB/LSB.
3. **Representação**: bytes, hexadecimal, ASCII/Unicode, cores; "bits não têm significado, convenções têm".
4. **Lógica**: AND/OR/NOT/XOR/NAND/NOR; tabelas-verdade; De Morgan; toda função é soma de produtos.
5. **Portas**: interruptores em série/paralelo; transistores; NAND universal; MUX e decodificador.
6. **Aritmética**: meio-somador, somador completo, somador de n bits; complemento de dois; overflow; ULA.
7. **Memória**: realimentação, latch, flip-flop, clock, registradores, RAM endereçável.
8. **Máquina**: programa armazenado; instruções em bits; busca-decodifica-executa; pulos; Turing-completude.

Nenhuma dessas camadas foi um "porque sim". Cada uma foi construída sobre a anterior com uma justificativa que você pode reconstruir.

## Onde começa e termina a base (resposta final)

A fundação de toda a computação é **a representação de informação como bits e sua manipulação por lógica booleana realizada em hardware, até o ponto em que bits guardados na memória são executados como instruções**. Começa no bit; termina no ciclo busca-decodifica-executa. Abaixo está a física dos semicondutores (não é computação). Acima está o software: linguagens, sistemas operacionais, redes, aplicativos. **Tudo acima é organização de bits usando as peças que você conhece.**

## O que foi simplificado (honestidade final)

- Transistores foram tratados como interruptores ideais. A realidade envolve física quântica e analógica.
- O somador de ondulação é lento; chips reais usam antecipação de vai-um e outras técnicas.
- Nossa máquina tem 8 instruções e 1 acumulador; processadores reais têm centenas de instruções, dezenas de registradores, pipelines (várias instruções em voo), execução fora de ordem, caches de vários níveis e múltiplos núcleos. **Nenhuma dessas coisas muda o princípio**; todas são otimizações de velocidade.
- Ponto flutuante (números com vírgula), multiplicação/divisão em hardware, e interrupções (como o teclado "avisa" o processador) foram só mencionados.
- Unicode e codificações têm muito mais detalhes.

Se você quiser ir mais fundo em hardware, o próximo passo natural é o **Nand2Tetris** (nand2tetris.org; livro *The Elements of Computing Systems*, Nisan & Schocken, MIT Press; curso gratuito no Coursera), que faz tudo isto com um simulador de hardware real e vai até um sistema operacional e um Tetris. Você já tem toda a base conceitual para a Parte I. O livro *Code: The Hidden Language of Computer Hardware and Software* (Charles Petzold, 2ª ed. 2022) conta essa mesma história com mais detalhes históricos e desenhos de circuitos; há tradução em português ("Código").

## Próximos passos rumo à programação

Você agora pode aprender uma linguagem de programação **entendendo o que está por baixo**, o que é raro e valioso. Sugestão de caminho:

1. **Python** como primeira linguagem: sintaxe limpa, foco nas ideias. Quando aparecer \`x = 5\`, você sabe: um nome para uma célula de memória com 00000101. Quando aparecer \`if\`, você sabe: um pulo condicional, um MUX. Quando aparecer \`int\` vs \`str\`, você sabe: convenções de interpretação de bits. Recursos gratuitos e em português: o curso "Python para Zumbis" (USP), o livro "Pense em Python" (tradução de *Think Python*), e a documentação oficial em português.
2. **Depois**, uma passada por **C**: é a linguagem que mais expõe o que você aprendeu (tipos com tamanho fixo em bits, overflow, endereços de memória explícitos, complemento de dois nu). *The C Programming Language* (Kernighan & Ritchie) ou o CS50 de Harvard (gratuito, legendas em português).
3. **Em paralelo**, continue a **revisão espaçada** deste jogo por algumas semanas: as fichas vão aparecer em intervalos crescentes. O que você construiu só se consolida com recuperação repetida ao longo do tempo (Roediger & Karpicke, 2006; Karpicke & Roediger, 2008).
4. Quando se sentir pronto, **Nand2Tetris Parte I** fecha o ciclo construindo tudo isto num simulador, e a **Parte II** sobe pelas camadas de software (montador, máquina virtual, compilador, sistema operacional), que é exatamente a ponte entre este curso e "programar de verdade".

## A última lição

Aprender a programar não é decorar comandos. É aprender a **organizar bits para que uma máquina tola produza comportamento útil**. Você agora entende a máquina. O resto é prática, projetos e paciência com os próprios erros, que, como você viu, são produtivos.

Agora enfrente o Chefe Final. Ele revisita todas as fases.
`,
      exercises: [
        {
          type: 'explain', id: 'f7-s4-e1',
          q: 'Escreva, com suas palavras, a cadeia completa: do bit ao programa. Uma frase por camada é suficiente, mas não pule camadas.',
          keywords: [['bit'], ['binário', 'número', 'base 2', 'posicional'], ['byte', 'hexadecimal', 'ascii', 'convenção', 'representa'], ['boole', 'lógica', 'and', 'or', 'tabela'], ['porta', 'nand', 'transistor'], ['somador', 'ula', 'complemento', 'aritmética'], ['memória', 'latch', 'flip-flop', 'registrador', 'ram', 'clock', 'relógio'], ['instrução', 'programa', 'pc', 'busca', 'executa', 'von neumann']],
          minGroups: 6,
          model: 'Um bit é um sistema com dois estados mais uma convenção. Agrupados e lidos com pesos de potências de 2, bits representam números. Com outras convenções (ASCII, RGB), representam texto, cores e qualquer coisa. A álgebra de Boole diz como combinar bits com AND, OR e NOT, e toda tabela-verdade pode ser escrita assim. Portas lógicas realizam essa álgebra fisicamente com transistores, e NAND sozinha constrói todas. Com portas constroem-se somadores e a ULA; o complemento de dois dá negativos e subtração de graça. Realimentação cria latches e flip-flops; com um clock, registradores e RAM endereçável. Finalmente, instruções codificadas em bits são guardadas na memória e um ciclo busca-decodifica-executa, com pulos condicionais, as executa: nasce o programa.',
        },
        {
          type: 'mc', id: 'f7-s4-e2',
          q: 'Quando você escrever em Python `if x == 0:` qual é a tradução mais fiel para o que acontece no hardware?',
          options: [
            { t: 'O computador "entende" a pergunta e responde.', fb: 'Não há entendimento. Há circuitos. Quais?' },
            { t: 'Os bits de x são comparados com zero (ex.: um NOR de todos os bits), e o resultado controla um MUX que escolhe o próximo valor do PC: continuar ou pular.', ok: true, fb: 'Exato. Um if é um pulo condicional, que é um MUX no caminho do PC.' },
            { t: 'Python envia a pergunta para a internet.', fb: 'Não. Tudo acontece localmente, em lógica combinacional e registradores.' },
          ],
          explain: 'Você vai programar sabendo o que acontece embaixo. Isso muda a forma de pensar sobre erros, desempenho e limites.',
        },
      ],
    },
  ],
  boss: {
    title: 'CHEFE FINAL: O Arquiteto',
    intro: 'O Arquiteto percorre todas as fases. Não há consulta. Se você chegou aqui dominando cada chefe anterior, está pronto. Respire e vá.',
    passRatio: 0.8,
    exercises: [
      { type: 'input', id: 'f7-b1', q: '[Fase 0] Quantos bits para distinguir 1.000 itens?', answer: '10', hints: ['2¹⁰ = 1.024.'], explain: '10 bits.' },
      { type: 'input', id: 'f7-b2', q: '[Fase 1] Converta 11011001 para decimal.', answer: '217', hints: ['128+64+16+8+1.'], explain: '217.' },
      { type: 'input', id: 'f7-b3', q: '[Fase 2] Converta 11011001 para hexadecimal.', answer: ['D9', 'd9', '0xD9', '0xd9'], hints: ['1101 | 1001.'], explain: 'D9.' },
      { type: 'truth', id: 'f7-b4', q: '[Fase 3] Preencha **NOT(A AND B)** — e lembre o que De Morgan diz sobre ela.', vars: ['A', 'B'], label: 'NAND', fn: (v) => !(v[0] && v[1]), explain: '= (NOT A) OR (NOT B).' },
      { type: 'circuit', id: 'f7-b5', q: '[Fase 4] Construa **A OR B** só com NAND.', inputs: ['A', 'B'], target: (v) => v[0] || v[1], allowed: ['NAND'], maxGates: 3, hints: ['NAND(A,A), NAND(B,B), NAND(g1,g2).'], explain: 'De Morgan em fios.' },
      { type: 'input', id: 'f7-b6', q: '[Fase 5] Escreva −7 em complemento de dois com 8 bits.', answer: '11111001', hints: ['7 = 00000111 → inverte 11111000 → +1.'], explain: '11111001. Confira: −128+64+32+16+8+1 = −7.' },
      {
        type: 'mc', id: 'f7-b7', q: '[Fase 5] Em 8 bits sem sinal, 255 + 1 = ?',
        options: [{ t: '256', fb: 'Não cabe em 8 bits.' }, { t: '0', ok: true, fb: 'Overflow: dá a volta.' }, { t: '255', fb: 'Somadores não saturam.' }],
        explain: 'Aritmética modular.',
      },
      {
        type: 'mc', id: 'f7-b8', q: '[Fase 6] O que diferencia um flip-flop de um circuito combinacional?',
        options: [{ t: 'O flip-flop guarda um valor entre bordas do clock, graças à realimentação; o combinacional só reflete as entradas atuais.', ok: true, fb: 'Correto.' }, { t: 'O flip-flop é mais rápido.', fb: 'Velocidade não é a distinção. Memória é.' }, { t: 'O flip-flop usa mais energia.', fb: 'Não é a distinção conceitual.' }],
        explain: 'Memória = realimentação + sincronização.',
      },
      { type: 'input', id: 'f7-b9', q: '[Fase 6] RAM com 24 bits de endereço e células de 1 byte: quantos MiB? (1 MiB = 2²⁰ bytes)', answer: '16', hints: ['2²⁴ / 2²⁰ = 2⁴.'], explain: '16 MiB.' },
      { type: 'input', id: 'f7-b10', q: '[Fase 7] Decodifique o byte **10100000** na nossa máquina (formato NOME NÚMERO).', answer: ['PULA 0', 'pula 0', 'PULA 00'], hints: ['101 | 00000.'], explain: 'PULA 0: volta para o início. Um laço infinito de um byte.' },
      {
        type: 'explain', id: 'f7-b11', q: '[Todas] Por que se diz que "um computador é NAND repetida mais convenções"? Defenda ou critique a frase.',
        keywords: [['nand', 'universal', 'porta'], ['convenção', 'interpret', 'significado'], ['memória', 'realimenta', 'flip-flop', 'clock', 'tempo'], ['instru', 'programa', 'bits'], ['simplific', 'mas', 'porém', 'além']],
        minGroups: 3,
        model: 'A frase é defensável: toda função booleana se constrói com NAND, a aritmética é lógica booleana, e até a memória é feita de portas realimentadas; a interpretação dos bits (números, texto, instruções) é pura convenção. Mas é uma simplificação: além das portas, é essencial a estrutura temporal (realimentação sincronizada por clock), que transforma lógica sem memória em máquina com estado, e a arquitetura de programa armazenado, que faz bits serem executados. Então: NAND + realimentação/tempo + convenções = computador.',
      },
    ],
  },
  review: [
    { id: 'f7-r1', q: 'Qual a ideia central da arquitetura de von Neumann?', a: 'Programa armazenado: instruções na mesma memória que os dados, como números.' },
    { id: 'f7-r2', q: 'Quais são os três passos do ciclo de instrução?', a: 'Buscar (fetch), decodificar (decode), executar (execute).' },
    { id: 'f7-r3', q: 'O que é o PC?', a: 'Program counter: registrador com o endereço da próxima instrução; incrementado a cada busca, alterado por pulos.' },
    { id: 'f7-r4', q: 'Como um "if" é implementado em hardware?', a: 'Pulo condicional: um MUX escolhe entre PC+1 e o endereço de destino conforme uma condição (ex.: A = 0).' },
    { id: 'f7-r5', q: 'O que é um opcode?', a: 'Os bits de uma instrução que indicam qual operação executar.' },
    { id: 'f7-r6', q: 'O que faz um montador (assembler)?', a: 'Traduz texto como "SOMA 6" para bits de máquina como 00100110.' },
    { id: 'f7-r7', q: 'O que significa Turing-completo?', a: 'Capaz de calcular qualquer coisa computável, dada memória suficiente.' },
    { id: 'f7-r8', q: 'Por que executar dados como código é perigoso?', a: 'Porque para a máquina bits são bits; o decodificador executa qualquer byte que o PC alcance. Base de ataques de buffer overflow.' },
  ],
  glossary: [
    { pt: 'programa armazenado', en: 'stored program', def: 'Instruções guardadas na memória como dados.' },
    { pt: 'acumulador', en: 'accumulator', def: 'Registrador onde as operações da ULA acontecem (máquinas simples).' },
    { pt: 'contador de programa', en: 'program counter (PC)', def: 'Registrador com o endereço da próxima instrução.' },
    { pt: 'registrador de instrução', en: 'instruction register (IR)', def: 'Guarda a instrução em execução.' },
    { pt: 'unidade de controle', en: 'control unit', def: 'Circuito que decodifica instruções e ativa os sinais de controle.' },
    { pt: 'código de operação', en: 'opcode', def: 'Bits da instrução que identificam a operação.' },
    { pt: 'busca-decodifica-executa', en: 'fetch-decode-execute', def: 'O ciclo eterno do processador.' },
    { pt: 'linguagem de máquina', en: 'machine language / machine code', def: 'Instruções em bits, diretamente executáveis.' },
    { pt: 'linguagem de montagem', en: 'assembly language', def: 'Texto legível (SOMA 6) traduzido 1:1 para máquina por um montador (assembler).' },
    { pt: 'pulo / desvio', en: 'jump / branch', def: 'Instrução que altera o PC. Condicional = decisão; para trás = laço.' },
    { pt: 'compilador / interpretador', en: 'compiler / interpreter', def: 'Programas que traduzem linguagens de alto nível para instruções de máquina (antes / durante a execução).' },
    { pt: 'Turing-completo', en: 'Turing-complete', def: 'Capaz de computar tudo o que é computável.' },
    { pt: 'bootstrapping', en: 'bootstrapping', def: 'Usar uma ferramenta simples para construir uma mais complexa (ex.: o primeiro montador escrito em bits).' },
    { pt: 'variável', en: 'variable', def: 'Em linguagens, um nome para uma célula (ou região) de memória.' },
  ],
};
