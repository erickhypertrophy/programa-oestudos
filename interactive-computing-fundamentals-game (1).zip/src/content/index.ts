import type { Phase, ReviewCard, GlossaryEntry } from '../lib/types';
import { phase0 } from './phase0';
import { phase1 } from './phase1';
import { phase2 } from './phase2';
import { phase3 } from './phase3';
import { phase4 } from './phase4';
import { phase5 } from './phase5';
import { phase6 } from './phase6';
import { phase7 } from './phase7';

export const PHASES: Phase[] = [phase0, phase1, phase2, phase3, phase4, phase5, phase6, phase7];

export const ALL_CARDS: Record<string, ReviewCard & { phase: string }> = Object.fromEntries(
  PHASES.flatMap((p) => p.review.map((c) => [c.id, { ...c, phase: p.id }])),
);

export const ALL_GLOSSARY: (GlossaryEntry & { phase: string; num: number })[] = PHASES.flatMap((p) =>
  p.glossary.map((g) => ({ ...g, phase: p.id, num: p.num })),
);

export function phaseById(id: string): Phase | undefined {
  return PHASES.find((p) => p.id === id);
}

export function totalExercises(p: Phase): number {
  return p.sections.reduce((a, s) => a + s.exercises.length, 0) + p.boss.exercises.length;
}
