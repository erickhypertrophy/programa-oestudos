import type { Phase } from '../lib/types';

export const phase6: Phase = {
  id: 'f6',
  num: 6,
  emoji: '🧠',
  title: 'Circuitos que lembram',
  subtitle: 'Realimentação, o latch, o flip-flop, o relógio, registradores e a memória endereçável: como bits ficam guardados no tempo',
  goal: 'Ao final desta fase você vai entender como um circuito feito de portas (que, sozinhas, não têm memória) consegue lembrar um bit, por que o relógio existe, o que é um registrador, e como a RAM localiza um byte entre bilhões.',
  sections: [
    {
      id: 's1',
      title: 'O truque da realimentação: o latch SR',
      body: `
## O que falta

Tudo o que construímos até agora é **combinacional**: a saída é função das entradas *agora*. Solte o botão e a saída some. Mas um computador precisa **lembrar**: o resultado da última conta, onde está no programa, o seu documento. Como fazer um circuito que mantenha um valor depois que a entrada que o causou desaparece?

> 🧪 **Tente antes de ler.** Você tem duas portas NOR. Lembre-se: NOR dá 1 só quando ambas as entradas são 0. Que tal ligar a saída de cada uma numa entrada da outra? O que acontece? Tente seguir os sinais no papel por um minuto.

## Quebrando a regra: ligar a saída de volta na entrada

Pegue duas portas NOR. Ligue a saída da primeira numa entrada da segunda, e a saída da segunda numa entrada da primeira. Sobram uma entrada livre em cada: chame-as de **S** (*set*, "ligar") e **R** (*reset*, "desligar"). Chame a saída da segunda de **Q** e a da primeira de Q̄ ("Q barra", o oposto de Q).

\`\`\`
R ───┐
     NOR ──┬──── Q
  ┌──┘     │
  │  ┌─────┘  (cruzados)
  └──┼─────┐
     │     │
S ───┤     │
     NOR ──┴──── Q̄
\`\`\`

Vamos analisar. Comece com S = 0, R = 0 e suponha Q = 1 (e portanto Q̄ = 0).

- Porta de cima: NOR(R=0, Q̄=0) = 1. Então Q = 1. ✓ Consistente.
- Porta de baixo: NOR(S=0, Q=1) = 0. Então Q̄ = 0. ✓ Consistente.

Tudo se sustenta. Agora suponha o oposto: Q = 0, Q̄ = 1, ainda com S = R = 0.

- Cima: NOR(0, 1) = 0 → Q = 0. ✓
- Baixo: NOR(0, 0) = 1 → Q̄ = 1. ✓

**Também se sustenta!** Com S = R = 0, o circuito tem **dois estados estáveis**, e fica no que estiver. Ele **lembra**. Isso não acontecia em nenhum circuito combinacional: lá, dadas as entradas, só havia uma saída possível.

## Gravando um valor

Agora pulse S = 1 (com R = 0), partindo de Q = 0:

- Baixo: NOR(S=1, Q=0) = 0 → Q̄ vira 0.
- Cima: NOR(R=0, Q̄=0) = 1 → Q vira 1.
- Baixo de novo: NOR(S=1, Q=1) = 0 → Q̄ = 0. Estável.

Agora solte S (S = 0). Cima: NOR(0, 0) = 1 → Q continua 1. Baixo: NOR(0, 1) = 0 → Q̄ continua 0. **Q ficou em 1 mesmo com S de volta a 0.** Gravamos um bit.

Pulsar R = 1 faz o simétrico: Q vai para 0 e fica.

| S | R | Q (depois) | significado |
|---|---|---|---|
| 0 | 0 | Q (anterior) | **lembra** |
| 1 | 0 | 1 | set (grava 1) |
| 0 | 1 | 0 | reset (grava 0) |
| 1 | 1 | ? | proibido (ambas saídas 0; ao soltar, imprevisível) |

Esse circuito é o **latch SR** (*SR latch*; *latch* = "trinco", "tranca"). É a menor memória possível: 1 bit, 2 portas.

[[demo:sr-latch]]

## Por que isso é profundo

Note o que mudou. A tabela acima tem uma linha cuja saída é "Q anterior": **a saída depende do passado**, não só do presente. Introduzimos o **tempo** na lógica. Circuitos assim se chamam **sequenciais**, e a física que permite isso é a **realimentação** (*feedback*): a saída volta para a entrada e se auto-sustenta.

> 💡 Fisicamente, o que mantém o bit é um **laço de reforço**: Q=1 força Q̄=0, que força Q=1, que força Q̄=0... Enquanto houver energia, o laço se mantém. Desligue a energia e ele some. É por isso que a RAM é **volátil**: apaga quando o computador desliga. (SSDs e HDs usam outros mecanismos físicos, não realimentação, para guardar sem energia.)

> ⚠️ **Simplificação avisada.** Células de RAM reais (SRAM) usam 6 transistores, não exatamente dois NORs, mas o princípio é idêntico: dois inversores cruzados. A DRAM (a RAM principal do seu PC) é diferente: guarda carga num capacitor minúsculo e precisa ser "refrescada" milhares de vezes por segundo porque a carga vaza. Mas a DRAM ainda é lida/escrita através de latches. O conceito de realimentação é o fundamento.
`,
      exercises: [
        {
          type: 'mc', id: 'f6-s1-e1',
          q: 'O que torna o latch SR diferente de todos os circuitos das fases anteriores?',
          options: [
            { t: 'Ele usa portas NOR, que são mais poderosas.', fb: 'NOR não é "mais poderosa": você construiu NOR com NAND. A diferença está na forma como as portas estão LIGADAS.' },
            { t: 'A saída é realimentada para a entrada, criando dois estados estáveis; assim a saída depende do passado, não só das entradas atuais.', ok: true, fb: 'Exato. Realimentação → memória. É a passagem do combinacional para o sequencial.' },
            { t: 'Ele tem duas saídas.', fb: 'Ter duas saídas não cria memória (um decodificador tem quatro). O essencial é o laço de volta.' },
          ],
          explain: 'A linha "S=0, R=0 → Q anterior" da tabela é a primeira vez que o tempo entra na nossa lógica.',
        },
        {
          type: 'mc', id: 'f6-s1-e2',
          q: 'Um latch SR está com Q = 1. Aplicamos um pulso em R (R=1 e depois R=0). Qual é Q agora?',
          options: [
            { t: '1, porque S não foi tocado.', fb: 'R é "reset": ele força Q para 0. O latch não precisa de S para mudar.' },
            { t: '0, e permanece 0 depois que R volta a 0.', ok: true, fb: 'Reset grava 0, e a realimentação mantém o 0.' },
            { t: 'Indefinido.', fb: 'Indefinido é só quando S e R são 1 ao mesmo tempo. Aqui só R foi pulsado.' },
          ],
          explain: 'Set grava 1, reset grava 0, e (0,0) lembra.',
        },
        {
          type: 'mc', id: 'f6-s1-e3',
          q: 'Por que a RAM do computador perde tudo quando ele é desligado?',
          options: [
            { t: 'Porque o sistema operacional apaga a memória ao desligar.', fb: 'Não é software. É física: o que mantém o bit num latch?' },
            { t: 'Porque o bit é mantido por um laço de realimentação entre portas que precisa de energia para se sustentar; sem energia, o laço some.', ok: true, fb: 'Exato. Memória por realimentação é volátil por natureza.' },
            { t: 'Porque os bits são apagados pelo calor.', fb: 'Calor não é a causa. A realimentação precisa de alimentação elétrica contínua.' },
          ],
          explain: 'SSDs guardam bits como carga presa em uma estrutura isolada (sem realimentação), por isso não precisam de energia para lembrar.',
        },
      ],
    },
    {
      id: 's2',
      title: 'O relógio e o flip-flop: domando o tempo',
      body: `
## Um problema: quando a memória deve mudar?

O latch SR muda de estado **imediatamente** quando S ou R sobem. Num circuito grande, isso é um caos: sinais chegam em momentos diferentes (lembra do atraso de propagação?), e a memória poderia gravar valores intermediários errados enquanto o somador ainda está "ondulando" o vai-um.

Precisamos de disciplina: **"só grave quando eu mandar"**. A solução tem dois passos.

## Passo 1: o latch D com habilitação

Primeiro, simplificamos a interface. Em vez de S e R separados, usamos uma única entrada **D** (*data*, dado) e uma entrada **EN** (*enable*, habilitar):

- S = D AND EN
- R = (NOT D) AND EN

Quando EN = 0, S = R = 0: o latch **lembra**. Quando EN = 1, se D = 1 então S = 1 (grava 1); se D = 0 então R = 1 (grava 0). O latch "copia D" enquanto EN está ligado, e "congela" quando EN desliga. E a combinação proibida (S = R = 1) nunca acontece. Isso é o **latch D**.

## Passo 2: o relógio

Agora, em vez de cada parte do circuito decidir quando habilitar, criamos um sinal global que **bate** em intervalos regulares: 0, 1, 0, 1, 0, 1... É o **relógio** (*clock*, CLK). Quando se diz que um processador é de "3 GHz", significa que esse sinal bate 3 bilhões de vezes por segundo.

E fazemos a memória mudar **apenas no instante em que o relógio sobe de 0 para 1** (a "borda de subida"). Não enquanto está em 1: só no instante da transição. Um circuito que faz isso se chama **flip-flop D disparado por borda**. Internamente, são dois latches D em sequência (mestre e escravo) com habilitações opostas, de forma que o valor "entra" no primeiro enquanto o clock está baixo e "passa" para o segundo exatamente na subida. Não vou detalhar a construção; o comportamento é o que importa:

| borda de subida do CLK? | Q (depois) |
|---|---|
| não | Q (anterior) |
| sim | D (no instante da borda) |

[[demo:dff]]

## Por que isso resolve o caos

Agora o ciclo de vida de um computador é:

1. O relógio sobe. Todos os flip-flops capturam seus novos valores **ao mesmo tempo**.
2. Esses valores saem dos flip-flops e atravessam a lógica combinacional (somadores, MUXes, decodificadores...). Os sinais "ondulam", têm valores intermediários errados, se estabilizam.
3. **Antes** da próxima subida do relógio, tudo precisa estar estável. Essa é a condição de projeto: o período do clock deve ser maior que o caminho crítico.
4. O relógio sobe de novo. Os flip-flops capturam os resultados estabilizados. Volta ao passo 2.

Os valores intermediários errados **nunca** são gravados, porque a gravação só acontece na borda, quando tudo já se acalmou. Isso é o **projeto síncrono**, e é como quase todo chip digital funciona.

> 💡 Agora você entende por que existe um "clock" e por que ele tem um limite. Mais rápido que o caminho crítico, os flip-flops capturariam lixo. Por isso *overclock* exagerado trava o computador: não é que ele "fique confuso"; é que sinais são gravados antes de se estabilizarem. Resfriar ajuda porque transistores mais frios comutam mais rápido, encurtando o caminho crítico.

## Registradores: vários flip-flops lado a lado

Um **registrador** de 8 bits são 8 flip-flops D compartilhando o mesmo clock. Na borda, os 8 capturam juntos um byte inteiro. Com uma entrada extra de "carregar" (*load*), via um MUX que escolhe entre "o novo valor" e "o valor atual realimentado", o registrador só muda quando se quer:

\`\`\`
para cada bit i:
  D_i = MUX(sel=load, entrada0 = Q_i (manter), entrada1 = novo_i (carregar))
\`\`\`

Registradores são a memória mais rápida do processador: ficam a um ciclo de distância da ULA. Um processador típico tem de 16 a 32 registradores de uso geral de 64 bits, mais alguns especiais, como o **contador de programa** (que veremos na Fase 7).

## Um contador

Ligue um registrador a um somador que soma 1 à sua saída, e leve o resultado de volta para a entrada do registrador. A cada borda do clock, o registrador recebe seu valor anterior + 1: 0, 1, 2, 3... Esse é um **contador**, e é literalmente como o processador sabe qual é a próxima instrução. Você já tem todas as peças: registrador (esta seção), somador (Fase 5).
`,
      exercises: [
        {
          type: 'mc', id: 'f6-s2-e1',
          q: 'Para que serve o relógio (clock) num circuito digital?',
          options: [
            { t: 'Para medir o tempo e mostrar as horas ao usuário.', fb: 'Esse é outro "relógio" (o RTC). O clock de que falamos é um sinal interno de sincronização.' },
            { t: 'Para definir os instantes exatos em que todas as memórias (flip-flops) capturam novos valores, garantindo que só valores já estabilizados sejam gravados.', ok: true, fb: 'Exato. É a disciplina que impede que valores intermediários da lógica combinacional sejam gravados.' },
            { t: 'Para fornecer energia às portas.', fb: 'A energia vem da alimentação (Vdd). O clock é um sinal de controle de tempo.' },
          ],
          explain: 'Projeto síncrono: capturar → propagar → estabilizar → capturar.',
        },
        {
          type: 'mc', id: 'f6-s2-e2',
          q: 'Por que não dá para aumentar a frequência do clock indefinidamente?',
          options: [
            { t: 'Porque o relógio esquentaria demais.', fb: 'Calor é uma consequência real, mas há um limite lógico anterior: o que precisa acontecer entre duas batidas?' },
            { t: 'Porque entre duas bordas do clock os sinais precisam atravessar todo o caminho crítico da lógica combinacional e se estabilizar; se o período for menor que isso, os flip-flops gravam valores errados.', ok: true, fb: 'Exato. Período mínimo = atraso do caminho crítico (+ margens).' },
            { t: 'Porque os flip-flops só aceitam até 5 GHz.', fb: 'Não há um número mágico. O limite vem do atraso do circuito que alimenta os flip-flops.' },
          ],
          explain: 'É por isso que engenheiros lutam para encurtar o caminho crítico: cada porta a menos na cadeia permite um clock mais rápido.',
        },
        {
          type: 'input', id: 'f6-s2-e3',
          q: 'Um registrador de **32 bits** é feito de quantos flip-flops D?',
          answer: '32',
          hints: ['Um flip-flop guarda 1 bit.'],
          explain: '32 flip-flops com o mesmo clock. Um processador de 64 bits tem registradores de 64 flip-flops.',
        },
        {
          type: 'circuit', id: 'f6-s2-e4',
          q: 'Construa a lógica de UM bit de um registrador com carga: entradas Q (valor atual), N (novo valor) e L (load). Saída = N se L=1, senão Q. (É um MUX!)',
          inputs: ['Q', 'N', 'L'], target: (v) => (v[2] ? v[1] : v[0]), allowed: ['NOT', 'AND', 'OR'], maxGates: 4,
          hints: ['É o multiplexador da Fase 4 com SEL = L.', 'NOT L; AND(Q, g1); AND(N, L); OR(g2, g3).'],
          explain: 'A saída desse MUX alimenta o D do flip-flop. Na borda do clock, o flip-flop grava: ou mantém (Q) ou carrega (N). Você acabou de projetar um registrador.',
        },
      ],
    },
    {
      id: 's3',
      title: 'Memória endereçável: achando um byte entre bilhões',
      body: `
## De registradores para RAM

Um registrador guarda uma palavra. Um computador precisa de bilhões de bytes. Não podemos ter bilhões de fios saindo do processador, um para cada byte. Precisamos de um jeito de dizer "quero o byte número 7.431.209" e recebê-lo.

A solução: a **memória de acesso aleatório** (*Random Access Memory*, RAM). "Acesso aleatório" significa que qualquer posição pode ser acessada diretamente, no mesmo tempo, sem percorrer as anteriores (ao contrário de uma fita).

> 🔤 **RAM** = *Random Access Memory*, "memória de acesso aleatório". O nome contrasta com memórias sequenciais (fitas, tambores) dos anos 1950, em que para ler a posição 1000 você precisava passar pelas 999 anteriores.

## A estrutura

Uma RAM de 2ⁿ palavras tem:

- 2ⁿ **registradores** (as células), numerados de 0 a 2ⁿ − 1;
- n fios de **endereço** (*address*): o número da célula desejada, em binário;
- fios de **dados** (*data*): o valor a escrever ou lido;
- um fio de **escrita** (*write enable*): 1 = escrever, 0 = ler;
- um **decodificador** n-para-2ⁿ, que transforma o endereço em "ativa só a célula tal";
- um **multiplexador** 2ⁿ-para-1, que escolhe a saída da célula endereçada para os fios de dados.

Todas peças que você já construiu. Leitura: o endereço entra, o decodificador... na verdade, para leitura só o MUX basta: com o endereço como seleção, ele entrega a saída da célula escolhida. Escrita: o decodificador ativa a linha da célula escolhida, e essa linha, com AND com "write enable", vira o sinal *load* daquele registrador. Na borda do clock, só aquela célula grava.

\`\`\`
         endereço (n bits)
              │
       ┌──────┴──────┐
       │ decodificador│──── linha 0 ──AND(write)── load → célula 0 ─┐
       │  n → 2ⁿ     │──── linha 1 ──AND(write)── load → célula 1 ─┤
       │             │          ...                                  ├─ MUX ─→ dados (saída)
       └─────────────┘──── linha 2ⁿ-1 ─AND(write)─ load → célula 2ⁿ-1┘    ↑
                                                                      endereço
  dados (entrada) ───────── para a entrada "novo valor" de todas as células
\`\`\`

## A conta que explica os tamanhos

Com n bits de endereço, há 2ⁿ células. Se cada célula é um byte:

| bits de endereço | células | tamanho |
|---|---|---|
| 10 | 1.024 | 1 KiB |
| 16 | 65.536 | 64 KiB (computadores de 8 bits dos anos 80) |
| 20 | 1.048.576 | 1 MiB (limite do MS-DOS original) |
| 32 | ~4,29 bilhões | 4 GiB (limite dos sistemas de 32 bits) |
| 48 | ~2,8 × 10¹⁴ | 256 TiB (o que processadores x86-64 atuais usam de fato) |

**É por isso que "32 bits" limitava a 4 GB de RAM**: 32 fios de endereço só distinguem 2³² posições. Para endereçar mais, precisou-se de mais bits de endereço, e daí "64 bits". E é por isso que os tamanhos de memória são potências de 2 (lembra do exercício na Fase 1?).

> ⚠️ **Simplificação.** RAM real é organizada em matrizes (linhas × colunas) com decodificadores separados, bancos, e hierarquias de cache. A DRAM usa capacitores em vez de flip-flops. Mas a interface lógica é esta: endereço entra, dado sai ou entra, controlado por um sinal de escrita e pelo clock.

## A hierarquia de memória

Memória rápida é cara e pequena; memória barata é grande e lenta. Por isso computadores empilham camadas:

| nível | tamanho típico | tempo de acesso | feita de |
|---|---|---|---|
| registradores | centenas de bytes | 1 ciclo (~0,3 ns) | flip-flops |
| cache L1/L2/L3 | KB a dezenas de MB | 1–40 ns | SRAM (latches de 6 transistores) |
| RAM principal | GB | ~80 ns | DRAM (capacitores) |
| SSD | TB | ~50 µs | flash (carga presa) |
| HD | TB | ~5 ms | magnetismo |

Todos guardam bits. O que muda é a física e o compromisso custo/velocidade. Quando você programa, essa hierarquia explica por que alguns programas são lentos "sem motivo": estão acessando memória de forma que derrota as caches. Mas isso é assunto para depois.

## O que já temos

Faça o inventário. Você construiu, conceitualmente, com portas:

- qualquer função booleana (Fase 3–4);
- somador/subtrator e a ULA (Fase 5);
- registradores e contadores (Fase 6);
- RAM endereçável (Fase 6).

Falta uma coisa: **juntar tudo numa máquina que lê instruções da memória e as executa**. É a Fase 7, a última, onde nasce o programa.
`,
      exercises: [
        {
          type: 'input', id: 'f6-s3-e1',
          q: 'Uma RAM tem **12 fios de endereço**. Quantas células ela tem?',
          answer: ['4096', '4.096'],
          hints: ['2¹². Você sabe 2¹⁰ = 1.024. Dobre duas vezes.'],
          explain: '2¹² = 4.096 células. Com células de 1 byte, 4 KiB.',
        },
        {
          type: 'input', id: 'f6-s3-e2',
          q: 'Para endereçar **1 MiB** (2²⁰ bytes), quantos bits de endereço são necessários?',
          answer: '20',
          hints: ['2ⁿ = 2²⁰.'],
          explain: '20 bits. O processador Intel 8086 (1978) tinha exatamente 20 fios de endereço, daí o limite de 1 MB do MS-DOS.',
        },
        {
          type: 'mc', id: 'f6-s3-e3',
          q: 'Qual bloco da Fase 4 transforma o número do endereço em "ativar somente a célula correspondente" para escrita?',
          options: [
            { t: 'Multiplexador', fb: 'O MUX faz o caminho contrário: escolhe UMA saída entre várias para a leitura. Para ativar uma linha específica, usa-se outro bloco.' },
            { t: 'Decodificador', ok: true, fb: 'O decodificador n-para-2ⁿ acende exatamente uma linha: a da célula endereçada.' },
            { t: 'Somador', fb: 'O somador faz contas; não seleciona células.' },
          ],
          explain: 'Decodificador para escrever (selecionar quem grava), MUX para ler (selecionar quem fala).',
        },
        {
          type: 'explain', id: 'f6-s3-e4',
          q: 'Explique por que um computador "de 32 bits" tinha um limite de cerca de 4 GB de RAM. Conecte com a regra 2ⁿ.',
          keywords: [['endereço', 'endereç'], ['32'], ['2³²', '2^32', '4 bilhões', '4,29', '4.29', '4294967296', 'potência'], ['célula', 'byte', 'posição'], ['fio', 'bit']],
          minGroups: 3,
          model: 'Um processador de 32 bits usa 32 bits para endereços de memória. Com 32 bits há 2³² ≈ 4,29 bilhões de endereços diferentes; se cada endereço aponta para um byte, o máximo endereçável é ~4,29 GB (4 GiB). Para acessar mais, é preciso mais bits de endereço, o que levou aos processadores de 64 bits. É a mesma regra 2ⁿ das lamparinas da Fase 0, aplicada a fios de endereço.',
        },
      ],
    },
  ],
  boss: {
    title: 'Chefe da Fase 6: O Guardião do Tempo',
    intro: 'O Guardião testa se você entende memória, relógio e endereçamento. Pense sempre em "o que mantém o bit?" e "quando ele muda?".',
    passRatio: 0.8,
    exercises: [
      {
        type: 'mc', id: 'f6-b1', q: 'O que é necessário, em termos de estrutura de circuito, para que um circuito de portas tenha memória?',
        options: [{ t: 'Muitas portas.', fb: 'Quantidade não cria memória. Um somador de 64 bits tem centenas de portas e não lembra nada.' }, { t: 'Realimentação: uma saída ligada de volta a uma entrada, criando estados estáveis que se auto-sustentam.', ok: true, fb: 'Correto.' }, { t: 'Portas NOR especificamente.', fb: 'Dá para fazer latch com NAND também. O essencial é o laço.' }],
        explain: 'Combinacional + realimentação = sequencial.',
      },
      {
        type: 'mc', id: 'f6-b2', q: 'No latch SR, o que acontece com S = 0 e R = 0?',
        options: [{ t: 'Q vira 0.', fb: 'Isso é o reset (R=1).' }, { t: 'Q mantém o valor anterior.', ok: true, fb: 'É o estado de "lembrar".' }, { t: 'Estado proibido.', fb: 'Proibido é S=R=1.' }],
        explain: 'Linha de memória da tabela.',
      },
      {
        type: 'mc', id: 'f6-b3', q: 'Um flip-flop D disparado por borda de subida copia D para Q...',
        options: [{ t: 'sempre que D muda.', fb: 'Isso seria um fio, não uma memória.' }, { t: 'enquanto o clock está em 1.', fb: 'Isso é um latch D com habilitação, não um flip-flop. O flip-flop é mais estrito.' }, { t: 'apenas no instante em que o clock passa de 0 para 1.', ok: true, fb: 'Correto: na borda.' }],
        explain: 'Disparo por borda é o que torna o projeto síncrono previsível.',
      },
      { type: 'input', id: 'f6-b4', q: 'Uma RAM com **16 bits de endereço** e células de 1 byte tem quantos bytes?', answer: ['65536', '65.536'], hints: ['2¹⁶ = 256 × 256.'], explain: '64 KiB. Era a RAM máxima dos computadores de 8 bits (Apple II, MSX, ZX Spectrum).' },
      {
        type: 'mc', id: 'f6-b5', q: 'Por que resfriar um processador pode permitir um clock mais alto?',
        options: [{ t: 'Porque o frio aumenta a tensão.', fb: 'Não. Pense no atraso das portas.' }, { t: 'Porque transistores mais frios comutam mais rápido, encurtando o caminho crítico, o que permite um período de clock menor.', ok: true, fb: 'Correto.' }, { t: 'Porque o frio impede o overflow.', fb: 'Overflow é aritmético, não térmico.' }],
        explain: 'Período mínimo do clock = atraso do caminho crítico.',
      },
      { type: 'circuit', id: 'f6-b6', q: 'Construa a lógica S do latch D: **S = D AND EN**; e... na verdade construa **R = (NOT D) AND EN**.', inputs: ['D', 'EN'], target: (v) => !v[0] && v[1], allowed: ['NOT', 'AND', 'OR'], maxGates: 2, hints: ['NOT D, depois AND com EN.'], explain: 'Com S = D·EN e R = ¬D·EN, o latch SR vira latch D e a combinação proibida nunca ocorre.' },
      {
        type: 'explain', id: 'f6-b7', q: 'Descreva o ciclo de um circuito síncrono: o que acontece entre duas bordas de subida do clock?',
        keywords: [['borda', 'subida', 'batida', 'pulso'], ['flip-flop', 'registrador', 'memória', 'captura', 'grava'], ['combinacional', 'lógica', 'somador', 'propag', 'atravess'], ['estabiliz', 'estável', 'acalm', 'termin']],
        minGroups: 3,
        model: 'Na borda de subida, todos os flip-flops capturam seus valores de entrada simultaneamente. Esses valores saem e atravessam a lógica combinacional (somadores, MUXes), que durante um tempo apresenta valores intermediários instáveis. Antes da próxima borda, os sinais precisam se estabilizar (o período deve ser maior que o caminho crítico). Na próxima borda, os flip-flops capturam os resultados já estáveis, e o ciclo recomeça. Assim, valores transitórios nunca são gravados.',
      },
    ],
  },
  review: [
    { id: 'f6-r1', q: 'O que permite que um circuito de portas tenha memória?', a: 'Realimentação: a saída volta para a entrada, criando estados estáveis auto-sustentados (latch).' },
    { id: 'f6-r2', q: 'Tabela do latch SR: o que fazem (0,0), (1,0), (0,1), (1,1)?', a: 'Lembra; set (Q=1); reset (Q=0); proibido.' },
    { id: 'f6-r3', q: 'Qual a diferença entre latch e flip-flop?', a: 'O latch muda enquanto habilitado; o flip-flop muda só na borda do clock.' },
    { id: 'f6-r4', q: 'Para que serve o clock?', a: 'Sincronizar: definir os instantes em que todas as memórias capturam valores, após a lógica combinacional se estabilizar.' },
    { id: 'f6-r5', q: 'O que limita a frequência máxima do clock?', a: 'O atraso do caminho crítico da lógica combinacional entre flip-flops.' },
    { id: 'f6-r6', q: 'O que é um registrador?', a: 'Conjunto de flip-flops com o mesmo clock, guardando uma palavra; com MUX de "load" para manter ou carregar.' },
    { id: 'f6-r7', q: 'Quantas células tem uma RAM com n bits de endereço?', a: '2ⁿ.' },
    { id: 'f6-r8', q: 'Por que a RAM é volátil?', a: 'Porque o bit é mantido por realimentação que precisa de energia contínua.' },
    { id: 'f6-r9', q: 'Que blocos da Fase 4 a RAM usa para escrever e para ler?', a: 'Decodificador (escolhe a célula que grava) e multiplexador (escolhe a célula que é lida).' },
  ],
  glossary: [
    { pt: 'circuito sequencial', en: 'sequential circuit', def: 'Circuito cuja saída depende também do passado (tem memória).' },
    { pt: 'realimentação', en: 'feedback', def: 'Ligar a saída de volta à entrada.' },
    { pt: 'latch SR', en: 'SR latch', def: 'Memória de 1 bit com entradas set e reset, feita de duas portas NOR (ou NAND) cruzadas.', origin: '*Latch* = trinco, tranca.' },
    { pt: 'latch D', en: 'D latch', def: 'Latch com entrada de dado (D) e habilitação (enable).' },
    { pt: 'flip-flop', en: 'flip-flop', def: 'Memória de 1 bit que só muda na borda do clock.' },
    { pt: 'relógio', en: 'clock (CLK)', def: 'Sinal periódico 0/1 que sincroniza todas as memórias do chip. "3 GHz" = 3 bilhões de batidas por segundo.' },
    { pt: 'borda de subida', en: 'rising edge', def: 'Instante em que o clock passa de 0 para 1.' },
    { pt: 'registrador', en: 'register', def: 'Conjunto de flip-flops que guarda uma palavra; memória mais rápida do processador.' },
    { pt: 'contador de programa', en: 'program counter (PC)', def: 'Registrador que guarda o endereço da próxima instrução.' },
    { pt: 'RAM', en: 'Random Access Memory', def: 'Memória em que qualquer célula é acessada diretamente pelo endereço.' },
    { pt: 'endereço', en: 'address', def: 'Número de uma célula de memória. n bits → 2ⁿ células.' },
    { pt: 'volátil', en: 'volatile', def: 'Perde o conteúdo sem energia (RAM). Oposto: não volátil (SSD, HD).' },
    { pt: 'SRAM / DRAM', en: 'SRAM / DRAM', def: 'RAM estática (latches, rápida, cara; usada em caches) / dinâmica (capacitores, densa, barata; a RAM principal).' },
    { pt: 'cache', en: 'cache', def: 'Memória pequena e rápida próxima ao processador que guarda cópias dos dados mais usados.' },
    { pt: 'projeto síncrono', en: 'synchronous design', def: 'Metodologia em que todas as memórias mudam só nas bordas de um clock comum.' },
  ],
};
