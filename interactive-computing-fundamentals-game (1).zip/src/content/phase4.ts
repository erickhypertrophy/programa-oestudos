import type { Phase } from '../lib/types';

export const phase4: Phase = {
  id: 'f4',
  num: 4,
  emoji: '🔌',
  title: 'Portas lógicas: a lógica feita de matéria',
  subtitle: 'Do interruptor ao transistor, do transistor à porta, e a descoberta de que uma única porta (NAND) constrói todas as outras',
  goal: 'Ao final desta fase você vai entender como um interruptor elétrico realiza uma operação lógica, o que um transistor faz, como se desenham e combinam portas, e vai ter construído com as próprias mãos NOT, AND, OR e XOR usando apenas NAND.',
  sections: [
    {
      id: 's1',
      title: 'Interruptores que pensam: a ideia de Shannon',
      body: `
## Dois interruptores em série

Pegue uma pilha, uma lâmpada e **dois interruptores em sequência** (em série) no mesmo fio. Quando a lâmpada acende? Só quando **os dois** interruptores estão fechados: se qualquer um estiver aberto, o circuito está interrompido.

Interruptor A fechado = 1, aberto = 0. Lâmpada acesa = 1.

| A | B | lâmpada |
|---|---|---|
| aberto (0) | aberto (0) | apagada (0) |
| aberto (0) | fechado (1) | apagada (0) |
| fechado (1) | aberto (0) | apagada (0) |
| fechado (1) | fechado (1) | acesa (1) |

Você reconhece essa tabela. **É o AND.** Dois interruptores em série *são* uma porta AND. Não "representam", não "simulam": a física do circuito realiza a tabela-verdade.

## Dois interruptores em paralelo

Agora coloque os dois interruptores em **caminhos separados** (em paralelo): a corrente pode passar por A ou por B. A lâmpada acende se **pelo menos um** estiver fechado.

| A | B | lâmpada |
|---|---|---|
| 0 | 0 | 0 |
| 0 | 1 | 1 |
| 1 | 0 | 1 |
| 1 | 1 | 1 |

**É o OR.** Série = AND; paralelo = OR.

## E o NOT?

Para o NOT precisamos de um interruptor que **abra quando acionado** (um "normalmente fechado"). Botão solto → lâmpada acesa; botão apertado → lâmpada apagada. Interruptores assim existem desde o século XIX.

> 📜 Foi exatamente isso que **Claude Shannon** percebeu em 1937, aos 21 anos, na sua dissertação de mestrado no MIT, *A Symbolic Analysis of Relay and Switching Circuits*. Ele estava trabalhando com relés (interruptores acionados por eletroímã) de centrais telefônicas e notou: série é AND, paralelo é OR, e portanto **toda a álgebra de Boole pode ser construída com interruptores**, e, inversamente, qualquer circuito de interruptores pode ser analisado e simplificado com as leis de Boole. Antes dele, projetar circuitos de comutação era arte e tentativa; depois, virou matemática.

## O ingrediente que faltava: interruptor controlado por eletricidade

Com interruptores manuais, dá para construir lógica, mas **alguém precisa apertar**. A mágica começa quando a saída de um circuito (a lâmpada) pode acionar o interruptor de outro circuito. Aí portas alimentam portas, e você pode encadear raciocínios sem intervenção humana.

Três gerações de "interruptor controlado por eletricidade":

1. **Relé** (séc. XIX–1940): um eletroímã puxa uma lâmina metálica, fechando um contato. Mecânico, lento (milissegundos), barulhento, mas funciona. O Z3 de Konrad Zuse (1941) e o Harvard Mark I (1944) usavam relés.
2. **Válvula termiônica** (1940–1950): um tubo de vidro a vácuo em que uma grade elétrica controla o fluxo de elétrons. Sem partes móveis, mil vezes mais rápida que o relé, mas quente, grande e queimava com frequência. O ENIAC tinha 17.468 válvulas.
3. **Transistor** (1947–hoje): um pedacinho de material semicondutor (silício) em que uma pequena tensão num terminal controla a passagem de corrente entre outros dois. Minúsculo, frio, rápido (bilhões de vezes por segundo), e fabricável aos bilhões num único chip.

> 🔤 **Transistor** vem de *transfer resistor*, "resistor de transferência", nome dado pela Bell Labs em 1947. Seus inventores (Bardeen, Brattain e Shockley) ganharam o Nobel de Física de 1956.

## O transistor como interruptor (versão simplificada)

> ⚠️ **Simplificação avisada.** Vou descrever o transistor MOSFET como um interruptor perfeito. Na realidade há tensões de limiar, correntes de fuga, tempos de transição e muita física de semicondutores. Para entender lógica digital, o modelo de interruptor basta, e é o que os próprios engenheiros digitais usam no dia a dia.

Um transistor tem três terminais. Chame-os de **entrada de controle** (*gate*, "portão"), e dois terminais de passagem (*source* e *drain*). Regra:

- Se a entrada de controle está em tensão alta (1), o transistor **conduz**: é um interruptor fechado.
- Se está em tensão baixa (0), **não conduz**: interruptor aberto.

Existe também o tipo complementar, que faz o oposto (conduz com 0, bloqueia com 1). A tecnologia que usa os dois tipos juntos se chama **CMOS** (*Complementary Metal-Oxide-Semiconductor*) e é a base de praticamente todos os chips atuais.

Com isso, construir um NOT fica assim: ligue a saída à alimentação (1) através de um transistor do tipo "conduz com 0", e ao terra (0) através de um transistor do tipo "conduz com 1". Entrada 0 → o primeiro conduz, saída = 1. Entrada 1 → o segundo conduz, saída = 0. **Dois transistores = um NOT.**

Um NAND em CMOS usa **4 transistores**. Um AND precisa de um NAND seguido de um NOT: 6 transistores. Por isso, em silício, **NAND é mais barata que AND**. Isso vai importar na seção 3.
`,
      exercises: [
        {
          type: 'mc', id: 'f4-s1-e1',
          q: 'Dois interruptores em SÉRIE (um depois do outro, no mesmo fio) controlando uma lâmpada realizam qual operação lógica?',
          options: [
            { t: 'OR', fb: 'Em série, basta UM interruptor aberto para cortar o circuito inteiro. Então a lâmpada só acende quando... ambos estão fechados. Que operação é essa?' },
            { t: 'AND', ok: true, fb: 'Correto: a corrente precisa passar pelos dois. Ambos fechados = acesa.' },
            { t: 'XOR', fb: 'XOR acenderia com exatamente um fechado. Em série, um só fechado não completa o circuito.' },
          ],
          explain: 'Série = AND, paralelo = OR. Essa é a observação de Shannon (1937) que casou lógica e eletricidade.',
        },
        {
          type: 'mc', id: 'f4-s1-e2',
          q: 'Por que o transistor foi tão mais revolucionário que o relé e a válvula, se os três fazem "a mesma coisa" (interruptor controlado eletricamente)?',
          options: [
            { t: 'Porque o transistor realiza operações lógicas que os outros não conseguem.', fb: 'Não: logicamente são equivalentes. Computadores de relés e de válvulas funcionavam. A diferença é outra.' },
            { t: 'Por tamanho, velocidade, consumo de energia, confiabilidade e, acima de tudo, por poder ser fabricado aos bilhões em um único chip.', ok: true, fb: 'Exato. A lógica é a mesma; a engenharia é incomparavelmente melhor. Um chip moderno tem mais transistores do que o planeta tinha relés em 1940.' },
            { t: 'Porque usa silício, que é o elemento mais abundante.', fb: 'Silício ser abundante ajuda no custo, mas a razão central é a combinação de tamanho, velocidade, confiabilidade e integração em massa.' },
          ],
          explain: 'Separar "o que a coisa faz" (função lógica) de "como é feita" (tecnologia) é um hábito mental essencial. A função é estável há 170 anos; a tecnologia muda a cada década.',
        },
        {
          type: 'input', id: 'f4-s1-e3',
          q: 'Em CMOS, um NOT usa 2 transistores e um NAND usa 4. Um AND é feito como NAND + NOT. Quantos transistores tem um AND?',
          answer: '6',
          hints: ['Some os dois.', '4 + 2.'],
          explain: '6 transistores. É por isso que, fisicamente, NAND é a porta "nativa" e AND é derivada. Engenheiros projetam pensando em NAND/NOR.',
        },
      ],
    },
    {
      id: 's2',
      title: 'Símbolos, fios e composição: lendo e desenhando circuitos',
      body: `
## Abstração: esqueça os transistores

Aqui vamos fazer algo que é a essência da engenharia de computação: **subir um nível de abstração**. Agora que sabemos que uma porta pode ser construída com transistores, vamos **parar de pensar em transistores** e pensar só em portas: caixinhas com entradas e saída, definidas pela tabela-verdade.

Isso é legítimo porque a porta se comporta de forma confiável conforme a tabela. Não importa se dentro há relés, válvulas ou transistores. É o mesmo movimento que fizemos ao dizer "um bit é uma lâmpada ou um furo ou uma tensão; não importa".

> 💡 **Abstração** é a ferramenta mental número um de quem programa. Você constrói uma camada, garante que ela funciona, e então usa a camada sem olhar dentro. Portas sobre transistores; somadores sobre portas; processador sobre somadores; linguagens sobre processador; aplicativos sobre linguagens. Cada camada "esconde" a de baixo. Este curso inteiro é uma escalada por essas camadas.

## Os símbolos

Engenheiros desenham portas com símbolos padronizados (norma americana ANSI, a mais comum em livros):

\`\`\`
   AND              OR               NOT             XOR
A ─┐                A ─╲               A ─▷o─ S       A ─╲╲
   ├─)D── S            ⟩⟩── S                          ⟩⟩── S
B ─┘                B ─╱                              B ─╱╱

  (forma de D)   (forma de escudo)  (triângulo+bolinha) (escudo com linha extra)

   NAND              NOR
A ─┐                A ─╲
   ├─)Do── S           ⟩⟩o── S
B ─┘                B ─╱
  (AND + bolinha)   (OR + bolinha)
\`\`\`

A **bolinha** na saída significa "negado". Então NAND é o símbolo do AND com bolinha; NOR é OR com bolinha. Um NOT é um triângulo (um "buffer", que só repassa o sinal) com bolinha.

Neste jogo, em vez de desenhos, vamos montar circuitos como **listas de portas**, cada uma dizendo de onde vêm suas entradas. É o mesmo que os engenheiros fazem em linguagens de descrição de hardware (HDL), como Verilog e VHDL, e é como o Nand2Tetris trabalha. Exemplo, o "detector de molhar-se" da Fase 3, A AND (NOT B):

\`\`\`
porta 1: NOT  recebe entrada B            → produz g1
porta 2: AND  recebe entrada A e g1       → produz g2 (saída)
\`\`\`

## Regras de composição

1. A saída de uma porta pode alimentar **quantas entradas** quiser (chamamos de *fan-out*). Um fio pode se ramificar.
2. Duas saídas **nunca** devem ser ligadas no mesmo fio (curto-circuito lógico: se uma diz 1 e outra 0, o resultado é indefinido e pode queimar).
3. Nesta fase, os circuitos são **combinacionais**: a informação flui só para frente, das entradas para a saída, sem voltas. A saída depende **apenas** das entradas atuais. Na Fase 6 vamos quebrar essa regra de propósito, e isso vai criar memória.

## Atraso: a física cobra o preço

Uma porta real leva tempo para mudar a saída depois que a entrada muda: o **atraso de propagação**, hoje da ordem de picossegundos (trilionésimos de segundo). Num circuito com muitas portas em cadeia, os atrasos se somam. O caminho mais longo (o *caminho crítico*) determina a velocidade máxima do chip. É por isso que um processador tem um "clock" de, digamos, 4 GHz e não infinito: cada ciclo precisa durar o bastante para os sinais atravessarem o caminho crítico. Vamos usar essa ideia na Fase 6.

## Praticando a leitura

Vamos ler um circuito dado como lista e descobrir sua função:

\`\`\`
entradas: A, B
porta 1: NAND recebe A e B        → g1
porta 2: NAND recebe A e g1       → g2
porta 3: NAND recebe B e g1       → g3
porta 4: NAND recebe g2 e g3      → g4 (saída)
\`\`\`

Para descobrir, montamos a tabela-verdade linha a linha:

| A | B | g1 = A⊼B | g2 = A⊼g1 | g3 = B⊼g1 | g4 = g2⊼g3 |
|---|---|---|---|---|---|
| 0 | 0 | 1 | 1 | 1 | 0 |
| 0 | 1 | 1 | 1 | 0 | 1 |
| 1 | 0 | 1 | 0 | 1 | 1 |
| 1 | 1 | 0 | 1 | 1 | 0 |

A última coluna é 0,1,1,0. **É o XOR!** Quatro NANDs fazem um XOR. Você vai construir isso na próxima seção. Mas antes, exercite a leitura.
`,
      exercises: [
        {
          type: 'mc', id: 'f4-s2-e1',
          q: 'Leia o circuito: `porta 1: NOT recebe A → g1; porta 2: NOT recebe B → g2; porta 3: AND recebe g1 e g2 → saída`. Qual função ele calcula?',
          options: [
            { t: 'A NAND B', fb: 'Monte a tabela: para A=0,B=0: g1=1, g2=1, saída=1. Para A=1,B=1: g1=0, g2=0, saída=0. Para A=0,B=1: saída = 1 AND 0 = 0. NAND daria 1 aí. Não é NAND.' },
            { t: 'A NOR B', ok: true, fb: '(NOT A) AND (NOT B) = NOT(A OR B) por De Morgan = NOR. Só acende quando ambas são 0.' },
            { t: 'A XOR B', fb: 'XOR acende quando as entradas diferem. Teste A=0,B=1: g1=1, g2=0, saída=0. Não é XOR.' },
          ],
          explain: 'Você acabou de usar De Morgan para LER um circuito. A álgebra e o hardware são a mesma coisa.',
        },
        {
          type: 'mc', id: 'f4-s2-e2',
          q: 'O que significa dizer que um circuito é "combinacional"?',
          options: [
            { t: 'Que ele combina várias portas.', fb: 'Todo circuito de mais de uma porta combina portas. "Combinacional" é um termo técnico mais específico, sobre DE QUE a saída depende.' },
            { t: 'Que a saída depende apenas das entradas atuais, sem memória do passado, porque a informação só flui para frente.', ok: true, fb: 'Exato. Mesmas entradas → mesma saída, sempre. Na Fase 6 veremos circuitos "sequenciais", que lembram.' },
            { t: 'Que ele usa só AND e OR.', fb: 'Não há restrição de tipo de porta. A restrição é sobre a ausência de "voltas" (realimentação).' },
          ],
          explain: 'Combinacional = função pura das entradas. É exatamente uma tabela-verdade feita de matéria.',
        },
        {
          type: 'circuit', id: 'f4-s2-e3',
          q: 'Primeiro circuito seu: construa **A AND (NOT B)** ("chove e não tenho guarda-chuva"). Saída 1 só quando A=1 e B=0.',
          inputs: ['A', 'B'], target: (v) => v[0] && !v[1], allowed: ['NOT', 'AND', 'OR'], maxGates: 3,
          hints: ['Você precisa inverter B primeiro. Adicione um NOT que recebe B.', 'Depois adicione um AND que recebe A e a saída do NOT (porta 1).'],
          explain: 'Duas portas: NOT(B) → AND(A, g1). A lista de portas é exatamente como engenheiros descrevem hardware em HDL.',
        },
        {
          type: 'circuit', id: 'f4-s2-e4',
          q: 'Construa **A NOR B** usando NOT e OR (saída 1 só quando ambas são 0).',
          inputs: ['A', 'B'], target: (v) => !(v[0] || v[1]), allowed: ['NOT', 'AND', 'OR'], maxGates: 3,
          hints: ['NOR = NOT(A OR B). Faça o OR primeiro.', 'Adicione OR(A, B), depois NOT recebendo a saída do OR. Alternativa por De Morgan: NOT A, NOT B, AND dos dois.'],
          explain: 'Há duas soluções: NOT(OR(A,B)) com 2 portas, ou AND(NOT A, NOT B) com 3. Equivalentes por De Morgan; a primeira é mais barata.',
        },
      ],
    },
    {
      id: 's3',
      title: 'A porta universal: construindo tudo com NAND',
      body: `
## O desafio

Na Fase 3 você provou que {AND, OR, NOT} constrói qualquer função. Agora vamos mostrar que **NAND sozinho constrói AND, OR e NOT**. Juntando: NAND sozinho constrói qualquer função booleana. Portanto qualquer computador. Essa é a razão de a NAND ser chamada de **porta universal**, e de o curso Nand2Tetris existir.

> 🧪 **Tente antes de ler.** Pegue papel. A tabela do NAND é: 00→1, 01→1, 10→1, 11→0. Você tem só portas NAND e pode ligar a mesma entrada nas duas pernas de uma porta. Como faria um NOT? Pense por 2 minutos antes de continuar. Errar aqui é produtivo: quando ler a solução, ela vai "grudar".

## NOT com NAND

Ligue **A nas duas entradas** de um NAND: saída = NOT(A AND A) = NOT A (pela idempotência, A AND A = A).

| A | A NAND A |
|---|---|
| 0 | NOT(0 AND 0) = 1 |
| 1 | NOT(1 AND 1) = 0 |

**1 NAND = 1 NOT.** ✓

## AND com NAND

NAND é "AND negado". Então, se negarmos de novo, voltamos ao AND: AND = NOT(NAND). E NOT a gente já sabe fazer.

\`\`\`
porta 1: NAND recebe A e B      → g1 = NOT(A AND B)
porta 2: NAND recebe g1 e g1    → g2 = NOT(g1) = A AND B
\`\`\`

**2 NANDs = 1 AND.** ✓

## OR com NAND: aqui entra De Morgan

De Morgan: A OR B = NOT(NOT A AND NOT B). E "NOT(X AND Y)" é exatamente NAND(X, Y). Então:

A OR B = NAND(NOT A, NOT B)

\`\`\`
porta 1: NAND recebe A e A      → g1 = NOT A
porta 2: NAND recebe B e B      → g2 = NOT B
porta 3: NAND recebe g1 e g2    → g3 = NOT(NOT A AND NOT B) = A OR B
\`\`\`

**3 NANDs = 1 OR.** ✓ Confira na tabela: A=0,B=0: g1=1, g2=1, g3=NAND(1,1)=0. ✓ A=1,B=0: g1=0, g2=1, g3=NAND(0,1)=1. ✓

## XOR com NAND: 4 portas

Você já viu esse circuito na seção anterior. Agora entenda por quê. XOR = (A AND NOT B) OR (NOT A AND B). Com manipulação algébrica (que não vou detalhar; você pode conferir pela tabela):

\`\`\`
porta 1: NAND recebe A e B      → g1
porta 2: NAND recebe A e g1     → g2
porta 3: NAND recebe B e g1     → g3
porta 4: NAND recebe g2 e g3    → g4 = A XOR B
\`\`\`

Intuição: g1 é 0 só quando ambos são 1. g2 = NAND(A, g1) é 0 quando A=1 e g1=1, ou seja, A=1 e B=0. Simetricamente g3 é 0 quando B=1 e A=0. Então NAND(g2, g3) é 1 quando g2=0 ou g3=0, ou seja, quando exatamente um dos dois está ligado. XOR. ✓

## O resultado

| porta | NANDs necessários |
|---|---|
| NOT | 1 |
| AND | 2 |
| OR | 3 |
| NOR | 4 |
| XOR | 4 |

E, pelo teorema da Fase 3, qualquer tabela-verdade. **Toda a lógica digital se reduz a uma única peça, repetida.** Isso não é uma curiosidade: é o que torna a fabricação de chips viável. Uma fábrica otimiza uma célula básica e a replica bilhões de vezes.

> 📜 O mesmo vale para NOR (tente: NOT = NOR(A,A); OR = NOT(NOR); AND via De Morgan). O computador de orientação da Apollo, que levou humanos à Lua em 1969, foi construído com cerca de 5.600 chips, **todos do mesmo tipo: dois NOR de 3 entradas por chip.** Nada mais. Uma única peça repetida levou pessoas à Lua.

Agora é a sua vez. Use a bancada para sentir a NAND:

[[demo:gates-nand]]

E construa, com as próprias mãos, as portas básicas. Esta é a parte mais importante da fase: **não pule**.
`,
      exercises: [
        {
          type: 'circuit', id: 'f4-s3-e1',
          q: 'Construa **NOT A** usando só NAND. (Entrada B está disponível mas você não precisa dela.)',
          inputs: ['A', 'B'], target: (v) => !v[0], allowed: ['NAND'], maxGates: 1,
          hints: ['Uma porta NAND com A nas duas entradas.', 'NAND(A, A) = NOT(A AND A) = NOT A.'],
          explain: 'Ligar a mesma entrada nas duas pernas transforma NAND em NOT. Em silício, às vezes se liga uma perna direto no 1 (alimentação), que dá o mesmo resultado.',
        },
        {
          type: 'circuit', id: 'f4-s3-e2',
          q: 'Construa **A AND B** usando só NAND.',
          inputs: ['A', 'B'], target: (v) => v[0] && v[1], allowed: ['NAND'], maxGates: 2,
          hints: ['NAND é AND negado. Negue de novo.', 'Porta 1: NAND(A, B). Porta 2: NAND(g1, g1).'],
          explain: 'AND = NOT(NAND). Duas portas.',
        },
        {
          type: 'circuit', id: 'f4-s3-e3',
          q: 'Construa **A OR B** usando só NAND. Use De Morgan.',
          inputs: ['A', 'B'], target: (v) => v[0] || v[1], allowed: ['NAND'], maxGates: 3,
          hints: ['A OR B = NOT(NOT A AND NOT B) = NAND(NOT A, NOT B).', 'Porta 1: NAND(A,A). Porta 2: NAND(B,B). Porta 3: NAND(g1, g2).'],
          explain: 'Três NANDs. De Morgan deixou de ser uma regra abstrata e virou fios.',
        },
        {
          type: 'circuit', id: 'f4-s3-e4',
          q: 'Chefe menor: construa **A XOR B** usando só NAND (4 portas).',
          inputs: ['A', 'B'], target: (v) => v[0] !== v[1], allowed: ['NAND'], maxGates: 4,
          hints: ['Comece com g1 = NAND(A, B).', 'Depois g2 = NAND(A, g1) e g3 = NAND(B, g1).', 'Por fim, g4 = NAND(g2, g3).'],
          explain: 'Esse é o XOR de 4 NANDs, uma célula clássica. Na próxima fase, ele será o coração do somador.',
        },
        {
          type: 'circuit', id: 'f4-s3-e5',
          q: 'Desafio livre: construa o **detector de maioria** de 3 entradas (saída 1 quando pelo menos duas estão em 1) com AND e OR. Lembre: (A∧B)∨(A∧C)∨(B∧C).',
          inputs: ['A', 'B', 'C'], target: (v) => (v[0] ? 1 : 0) + (v[1] ? 1 : 0) + (v[2] ? 1 : 0) >= 2, allowed: ['AND', 'OR', 'NOT'], maxGates: 5,
          hints: ['Três ANDs: (A,B), (A,C), (B,C).', 'Depois OR dos dois primeiros, e OR desse resultado com o terceiro.'],
          explain: '5 portas. Guarde este circuito: é exatamente o "vai-um" do somador completo da Fase 5.',
        },
      ],
    },
    {
      id: 's4',
      title: 'Blocos úteis: multiplexador e decodificador',
      body: `
## Subindo mais um degrau

Com portas, vamos construir dois blocos que aparecem em todo processador. Isso serve para você praticar composição e, principalmente, para começar a enxergar como "decisões" e "endereços" são feitos de lógica.

## Multiplexador (MUX): o seletor

Um **multiplexador de 2 entradas** tem três entradas: A, B e SEL (seleção). Regra: se SEL = 0, a saída é A; se SEL = 1, a saída é B. É um "interruptor de duas posições", feito só de lógica.

| SEL | A | B | saída |
|---|---|---|---|
| 0 | 0 | 0 | 0 (=A) |
| 0 | 0 | 1 | 0 (=A) |
| 0 | 1 | 0 | 1 (=A) |
| 0 | 1 | 1 | 1 (=A) |
| 1 | 0 | 0 | 0 (=B) |
| 1 | 0 | 1 | 1 (=B) |
| 1 | 1 | 0 | 0 (=B) |
| 1 | 1 | 1 | 1 (=B) |

Fórmula: **saída = (NOT SEL AND A) OR (SEL AND B)**.

Leia a fórmula: quando SEL=0, o segundo termo morre (SEL AND B = 0) e o primeiro vira A. Quando SEL=1, o primeiro morre e o segundo vira B. É um "ou isto, ou aquilo", decidido por um bit.

[[demo:mux]]

> 💡 Por que isso é profundo: o MUX é a forma física do **"se... então... senão"**. Quando um programa faz \`x = cond ? a : b\`, lá no fundo há multiplexadores escolhendo entre valores. Toda decisão do processador (qual operação fazer, de qual registrador ler, para onde pular) passa por multiplexadores.

Com 2 bits de seleção, um MUX escolhe entre 4 entradas; com 3 bits, entre 8; com n bits, entre 2ⁿ entradas. De novo a regra 2ⁿ.

## Decodificador: de número para "qual linha"

Um **decodificador 2-para-4** recebe 2 bits (um número de 0 a 3) e tem 4 saídas. Exatamente **uma** saída fica em 1: a de número correspondente à entrada.

| A₁ | A₀ | S₀ | S₁ | S₂ | S₃ |
|---|---|---|---|---|---|
| 0 | 0 | 1 | 0 | 0 | 0 |
| 0 | 1 | 0 | 1 | 0 | 0 |
| 1 | 0 | 0 | 0 | 1 | 0 |
| 1 | 1 | 0 | 0 | 0 | 1 |

Fórmulas: S₀ = ¬A₁ ∧ ¬A₀; S₁ = ¬A₁ ∧ A₀; S₂ = A₁ ∧ ¬A₀; S₃ = A₁ ∧ A₀. Repare que são exatamente os termos AND do método "soma de produtos" da Fase 3! Um decodificador é uma máquina que gera todos os termos possíveis.

Para que serve? **Endereçamento de memória.** Quando o processador quer a célula de memória número 5, ele coloca 101 nos fios de endereço; um decodificador transforma isso em "ativa só a linha 5". Com 30 bits de endereço, um decodificador (em árvore) ativa uma entre 2³⁰ ≈ 1 bilhão de linhas. Vamos usar isso na Fase 6.

Outro uso: **decodificar instruções**. Quando o processador lê um byte de instrução, um decodificador transforma o padrão de bits em "ative o circuito de soma" ou "ative o circuito de cópia". Fase 7.

## O que você já consegue construir

Pare e perceba o caminho percorrido. Partindo de "uma lâmpada acesa ou apagada", você agora tem:

- qualquer função booleana (Fase 3) feita de portas (Fase 4);
- portas feitas de uma única peça universal (NAND);
- seletores (MUX) e decodificadores, que são a base de decisões e endereços.

Na próxima fase, com essas peças, vamos construir uma máquina que **faz contas**.
`,
      exercises: [
        {
          type: 'circuit', id: 'f4-s4-e1',
          q: 'Construa um **multiplexador**: entradas A, B e S. Saída = A quando S=0, B quando S=1. Fórmula: (NOT S AND A) OR (S AND B).',
          inputs: ['A', 'B', 'S'], target: (v) => (v[2] ? v[1] : v[0]), allowed: ['NOT', 'AND', 'OR'], maxGates: 4,
          hints: ['Porta 1: NOT S.', 'Porta 2: AND(A, g1). Porta 3: AND(B, S).', 'Porta 4: OR(g2, g3).'],
          explain: 'Você construiu o "se/senão" físico. Cada decisão de um processador passa por algo assim.',
        },
        {
          type: 'circuit', id: 'f4-s4-e2',
          q: 'Construa a saída **S₂** de um decodificador 2-para-4: deve ser 1 somente quando A=1 e B=0 (A é o bit mais significativo).',
          inputs: ['A', 'B'], target: (v) => v[0] && !v[1], allowed: ['NOT', 'AND', 'OR', 'NAND'], maxGates: 3,
          hints: ['É o termo AND da linha "10": A direta, B negada.', 'NOT B, depois AND(A, g1).'],
          explain: 'Cada saída de um decodificador é um termo AND da forma normal. Para 4 saídas, 4 termos; para 2ⁿ saídas, 2ⁿ termos.',
        },
        {
          type: 'input', id: 'f4-s4-e3',
          q: 'Um multiplexador precisa escolher entre **32 entradas**. Quantos bits de seleção (SEL) ele precisa?',
          answer: '5',
          hints: ['n bits selecionam entre 2ⁿ entradas.', '2⁵ = 32.'],
          explain: '5 bits. É o mesmo raciocínio das lamparinas da Fase 0, agora aplicado a um bloco de hardware.',
        },
        {
          type: 'explain', id: 'f4-s4-e4',
          q: 'Explique o que é abstração em camadas usando o que você viu nesta fase (transistor → porta → bloco). Por que podemos "esquecer" os transistores ao projetar com portas?',
          keywords: [['camada', 'nível', 'abstra'], ['transistor'], ['porta', 'gate'], ['tabela', 'comport', 'confi', 'garant', 'funciona'], ['esquec', 'ignor', 'não precisa', 'sem olhar', 'esconde']],
          minGroups: 4,
          model: 'Cada camada é construída sobre a anterior e, uma vez que se garante que ela se comporta conforme a especificação (a porta obedece à sua tabela-verdade), podemos usá-la sem olhar dentro. Transistores formam portas; portas formam blocos como MUX e decodificador; blocos formam o processador. Ao projetar com portas, não precisamos pensar em transistores porque a porta é uma caixa confiável: mesmas entradas, mesma saída. Isso reduz a complexidade e é o mesmo princípio que torna possível programar sem pensar em hardware.',
        },
      ],
    },
  ],
  boss: {
    title: 'Chefe da Fase 4: O Forjador de NAND',
    intro: 'O Forjador lhe dá uma única ferramenta e exige que você construa tudo. Depois, testa se você sabe ler circuitos e explicar por que eles funcionam. Monte as tabelas se precisar.',
    passRatio: 0.8,
    exercises: [
      { type: 'circuit', id: 'f4-b1', q: 'Construa **A NOR B** usando só NAND (até 4 portas).', inputs: ['A', 'B'], target: (v) => !(v[0] || v[1]), allowed: ['NAND'], maxGates: 4, hints: ['NOR = NOT(OR). Você sabe fazer OR com 3 NANDs e NOT com 1.', 'NAND(A,A), NAND(B,B), NAND(g1,g2) = OR; depois NAND(g3,g3).'], explain: '4 NANDs. Toda porta se reduz a NAND.' },
      { type: 'circuit', id: 'f4-b2', q: 'Construa **(A OR B) AND (NOT C)** com NOT, AND, OR.', inputs: ['A', 'B', 'C'], target: (v) => (v[0] || v[1]) && !v[2], allowed: ['NOT', 'AND', 'OR'], maxGates: 3, hints: ['OR(A,B); NOT C; AND dos dois.'], explain: 'Três portas, lendo a fórmula de dentro para fora.' },
      {
        type: 'mc', id: 'f4-b3', q: 'Leia: `porta 1: NAND(A,B) → g1; porta 2: NAND(g1,g1) → saída`. Função?',
        options: [{ t: 'A AND B', ok: true, fb: 'NAND seguido de NOT = AND.' }, { t: 'A OR B', fb: 'Teste A=1,B=0: g1=1, saída=NAND(1,1)=0. OR daria 1.' }, { t: 'A NAND B', fb: 'A segunda porta inverte g1. NAND invertido é AND.' }],
        explain: 'Leitura de circuito.',
      },
      {
        type: 'mc', id: 'f4-b4', q: 'Por que NAND é chamada de "porta universal"?',
        options: [{ t: 'Porque é usada em todos os países.', fb: 'Não é geografia. É sobre capacidade de construção.' }, { t: 'Porque só com NANDs dá para construir NOT, AND e OR, e com essas três, qualquer função booleana.', ok: true, fb: 'Exato: universal = funcionalmente completa sozinha.' }, { t: 'Porque é a porta mais rápida.', fb: 'Ela é barata em transistores, mas "universal" se refere a poder construir todas as outras.' }],
        explain: 'Junção do teorema da Fase 3 com as construções desta fase.',
      },
      { type: 'input', id: 'f4-b5', q: 'Quantas portas NAND são necessárias, no mínimo (pelas construções que você fez), para um **XOR**?', answer: '4', hints: ['Você construiu na seção 3.'], explain: '4 NANDs.' },
      {
        type: 'mc', id: 'f4-b6', q: 'Dois interruptores em PARALELO (caminhos separados) realizam:',
        options: [{ t: 'AND', fb: 'Em paralelo, basta um caminho fechado para a corrente passar. Isso é "pelo menos um".' }, { t: 'OR', ok: true, fb: 'Paralelo = OR.' }, { t: 'NOT', fb: 'NOT precisa de um interruptor que abre ao ser acionado.' }],
        explain: 'Shannon, 1937.',
      },
      { type: 'circuit', id: 'f4-b7', q: 'Construa um circuito "**igualdade**": saída 1 quando A = B (ambos 0 ou ambos 1). Isso é o XNOR.', inputs: ['A', 'B'], target: (v) => v[0] === v[1], allowed: ['NOT', 'AND', 'OR', 'XOR'], maxGates: 3, hints: ['Igualdade é o contrário de "diferentes" (XOR).', 'XOR(A,B) e depois NOT.'], explain: 'XNOR = NOT XOR. Comparadores de igualdade de números inteiros são feitos com XNORs em cada bit e um AND de tudo.' },
      {
        type: 'explain', id: 'f4-b8', q: 'Explique por que um multiplexador pode ser visto como a versão física de um "se... então... senão".',
        keywords: [['sel', 'seleç', 'controle', 'condição'], ['escolh', 'decid', 'passa'], ['entrada', 'a ou b', 'valor'], ['se', 'então', 'senão', 'if', 'else']],
        minGroups: 3,
        model: 'Um MUX tem um bit de seleção que decide qual das entradas chega à saída: se SEL é 0, passa A; senão, passa B. É exatamente a estrutura "se condição então valor1 senão valor2". Dentro do processador, as condições dos programas acabam virando bits de seleção que controlam multiplexadores escolhendo entre caminhos de dados.',
      },
    ],
  },
  review: [
    { id: 'f4-r1', q: 'Interruptores em série fazem qual operação? E em paralelo?', a: 'Série = AND; paralelo = OR. (Shannon, 1937.)' },
    { id: 'f4-r2', q: 'O que faz um transistor, no modelo simplificado?', a: 'É um interruptor controlado por tensão: entrada de controle em 1 conduz; em 0, bloqueia.' },
    { id: 'f4-r3', q: 'Como fazer NOT com NAND?', a: 'NAND(A, A): ligar a mesma entrada nas duas pernas.' },
    { id: 'f4-r4', q: 'Como fazer OR com NAND?', a: 'NAND(NOT A, NOT B), onde cada NOT é um NAND(x,x). 3 portas. Vem de De Morgan.' },
    { id: 'f4-r5', q: 'O que é um circuito combinacional?', a: 'Um cujo resultado depende só das entradas atuais (sem memória, sem realimentação).' },
    { id: 'f4-r6', q: 'O que faz um multiplexador (MUX)?', a: 'Escolhe qual entrada vai para a saída, com base em bits de seleção. É o "se/senão" físico.' },
    { id: 'f4-r7', q: 'O que faz um decodificador?', a: 'Transforma um número de n bits em uma única linha ativa entre 2ⁿ. Usado em endereçamento de memória e decodificação de instruções.' },
    { id: 'f4-r8', q: 'Por que NAND é mais barata que AND em CMOS?', a: 'NAND usa 4 transistores; AND = NAND + NOT = 6.' },
  ],
  glossary: [
    { pt: 'porta lógica', en: 'logic gate', def: 'Circuito físico que realiza uma operação booleana.', origin: '"Gate" = portão: deixa ou não o sinal passar.' },
    { pt: 'relé', en: 'relay', def: 'Interruptor mecânico acionado por eletroímã. Base dos primeiros computadores.' },
    { pt: 'válvula', en: 'vacuum tube', def: 'Interruptor eletrônico a vácuo, anos 1940–50.' },
    { pt: 'CMOS', en: 'CMOS', def: 'Tecnologia que combina dois tipos complementares de transistor; base dos chips atuais.', origin: 'Complementary Metal-Oxide-Semiconductor.' },
    { pt: 'abstração', en: 'abstraction', def: 'Usar uma camada pela sua interface/comportamento, ignorando a implementação interna.' },
    { pt: 'circuito combinacional', en: 'combinational circuit', def: 'Saída depende só das entradas atuais.' },
    { pt: 'atraso de propagação', en: 'propagation delay', def: 'Tempo que uma porta leva para refletir na saída uma mudança na entrada.' },
    { pt: 'caminho crítico', en: 'critical path', def: 'Cadeia de portas mais lenta de um circuito; limita a frequência do clock.' },
    { pt: 'multiplexador', en: 'multiplexer (MUX)', def: 'Seleciona uma entre 2ⁿ entradas com n bits de seleção.' },
    { pt: 'decodificador', en: 'decoder', def: 'Ativa uma entre 2ⁿ saídas conforme um número de n bits.' },
    { pt: 'HDL', en: 'Hardware Description Language', def: 'Linguagem para descrever circuitos como texto (Verilog, VHDL). Nosso construtor de listas de portas é uma mini-HDL.' },
    { pt: 'fan-out', en: 'fan-out', def: 'Quantas entradas uma saída alimenta.' },
  ],
};
