import type { Phase } from '../lib/types';

export const phase0: Phase = {
  id: 'f0',
  num: 0,
  emoji: '💡',
  title: 'O átomo da informação',
  subtitle: 'O que é informação, por que ela pode ser reduzida a "sim ou não", e o nascimento do bit',
  goal: 'Ao final desta fase você vai saber explicar, sem decorar, o que é um bit, por que ele é a menor unidade possível de informação, e por que computadores escolheram trabalhar com apenas dois estados.',
  sections: [
    {
      id: 's1',
      title: 'Antes de qualquer máquina: o que é "informação"?',
      body: `
## Um problema de 1850

Imagine que você mora numa fazenda, no século XIX, e sua irmã mora em outra fazenda a 3 quilômetros, do outro lado do vale. Vocês combinam o seguinte: toda noite, às 20h, cada uma olha pela janela. Se a lamparina da outra estiver **acesa**, significa "está tudo bem". Se estiver **apagada**, significa "preciso de ajuda, venha amanhã".

Pare e pense no que acabou de acontecer. Você não enviou nenhuma palavra. Não enviou nenhum número. Enviou **uma única distinção**: acesa *ou* apagada. E, ainda assim, informação de verdade atravessou o vale.

> 💡 Informação, no sentido mais básico e preciso, é **a resolução de uma dúvida**. Antes de olhar pela janela, você não sabia se sua irmã estava bem. Depois de olhar, sabia. Algo mudou na sua cabeça. Essa mudança é informação.

Note que, se a lamparina estivesse **sempre** acesa, todas as noites, sem exceção, por 10 anos, ela deixaria de carregar informação. Você já saberia o que ia ver. Nenhuma dúvida seria resolvida. Isso é um ponto profundo: **informação só existe onde há mais de uma possibilidade**. Onde só existe uma possibilidade, não há nada a ser informado.

## Quantas possibilidades no mínimo?

Agora a pergunta que define toda a computação: **qual é a menor quantidade de informação que pode existir?**

Para que exista informação, precisa haver dúvida. Para haver dúvida, precisa haver pelo menos duas possibilidades. Com uma só, não há dúvida. Com duas, há a menor dúvida possível: "é esta ou aquela?".

Então a menor unidade de informação é a resposta a uma pergunta com exatamente duas respostas possíveis. Sim ou não. Acesa ou apagada. Verdadeiro ou falso. Cara ou coroa.

> 📜 Em 1948, um engenheiro e matemático americano chamado **Claude Shannon** publicou um artigo chamado *A Mathematical Theory of Communication* ("Uma Teoria Matemática da Comunicação"). Nele, ele definiu formalmente essa unidade mínima e lhe deu nome. Esse artigo é considerado o nascimento da Teoria da Informação, e é a razão pela qual conseguimos medir informação como medimos peso ou distância.

> 🔤 **Bit** vem do inglês **b**inary dig**it**, "dígito binário". *Binary* quer dizer "de dois" (do latim *bini*, "dois a dois"). *Digit* quer dizer "dígito, algarismo" (do latim *digitus*, "dedo", porque se contava nos dedos). Portanto: bit = um algarismo que só pode ter dois valores. O nome foi sugerido pelo estatístico John Tukey e popularizado por Shannon.

Experimente agora. Abaixo há a lamparina da sua irmã. Note como não existe um terceiro estado.

[[demo:bit-switch]]

## Por que escrevemos 0 e 1?

Repare: a lamparina não "é" 0 nem "é" 1. Ela é uma lamparina. **Nós** decidimos chamar o estado apagado de 0 e o estado aceso de 1. Poderíamos ter chamado de A e B, ou de "frio" e "quente", ou de ✗ e ✓.

Escolhemos 0 e 1 por um motivo que vai ficar claro na Fase 1: esses dois símbolos já são algarismos, e isso vai permitir que a gente **conte** e **faça contas** com bits. Mas guarde desde já esta ideia:

> 💡 Um bit não é "um zero ou um um". Um bit é **qualquer coisa física que pode estar em um de dois estados distinguíveis**, mais a **convenção** (o acordo) sobre o que cada estado significa. O 0 e o 1 são só os nomes que damos aos dois estados.

Isso significa que um bit pode ser:

- uma lâmpada acesa ou apagada;
- um interruptor ligado ou desligado;
- um furo presente ou ausente num cartão de papel (assim funcionavam os primeiros computadores);
- um pedacinho de um disco magnetizado para "norte" ou para "sul" (assim funcionam HDs);
- uma pequenina região de um chip com carga elétrica presa ou sem carga (assim funcionam SSDs e pendrives);
- um fio com tensão elétrica alta (por exemplo, 3,3 volts) ou baixa (0 volts): é assim dentro de um processador.

Em todos esses casos, a **física** é diferente, mas a **informação** é a mesma: 1 bit.

## Verificação rápida: isso é informação?

Antes dos exercícios, vamos treinar o olhar. Em cada caso, pergunte: *há mais de uma possibilidade? Alguma dúvida é resolvida?*

- "O sol nasceu hoje." Pouquíssima informação: era quase certo. Praticamente nenhuma dúvida resolvida.
- "O número sorteado foi 47." Muita informação: havia dezenas de possibilidades, e uma foi escolhida.
- Um semáforo: três estados (verde, amarelo, vermelho). Carrega informação, mas **mais que 1 bit**, porque há três possibilidades, não duas. Vamos aprender a medir isso daqui a pouco.
`,
      exercises: [
        {
          type: 'mc', id: 'f0-s1-e1',
          q: 'Sua vizinha coloca uma bandeira vermelha na janela todos os dias, sem exceção, há 20 anos. Hoje você olha e vê a bandeira vermelha. Quanta informação você recebeu ao olhar?',
          options: [
            { t: 'Muita, porque vermelho é uma cor forte e chamativa.', fb: 'A intensidade da cor não tem nada a ver com informação. Informação é sobre dúvida resolvida, não sobre o quão visível é o sinal.' },
            { t: 'Praticamente nenhuma, porque você já sabia o que ia ver: não havia dúvida a resolver.', ok: true, fb: 'Exatamente. Se só existe uma possibilidade (sempre vermelha), não há dúvida, e portanto não há informação transmitida.' },
            { t: 'Exatamente 1 bit, porque uma bandeira é um objeto único.', fb: 'Um bit exige DUAS possibilidades reais. Se a bandeira nunca muda, na prática só existe uma possibilidade. O objeto ser "único" não importa.' },
          ],
          explain: 'Essa é a ideia central de Shannon: informação mede **surpresa** ou **redução de incerteza**. Um sinal que nunca muda não informa nada, mesmo que você olhe para ele todo dia.',
        },
        {
          type: 'mc', id: 'f0-s1-e2',
          q: 'Qual destas opções NÃO pode funcionar como um bit?',
          options: [
            { t: 'Um interruptor de luz comum (ligado/desligado).', fb: 'Isso é um bit perfeito: dois estados claramente distinguíveis.' },
            { t: 'Uma porta que pode estar aberta ou fechada.', fb: 'Também é um bit: dois estados. Precisamos apenas combinar o que cada um significa.' },
            { t: 'Um dado de seis faces jogado na mesa.', ok: true, fb: 'Correto. Um dado parado tem seis estados possíveis, não dois. Ele carrega informação, mas é MAIS que um bit. (Você poderia usá-lo como bit só se combinasse algo como "par = 0, ímpar = 1", mas aí estaria jogando fora parte da informação.)' },
            { t: 'Um fio elétrico que pode ter tensão alta ou baixa.', fb: 'É exatamente assim que processadores guardam bits: tensão alta = 1, tensão baixa = 0.' },
          ],
          explain: 'Um bit é definido pela existência de **exatamente dois** estados distinguíveis. Mais estados = mais informação por "símbolo", e vamos aprender a medir isso na próxima seção.',
        },
        {
          type: 'explain', id: 'f0-s1-e3',
          q: 'Explique com suas próprias palavras: **o que é um bit?** Tente incluir de onde vem o nome e por que ele é a menor unidade possível de informação.',
          keywords: [['dois', '2', 'duas'], ['estado', 'possibilidade', 'opção', 'valor'], ['menor', 'mínima', 'mínimo', 'pequena'], ['binary', 'binário', 'binária', 'digit', 'dígito'], ['dúvida', 'incerteza', 'pergunta', 'informação']],
          minGroups: 3,
          model: 'Um bit é a menor unidade de informação: a resposta a uma pergunta que só tem duas respostas possíveis (sim/não, 0/1). O nome vem de "binary digit", dígito binário, "de dois valores". É a menor unidade porque, com menos de duas possibilidades, não há dúvida nenhuma a resolver, e sem dúvida não há informação. Qualquer coisa física com dois estados distinguíveis pode ser usada como bit, desde que combinemos o que cada estado significa.',
        },
      ],
    },
    {
      id: 's2',
      title: 'Medindo informação: por que 2 bits valem 4 possibilidades',
      body: `
## Uma lamparina não basta

Voltemos ao vale. Com uma lamparina, você e sua irmã conseguem transmitir uma de duas mensagens por noite: "tudo bem" ou "venha". Mas e se vocês quisessem mais opções? Por exemplo:

1. Tudo bem.
2. Venha amanhã.
3. Mande o médico.
4. A vaca fugiu de novo.

Uma lamparina tem só dois estados. Quatro mensagens não cabem. A solução óbvia é usar **duas lamparinas**, lado a lado. Vamos listar todas as combinações possíveis:

| Lamparina da esquerda | Lamparina da direita | Mensagem combinada |
|---|---|---|
| apagada (0) | apagada (0) | Tudo bem |
| apagada (0) | acesa (1) | Venha amanhã |
| acesa (1) | apagada (0) | Mande o médico |
| acesa (1) | acesa (1) | A vaca fugiu |

Duas lamparinas → quatro combinações. Isso não é coincidência. Vamos entender *por quê*.

## A regra da multiplicação

A primeira lamparina pode estar de 2 jeitos. **Para cada um desses jeitos**, a segunda pode estar de 2 jeitos. Então o total é 2 × 2 = 4.

Se acrescentarmos uma terceira lamparina, para **cada** uma das 4 combinações anteriores, a nova pode estar de 2 jeitos: 4 × 2 = 8.

Uma quarta: 8 × 2 = 16. Uma quinta: 32. Uma sexta: 64.

> 💡 **Regra fundamental:** com *n* bits, existem **2 × 2 × 2 × ... (n vezes)** combinações diferentes. Escrevemos isso como **2ⁿ** e lemos "dois elevado a n". Não é "2 vezes n"! É 2 multiplicado por si mesmo n vezes. Com 10 bits não são 20 combinações: são 1.024.

Vamos ver a tabela crescer. Memorize pelo menos até 2⁸: ela vai aparecer o tempo todo.

[[demo:powers]]

Essa tabela vai ser sua amiga pelo curso inteiro. Algumas dessas potências têm nomes que você já ouviu:

- **2⁸ = 256**: o número de valores que cabem em um **byte** (vamos definir byte na Fase 2).
- **2¹⁰ = 1.024**: é quase mil, por isso "kilo" em computação muitas vezes significa 1.024, e não 1.000.
- **2³² ≈ 4,29 bilhões**: o número de endereços que um sistema "de 32 bits" conseguia acessar, e por isso eles tinham um limite de ~4 GB de memória.

## O raciocínio inverso: de quantos bits eu preciso?

Agora vire a pergunta. Se eu tenho uma lista de mensagens possíveis, **quantos bits preciso para distinguir todas?**

A resposta é: o menor *n* tal que 2ⁿ seja **maior ou igual** ao número de mensagens.

- 2 mensagens → 1 bit (2¹ = 2).
- 3 mensagens → 2 bits (2¹ = 2 é pouco; 2² = 4 dá e sobra uma combinação sem uso).
- 4 mensagens → 2 bits (2² = 4, exato).
- 5 mensagens → 3 bits (2² = 4 é pouco; 2³ = 8).
- 26 letras do alfabeto → 5 bits (2⁴ = 16 é pouco; 2⁵ = 32).
- 100 mensagens → 7 bits (2⁶ = 64 é pouco; 2⁷ = 128).

> ⚠️ **Simplificação avisada.** Shannon mostrou que, se algumas mensagens são mais prováveis que outras, dá para usar *menos* bits em média (é a base da compactação de arquivos, como ZIP). Aqui estamos assumindo que todas as mensagens são igualmente prováveis, o que dá a conta simples acima. Essa é a versão que você precisa agora.

## O jogo das 20 perguntas

Existe um jogo antigo em que uma pessoa pensa em algo e a outra tem direito a 20 perguntas de "sim ou não" para adivinhar. Agora você consegue entender por que esse jogo funciona: cada pergunta de sim/não é **1 bit** de informação. Com 20 bits, você distingue 2²⁰ = 1.048.576 coisas diferentes. Mais de um milhão. É por isso que, com boas perguntas, dá para adivinhar quase qualquer coisa.

E a boa pergunta é aquela que **divide as possibilidades ao meio**. "É um animal?" é boa. "É um ornitorrinco?" é péssima: se a resposta for não, você eliminou só uma possibilidade.

> 💡 Essa ideia, de "cortar o espaço de possibilidades pela metade a cada bit", vai reaparecer quando você estudar programação, num algoritmo chamado **busca binária**. Guarde-a.
`,
      exercises: [
        {
          type: 'input', id: 'f0-s2-e1',
          q: 'Com **3 lamparinas** (3 bits), quantas combinações diferentes existem? Responda só o número.',
          answer: '8',
          hints: ['Cada lamparina multiplica as possibilidades por 2. Comece com 1 lamparina (2 jeitos) e vá acrescentando.', '2 × 2 × 2 = ?', 'Não é 2 × 3 = 6. É 2 multiplicado por si mesmo 3 vezes.'],
          explain: '2³ = 2 × 2 × 2 = 8. Se quiser conferir, liste: 000, 001, 010, 011, 100, 101, 110, 111. São exatamente oito.',
        },
        {
          type: 'input', id: 'f0-s2-e2',
          q: 'Um elevador atende **12 andares**. Quantos bits são necessários, no mínimo, para representar "em qual andar o elevador está"? Responda só o número.',
          answer: '4',
          hints: ['Procure a menor potência de 2 que seja maior ou igual a 12.', '2³ = 8 é suficiente para 12 andares? E 2⁴?', '8 < 12 ≤ 16. Então são 4 bits (e sobram 4 combinações sem uso, o que é normal).'],
          explain: 'Com 3 bits só temos 8 combinações, insuficientes. Com 4 bits temos 16: cabem os 12 andares, e sobram 4 códigos não usados. Esse "sobrar" é normal e acontece o tempo todo em computação.',
        },
        {
          type: 'mc', id: 'f0-s2-e3',
          q: 'Você está jogando "20 perguntas" e a pessoa pensou em um número de 1 a 1000. Qual primeira pergunta extrai MAIS informação?',
          options: [
            { t: '"É o número 500?"', fb: 'Se a resposta for "não" (o mais provável, 999 em 1000), você quase não eliminou nada. Pergunta fraca: muito pouca informação em média.' },
            { t: '"É maior que 500?"', ok: true, fb: 'Essa pergunta divide as possibilidades quase ao meio: qualquer que seja a resposta, sobram ~500 números. É o máximo de informação que 1 bit pode dar.' },
            { t: '"É menor que 10?"', fb: 'Se for "não" (990 em 1000 de chance), você eliminou só 9 números. Em média, pouquíssima informação.' },
          ],
          explain: 'Um bit carrega o máximo de informação quando as duas respostas são igualmente prováveis. Por isso perguntas que "dividem ao meio" são as melhores. Com 10 perguntas assim você acha qualquer número de 1 a 1024.',
        },
        {
          type: 'input', id: 'f0-s2-e4',
          q: 'Quantas combinações diferentes existem com **8 bits**? (Este número você vai usar centenas de vezes; vale decorar.)',
          answer: '256',
          hints: ['2⁸. Vá dobrando: 2, 4, 8, 16, 32, 64, 128, ...', 'Dobre mais uma vez depois de 128.'],
          explain: '2⁸ = 256. Esse é o número de valores que cabem em um byte: de 0 a 255. Vai aparecer em cores (0–255 por canal), em endereços de rede (192.168.0.1 são quatro números de 0 a 255), em texto ASCII e muito mais.',
        },
      ],
    },
    {
      id: 's3',
      title: 'Por que dois estados, e não dez? A decisão de engenharia',
      body: `
## A pergunta que todo iniciante deveria fazer

Nós, humanos, contamos com dez símbolos (0 a 9). Por que os computadores não usam dez estados também? Seria mais "natural" para nós. Se um fio pudesse ter dez níveis de tensão diferentes, cada fio carregaria mais informação, e precisaríamos de menos fios.

Essa pergunta é excelente, e a resposta não é "porque sim". É uma **decisão de engenharia** baseada em três problemas concretos.

## Problema 1: ruído

Nenhum sinal físico é perfeito. Um fio que deveria estar em 5 volts pode estar em 4,8 ou 5,3 por causa de calor, interferência de outros fios, variação na fonte de energia. Chamamos essas perturbações de **ruído** (em inglês, *noise*).

Imagine um sistema com dez estados, usando tensões de 0, 1, 2, ..., 9 volts. A diferença entre "4" e "5" é de apenas 1 volt. Um ruído de meio volt já cria dúvida: era 4,5 volts... é um 4 ou um 5?

Agora imagine um sistema com dois estados: 0 volts e 5 volts. Um ruído de meio volt é irrelevante: 0,5 volts ainda é claramente "baixo"; 4,5 volts ainda é claramente "alto". Na prática, define-se uma faixa: abaixo de ~1,5 V é 0, acima de ~3,5 V é 1, e o meio é "zona proibida" que o circuito é projetado para atravessar rapidamente, sem ficar parado nela.

> 💡 Com dois estados, você pode colocar os dois estados **o mais longe possível um do outro**. Isso dá a máxima resistência ao ruído. É a razão número um de os computadores serem binários.

## Problema 2: a física dos componentes

Os componentes eletrônicos que formam os computadores modernos são chamados de **transistores** (vamos entendê-los melhor na Fase 4). A coisa mais simples e confiável que um transistor consegue fazer é funcionar como um **interruptor**: ou deixa a corrente passar, ou bloqueia. Ligado ou desligado.

Fazer um transistor manter dez níveis de corrente precisos e estáveis é possível, mas muito mais difícil, caro, lento e sujeito a erro. Fazer ele funcionar como um interruptor é fácil, barato e rápido. Quando você vai fabricar **bilhões** deles num chip do tamanho de uma unha (um processador moderno tem mais de 10 bilhões de transistores), "fácil e confiável" vence.

## Problema 3: a lógica

Este é o motivo mais bonito, e vai ocupar a Fase 3 inteira. Existe um sistema matemático, criado em 1847 por um inglês chamado **George Boole**, que trabalha com exatamente dois valores: verdadeiro e falso. Ele descobriu que raciocínio lógico ("se chover E eu não tiver guarda-chuva, então me molho") pode ser feito com operações sobre esses dois valores, como se fossem contas.

Quando você usa dois estados, os seus bits podem ser ao mesmo tempo:

- **algarismos** (para contar e fazer contas);
- **valores lógicos** (verdadeiro/falso, para tomar decisões).

Essa coincidência, de que o menor sistema numérico e o sistema lógico de Boole usam os mesmos dois valores, é o que permite que uma única máquina faça aritmética *e* tome decisões com os mesmos componentes. Isso é um computador.

> 📜 Em 1937, um estudante de mestrado americano chamado **Claude Shannon** (o mesmo!) escreveu uma dissertação mostrando que circuitos elétricos com interruptores podiam realizar toda a álgebra de Boole. Essa dissertação é frequentemente chamada de "a mais importante dissertação de mestrado do século XX". Ela é a ponte entre a lógica abstrata e o hardware físico.

## Houve computadores decimais?

Sim! O ENIAC (1945), um dos primeiros computadores eletrônicos, era decimal: contava com "anéis" de dez válvulas. Era enorme, consumia 150 kW e queimava válvulas o tempo todo. Já o EDVAC, projetado logo depois por John von Neumann e equipe, era binário, e desde então praticamente todos os computadores são binários. A experiência mostrou na prática que binário é mais simples e confiável.

Também existiu um computador **ternário** (três estados: -1, 0, +1), o Setun, construído na União Soviética em 1958. Funcionava bem, mas não vingou: a indústria inteira já tinha se organizado em torno do binário, e os ganhos não compensavam a troca.

> ⚠️ **Honestidade:** "binário é melhor" não é uma lei da natureza. É o resultado de um balanço entre ruído, custo de fabricação, simplicidade de projeto e história. Computadores quânticos, por exemplo, usam **qubits**, que não se comportam como bits comuns. Mas para tudo o que você vai usar como programador, o mundo é binário, e por bons motivos.

## Onde a nossa "base" começa e termina

Agora dá para dizer com precisão qual é a fundação que este curso ensina:

- **Começa** no bit: a menor unidade de informação, fisicamente realizada como dois estados.
- **Passa** por como bits representam números, texto e qualquer outra coisa (Fases 1 e 2).
- **Passa** pela lógica de Boole, que diz como combinar bits (Fase 3), e pelas portas lógicas, que são essa lógica feita de interruptores (Fase 4).
- **Passa** por como portas fazem contas (Fase 5) e lembram coisas (Fase 6).
- **Termina** no momento em que uma sequência de bits guardada na memória é lida e executada como **instrução**: o nascimento do programa (Fase 7).

Acima disso ficam as linguagens de programação, sistemas operacionais, internet, inteligência artificial. **Tudo** isso é construído em cima desta camada. Nada abaixo dela é "programação": abaixo está a física dos materiais. Por isso essa é a base.
`,
      exercises: [
        {
          type: 'mc', id: 'f0-s3-e1',
          q: 'Um engenheiro propõe um chip em que cada fio pode ter 16 níveis de tensão diferentes, "para carregar 4 bits por fio e economizar espaço". Qual é o principal problema prático dessa ideia?',
          options: [
            { t: 'É matematicamente impossível representar 16 valores em um fio.', fb: 'Não é impossível: matematicamente, 16 níveis distinguíveis = 4 bits. O problema não é matemático.' },
            { t: 'Os 16 níveis ficam muito próximos uns dos outros, e o ruído elétrico faria o circuito confundir um nível com o vizinho.', ok: true, fb: 'Exato. Dividindo a mesma faixa de tensão em 16 fatias em vez de 2, cada fatia fica 8 vezes mais estreita, e a tolerância ao ruído despenca.' },
            { t: 'Computadores só entendem 0 e 1 por definição, então não funcionaria.', fb: 'Isso é circular ("é binário porque é binário"). Computadores são binários por uma razão de engenharia, não por definição. Qual é a razão?' },
          ],
          explain: 'Na prática, existem memórias flash (SSDs) que guardam 3 ou 4 bits por célula usando múltiplos níveis de carga. Elas funcionam, mas são mais lentas e menos duráveis que as de 1 bit por célula, exatamente por causa da menor tolerância a ruído. A teoria bate com a prática.',
        },
        {
          type: 'mc', id: 'f0-s3-e2',
          q: 'Qual "coincidência" torna o sistema binário especialmente poderoso para construir computadores?',
          options: [
            { t: 'O número 2 é o menor número primo.', fb: 'É verdade, mas isso não tem relação direta com a utilidade do binário em computadores.' },
            { t: 'Os mesmos dois valores servem tanto como algarismos (para contar) quanto como valores lógicos verdadeiro/falso (para decidir).', ok: true, fb: 'Essa é a chave: a álgebra de Boole e o sistema numérico de base 2 usam os mesmos dois símbolos, então um só tipo de circuito faz contas e toma decisões.' },
            { t: 'Dois estados cabem exatamente em um transistor, e dez não caberiam.', fb: 'Transistores podem ter vários níveis (memórias flash fazem isso). A questão não é "caber", é confiabilidade e a conexão com a lógica.' },
          ],
          explain: 'Shannon (1937) provou que interruptores elétricos podem realizar toda a álgebra de Boole. Daí em diante, "fazer lógica" e "fazer circuito" viraram a mesma coisa.',
        },
        {
          type: 'explain', id: 'f0-s3-e3',
          q: 'Um amigo diz: "computadores usam 0 e 1 porque só entendem isso". Corrija a frase com suas palavras, dando pelo menos dois motivos reais de engenharia para a escolha do binário.',
          keywords: [['ruído', 'interferência', 'noise', 'confund'], ['transistor', 'interruptor', 'simples', 'barato', 'confiável'], ['lógica', 'boole', 'verdadeiro', 'decis'], ['longe', 'distante', 'separad', 'diferença', 'tolerância']],
          minGroups: 2,
          model: 'Computadores não "só entendem" 0 e 1: eles foram projetados com dois estados porque (1) dois estados podem ficar bem afastados um do outro (ex.: 0 V e 5 V), o que torna o circuito muito resistente a ruído elétrico; (2) o componente básico, o transistor, funciona de forma mais simples, barata e confiável como um interruptor liga/desliga; e (3) dois valores coincidem com o verdadeiro/falso da lógica de Boole, permitindo que a mesma máquina faça contas e tome decisões. Já existiram computadores decimais e ternários; o binário venceu por engenharia, não por necessidade absoluta.',
        },
      ],
    },
  ],
  boss: {
    title: 'Chefe da Fase 0: O Guardião do Vale',
    intro: 'O Guardião só deixa passar quem entende informação de verdade, e não quem decorou. Responda sem consultar o texto. Se errar, tudo bem: você verá o que faltou e poderá tentar de novo depois de revisar. É preciso acertar pelo menos 80% na primeira tentativa de cada pergunta.',
    passRatio: 0.8,
    exercises: [
      {
        type: 'mc', id: 'f0-b1',
        q: 'O que define, de forma precisa, a quantidade de informação de uma mensagem?',
        options: [
          { t: 'O tamanho físico do sinal (volume do som, brilho da luz).', fb: 'O meio físico não importa. Uma lamparina fraca e uma forte, se ambas têm só dois estados, carregam a mesma informação.' },
          { t: 'Quanta incerteza ela elimina: quantas possibilidades existiam antes e quantas restam depois.', ok: true, fb: 'Isso. Informação é redução de incerteza.' },
          { t: 'A quantidade de palavras usadas para escrevê-la.', fb: 'Uma frase longa e previsível pode conter menos informação que um único "sim" numa pergunta importante.' },
        ],
        explain: 'Definição de Shannon (1948).',
      },
      {
        type: 'input', id: 'f0-b2',
        q: 'Uma máquina de refrigerante tem 40 produtos diferentes. Quantos bits são necessários, no mínimo, para codificar a escolha do produto?',
        answer: '6',
        hints: ['Menor n com 2ⁿ ≥ 40.', '2⁵ = 32 (pouco). 2⁶ = ?'],
        explain: '2⁵ = 32 < 40 ≤ 64 = 2⁶. São 6 bits, com 24 códigos sobrando.',
      },
      {
        type: 'input', id: 'f0-b3',
        q: 'Com 5 bits, quantas combinações diferentes existem?',
        answer: '32',
        hints: ['2 × 2 × 2 × 2 × 2.', 'Dobre a partir de 16.'],
        explain: '2⁵ = 32. É por isso que 5 bits bastam para as 26 letras do alfabeto.',
      },
      {
        type: 'mc', id: 'f0-b4',
        q: 'Qual afirmação sobre o bit está CORRETA?',
        options: [
          { t: 'Um bit é sempre um 0 ou um 1 gravado fisicamente dentro do computador.', fb: 'O 0 e o 1 são nomes que damos aos estados. Fisicamente há tensões, cargas, magnetização, furos... A convenção é nossa.' },
          { t: 'Um bit é qualquer sistema físico com dois estados distinguíveis, junto com a convenção sobre o que cada estado significa.', ok: true, fb: 'Perfeito. Física + convenção.' },
          { t: 'Um bit é a menor coisa que existe fisicamente num chip.', fb: 'O bit é uma unidade de INFORMAÇÃO, não de matéria. Pode ser realizado por um transistor, por um furo num cartão ou por uma lamparina.' },
        ],
        explain: 'Separar "o que é físico" de "o que é informação" é um dos hábitos mentais mais importantes para quem vai programar.',
      },
      {
        type: 'mc', id: 'f0-b5',
        q: 'Por que colocar os dois estados de um bit "o mais longe possível" (ex.: 0 V e 5 V em vez de 0 V e 0,5 V) é importante?',
        options: [
          { t: 'Porque assim o computador fica mais rápido.', fb: 'Na verdade, tensões maiores costumam deixar o circuito MAIS lento e gastar mais energia. O motivo é outro.' },
          { t: 'Porque assim pequenas perturbações (ruído) não conseguem fazer um estado ser confundido com o outro.', ok: true, fb: 'Correto. Distância entre estados = margem contra ruído.' },
          { t: 'Porque a lógica de Boole exige 5 volts.', fb: 'A lógica de Boole não fala em volts. Ela é abstrata. Os volts são uma escolha de engenharia.' },
        ],
        explain: 'Essa "margem de ruído" é o motivo prático número um para o binário.',
      },
      {
        type: 'explain', id: 'f0-b6',
        q: 'Explique a um amigo por que, com 3 lamparinas, dá para enviar 8 mensagens diferentes e não 6. Use a ideia de "para cada".',
        keywords: [['para cada', 'cada uma', 'cada combinação', 'multiplic'], ['2 × 2 × 2', '2x2x2', '2*2*2', 'dobra', 'dobro'], ['8', 'oito'], ['6', 'seis', 'soma', 'somar']],
        minGroups: 3,
        model: 'A primeira lamparina pode estar de 2 jeitos. Para cada um desses jeitos, a segunda pode estar de 2 jeitos, dando 4 combinações. Para cada uma dessas 4, a terceira pode estar de 2 jeitos, dando 8. As possibilidades se multiplicam (2 × 2 × 2 = 8), não se somam (2 + 2 + 2 = 6). Somar seria o certo se só uma lamparina pudesse estar acesa por vez, mas elas são independentes.',
      },
    ],
  },
  review: [
    { id: 'f0-r1', q: 'O que é informação, segundo Shannon?', a: 'Redução de incerteza: a resolução de uma dúvida entre possibilidades. Onde só existe uma possibilidade, não há informação.' },
    { id: 'f0-r2', q: 'De onde vem a palavra "bit" e o que ela significa?', a: '*Binary digit*, "dígito binário": um algarismo que só pode ter dois valores.' },
    { id: 'f0-r3', q: 'Com n bits, quantas combinações existem? (fórmula)', a: '2ⁿ: dois multiplicado por si mesmo n vezes. Ex.: 8 bits → 256.', answer: ['2^n', '2ⁿ', '2 elevado a n', '2**n'] },
    { id: 'f0-r4', q: 'Quantas combinações existem com 8 bits?', a: '256 (de 0 a 255).', answer: '256' },
    { id: 'f0-r5', q: 'Cite dois motivos de engenharia para computadores serem binários.', a: '(1) Resistência ao ruído: dois estados podem ficar bem afastados. (2) Transistores são simples e confiáveis como interruptores liga/desliga. (3) Os dois valores coincidem com verdadeiro/falso da lógica de Boole.' },
    { id: 'f0-r6', q: 'Quantos bits preciso para distinguir 100 mensagens?', a: '7 bits (2⁶ = 64 é pouco; 2⁷ = 128).', answer: '7' },
  ],
  glossary: [
    { pt: 'bit', en: 'bit (binary digit)', def: 'Menor unidade de informação: uma escolha entre exatamente duas possibilidades (0/1).', origin: 'Contração de "binary digit", sugerida por John Tukey e popularizada por Claude Shannon (1948).' },
    { pt: 'informação', en: 'information', def: 'Redução de incerteza. Mede-se pela quantidade de possibilidades eliminadas.' },
    { pt: 'ruído', en: 'noise', def: 'Perturbação indesejada num sinal físico (calor, interferência) que pode fazer um estado ser confundido com outro.' },
    { pt: 'binário', en: 'binary', def: 'Que tem dois estados ou usa base 2.', origin: 'Do latim *bini*, "dois a dois".' },
    { pt: 'potência de dois', en: 'power of two', def: '2ⁿ = 2 multiplicado por si mesmo n vezes. É o número de combinações de n bits.' },
    { pt: 'transistor', en: 'transistor', def: 'Componente eletrônico que funciona como interruptor controlado eletricamente. Base física dos computadores modernos.', origin: 'De *transfer resistor*, "resistor de transferência" (Bell Labs, 1947).' },
  ],
};
