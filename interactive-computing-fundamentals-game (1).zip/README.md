# BITS: a fundação de tudo — curso jogável

Um jogo de aprendizado, em português do Brasil, sobre a camada mais baixa da computação: do **bit** até a **máquina que executa programas**. 8 fases, 30 seções, 183 exercícios interativos, 8 chefes, revisão espaçada, glossário PT/EN e progresso salvo.

## Como rodar (nunca fiz isso antes)

1. Instale o **Node.js** (LTS) em https://nodejs.org — instalador padrão, "Next, Next, Finish".
2. Abra um terminal (Windows: tecla Windows → digite "PowerShell"; Mac: Cmd+Espaço → "Terminal"; Linux: Ctrl+Alt+T).
3. Entre na pasta do projeto: digite `cd ` (com espaço), arraste a pasta para a janela do terminal e aperte Enter.
4. Digite `npm install` e aperte Enter (espere terminar).
5. Digite `npm run dev` e aperte Enter. Abra no navegador o endereço mostrado (normalmente http://localhost:5173).
6. Para parar: Ctrl+C no terminal.

**Sem terminal depois do primeiro build:** `npm run build` gera `dist/index.html`, um arquivo único que abre direto no navegador (duplo clique).

## Verificação automática do conteúdo

```
npx tsx scripts/verify.ts        # soluções de circuitos, respostas, ids, demos
npx tsx scripts/verify-gen.ts    # 6.300 amostras dos exercícios gerados
npx tsx scripts/verify-render.tsx # renderiza todas as telas
```

## Estrutura

- `src/content/phase0..7.ts` — todo o conteúdo (lições, exercícios, chefes, fichas, glossário)
- `src/components/Demos.tsx` — laboratórios interativos (contador binário, portas, somador, latch, flip-flop, mini-CPU…)
- `src/components/CircuitBuilder.tsx` — construtor de circuitos (mini-HDL) com teste exaustivo
- `src/components/Exercise.tsx` — 7 tipos de exercício com feedback específico e dicas progressivas
- `src/lib/storage.ts` — progresso (localStorage), repetição espaçada (Leitner), dificuldade adaptativa
- Guia completo com método e fontes: botão "Guia, método e fontes" dentro do jogo.
