import type { Progress, GlossaryEntry } from './types';

const STORAGE_KEY = 'a-base-de-tudo-progress-v1';

export function createInitialProgress(): Progress {
  return {
    currentPhaseId: 0,
    currentLessonId: null,
    completedLessons: [],
    completedExercises: {},
    glossary: [],
    phasesUnlocked: [0],
    lastSeenAt: Date.now(),
  };
}

export function loadProgress(): Progress {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createInitialProgress();
    const parsed = JSON.parse(raw);
    // Validar o mínimo
    if (typeof parsed.currentPhaseId !== 'number') return createInitialProgress();
    return {
      ...createInitialProgress(),
      ...parsed,
    };
  } catch {
    return createInitialProgress();
  }
}

export function saveProgress(progress: Progress): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch {
    // Ignora erros de armazenamento (ex: modo privado)
  }
}

export function resetProgress(): Progress {
  const fresh = createInitialProgress();
  saveProgress(fresh);
  return fresh;
}

export function markLessonComplete(progress: Progress, lessonId: string): Progress {
  const completed = progress.completedLessons.includes(lessonId)
    ? progress.completedLessons
    : [...progress.completedLessons, lessonId];
  return { ...progress, completedLessons: completed };
}

export function recordExerciseResult(
  progress: Progress,
  exerciseId: string,
  correct: boolean
): Progress {
  const prev = progress.completedExercises[exerciseId];
  const result = {
    exerciseId,
    attempts: (prev?.attempts ?? 0) + 1,
    correct: prev?.correct || correct,
    lastAttemptAt: Date.now(),
  };
  return {
    ...progress,
    completedExercises: {
      ...progress.completedExercises,
      [exerciseId]: result,
    },
  };
}

export function unlockPhase(progress: Progress, phaseId: number): Progress {
  if (progress.phasesUnlocked.includes(phaseId)) return progress;
  return {
    ...progress,
    phasesUnlocked: [...progress.phasesUnlocked, phaseId].sort((a, b) => a - b),
  };
}

export function addGlossaryTerms(
  progress: Progress,
  terms: GlossaryEntry[]
): Progress {
  if (!terms || terms.length === 0) return progress;
  const existing = new Set(progress.glossary.map((g) => g.term.toLowerCase()));
  const novos = terms.filter((t) => !existing.has(t.term.toLowerCase()));
  if (novos.length === 0) return progress;
  return {
    ...progress,
    glossary: [...progress.glossary, ...novos],
  };
}
