import type { Phase, GlossaryEntry } from './types';

// ============================================================
// GLOSSÁRIO GLOBAL (termos que vão sendo adicionados por fase)
// ============================================================

// ============================================================
// FASE 0: A Descoberta
// ============================================================
const fase0: Phase = {
  id: 0,
  title: 'A Descoberta',
  subtitle: 'A ideia mais importante da história da computação',
  description: 'Antes de qualquer código, antes de qualquer chip, existe uma única ideia. Aqui você vai descobrir qual é essa ideia, por que ela é a base de TUDO, e por que ela tem exatamente dois estados.',
  icon: '💡',
  color: 'amber',
  lessons: [
    {
      id: '0-1',
      title: 'Boas-vindas: você vai construir as fundações',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Olá! Seja muito bem-vindo ou bem-vinda.',
            "Este não é um curso como os outros. Aqui, nós não vamos começar com 'print(\"Olá, mundo!\")'. Nós vamos começar pelo fundamento absoluto de tudo o que chamamos de computação, programação, software, hardware, internet, inteligência artificial — absolutamente tudo.",
            'Quando você terminar, você não vai saber programar em Python ou JavaScript ainda. Mas você vai entender a rocha sobre a qual todas essas linguagens e tecnologias estão construídas. E quando você chegar a essas linguagens, elas vão fazer muito mais sentido, porque você vai saber o que está acontecendo por baixo dos panos.',
            'Aqui está a promessa que eu te faço: se você acompanhar cada lição, fizer cada exercício, e não pular para a próxima fase antes de dominar a atual, no final você terá um entendimento que 90% dos programadores profissionais não têm, porque quase ninguém mais volta até a raiz.',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'tip',
          title: 'Como este curso funciona',
          text: 'Você só avança quando demonstra que entendeu. Existem exercícios ao longo de cada lição. Se errar, eu explico por quê e dou dicas. Seu progresso fica salvo automaticamente mesmo se fechar a página. No final de cada fase, há um "chefe" que testa se você dominou tudo. Não pule fases — o curso é construído em camadas como uma casa.',
        },
      ],
    },
    {
      id: '0-2',
      title: 'Antes de tudo: o que é um computador, realmente?',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Pare por um segundo e responda para você mesmo(a): o que um computador faz?',
            'A maioria das pessoas pensa em "coisas complicadas": editar vídeo, rodar jogos, acessar a internet, fazer planilhas, gerar texto com IA.',
            'Mas a verdade é muito mais simples: um computador é uma máquina que pega informação e a transforma de acordo com regras. Isso é tudo.',
            'Agora, a próxima pergunta é: como você constrói uma máquina dessas? Mais especificamente: qual é a maneira MAIS SIMPLES possível de representar informação, para que a máquina seja fácil de construir e de não quebrar?',
            'A resposta é: use apenas dois estados.',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'curiosity',
          title: 'Por que não 3? Por que não 10?',
          text: 'Sinais analógicos (como o volume de um rádio, que pode estar em qualquer posição) são imprecisos. Se você tem 10 estados, um pouco de ruído elétrico faz o valor 5 virar 4 ou 6 e dar erro. Com apenas DOIS estados, ou é uma coisa ou é outra. Ou tem corrente ou não tem. Ou o interruptor está ligado ou desligado. É extremamente confiável, e extremamente simples de fabricar.',
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-0-1',
            type: 'multiple-choice',
            prompt: 'Por que computadores usam apenas dois estados (e não 10, ou 3, ou infinitos)?',
            options: [
              'Porque George Boole era um matemático de dois valores.',
              'Porque dois estados são fisicamente mais simples de representar de forma confiável.',
              'Porque os matemáticos do século 19 não sabiam contar até 10.',
              'Porque os primeiros computadores só conseguiram fazer dois estados por acidente, e a tradição continuou.',
            ],
            correctIndex: 1,
            feedbackIncorreto: [
              'Boole criou a matemática, mas a razão de usar dois estados é FÍSICA, não matemática.',
              undefined,
              'Nem pense nisso — Boole sabia contar perfeitamente.',
              'Não foi acidente. Foi uma escolha consciente baseada em confiabilidade, e Shannon provou em 1937 que era a abordagem correta.',
            ],
          },
        },
      ],
      newGlossaryTerms: [
        {
          term: 'Bit',
          termEn: 'Bit (Binary digIT)',
          definition: 'A menor unidade de informação possível. Representa apenas UM de dois valores: 0 ou 1, ligado ou desligado, verdadeiro ou falso. A palavra "bit" vem da contração de "binary digit" (dígito binário).',
        },
      ],
    },
    {
      id: '0-3',
      title: 'Dois valores: como chamá-los?',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Se temos dois estados, precisamos de nomes para eles. Ao longo deste curso e da sua jornada em computação, você verá esses dois estados serem chamados por nomes diferentes, mas eles sempre se referem à MESMA coisa:',
          ],
        },
        {
          kind: 'reveal',
          title: 'Os dois estados e todos os seus nomes',
          texts: [
            '0 / 1',
            'Desligado / Ligado',
            'Falso / Verdadeiro',
            'False / True',
            'Baixo / Alto (em tensão elétrica: ~0V / ~5V ou ~3.3V ou ~1.1V em chips modernos)',
            'Não / Sim',
            'OFF / ON',
            'Todos esses pares representam a mesma ideia: um bit que pode assumir exatamente um de dois valores possíveis.',
          ],
        },
        {
          kind: 'narrative',
          texts: [
            'Agora, a pergunta que realmente importa: será que apenas dois estados são suficientes para representar QUALQUER informação? Para fazer QUALQUER cálculo? Para escrever QUALQUER programa?',
            'A resposta é SIM. E a prova disso é que você está lendo este texto em um computador, que não faz nada além de manipular bilhões de bits. Mas COMO isso é possível? Essa é a pergunta que este curso responde.',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-0-2',
            type: 'multiple-choice',
            prompt: 'Um bit é...',
            options: [
              'Um arquivo pequeno do Windows.',
              'A menor unidade de informação, que guarda um entre dois valores possíveis.',
              'Um tipo de transistor usado em processadores modernos.',
              'O número 1 escrito em código binário.',
            ],
            correctIndex: 1,
            feedbackIncorreto: [
              'Isso é um ".bat"? Não. "Bit" não tem relação com o Windows.',
              undefined,
              'Não, um bit é informação. Um transistor é o hardware que IMPLEMENTA um bit.',
              'Não exatamente. Um bit pode ser 0 ou 1, não apenas 1.',
            ],
          },
        },
      ],
      newGlossaryTerms: [
        {
          term: 'Dígito Binário',
          termEn: 'Binary Digit',
          definition: 'O nome oficial do 0 ou do 1 em um número binário. "Bit" é a abreviação.',
        },
      ],
    },
    {
      id: '0-4',
      title: 'A história: Boole e Shannon, dois homens separados por 90 anos',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Em 1854, um matemático inglês autodidata chamado George Boole (1815-1864) publicou um livro chamado "Uma Investigação sobre as Leis do Pensamento". Nesse livro, ele descreveu um sistema matemático que funciona com apenas DOIS valores — verdadeiro e falso — e três operações básicas: AND, OR e NOT.',
            'Na época, isso era apenas matemática abstrata e lógica filosófica. Ninguém imaginava que isso seria útil para construir máquinas. O trabalho de Boole ficou em livros de filosofia por quase um século.',
          ],
        },
        {
          kind: 'quote',
          title: 'A tese que mudou o mundo',
          text: 'Em 1937, um estudante de mestrado de 21 anos do MIT chamado Claude Shannon escreveu uma tese de 81 páginas. Nela, ele mostrou que a álgebra de Boole era EXATAMENTE o que você precisava para descrever circuitos elétricos feitos de interruptores (relés, na época).\n\nCada interruptor era um bit: ligado = verdadeiro, desligado = falso. Colocando interruptores em série, você fazia a operação AND. Em paralelo, OR. Com um inversor, NOT.\n\nEssa tese é considerada uma das mais importantes da história da computação. Ela é a ponte entre a matemática e o hardware.',
        },
        {
          kind: 'narrative',
          texts: [
            'O resto é história. Dos relés passamos para os transistores (inventados em 1947), dos transistores para os circuitos integrados, e destes para os microprocessadores com bilhões de transistores. Mas em cada nível, a base ainda é a mesma: Álgebra Booleana implementada fisicamente.',
            'Você vai aprender exatamente o que Shannon descobriu. E vai entender por que esse conhecimento é a base de tudo.',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'warning',
          title: 'Uma nota sobre simplificação',
          text: 'A história real é mais complexa (houveram outros contribuidores, como Gottfried Leibniz no século 17, Charles Babbage, Augustus De Morgan, etc.). Mas para este curso, o núcleo essencial é Boole (a matemática) e Shannon (a conexão com hardware).',
        },
      ],
      newGlossaryTerms: [
        {
          term: 'Álgebra Booleana',
          termEn: 'Boolean Algebra',
          definition: 'Um sistema matemático que lida com dois valores (0/1 ou verdadeiro/falso) e operações sobre eles (NOT, AND, OR etc.). Nomeada em homenagem a George Boole.',
        },
        {
          term: 'Transistor',
          termEn: 'Transistor',
          definition: 'Um componente eletrônico minúsculo que funciona como um interruptor controlado por eletricidade. Pode estar ligado ou desligado. Os processadores modernos têm bilhões de transistores em um chip de poucos centímetros.',
        },
      ],
    },
    {
      id: '0-5',
      title: 'Chefe da Fase 0: verificando se a base está sólida',
      blocks: [
        {
          kind: 'boss-intro',
          title: '⚔️ CHEFE DA FASE 0',
          text: 'Antes de avançarmos para a Fase 1 (onde vamos aprender a contar usando apenas dois dígitos), você precisa provar que entendeu a ideia central desta fase. Se errar, não tem problema — eu explico e você pode tentar de novo.',
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-0-1',
            type: 'multiple-choice',
            prompt: 'Qual é a afirmação MAIS CORRETA sobre o que é a base de toda a computação?',
            options: [
              'A base é a linguagem de programação Python, que é a mais usada no mundo.',
              'A base é o microprocessador Intel ou AMD dentro do computador.',
              'A base é a ideia que informação pode ser representada com exatamente dois estados, e que podemos transformar essa informação usando regras da lógica booleana implementadas fisicamente.',
              'A base é a eletricidade, porque sem eletricidade o computador não liga.',
            ],
            correctIndex: 2,
            feedbackIncorreto: [
              'Python é uma ferramenta MUITO acima da base. Foi construída sobre outras camadas, que por sua vez foram construídas sobre a lógica booleana.',
              'O microprocessador é a IMPLEMENTAÇÃO física da base, mas não é a base em si. A base é o princípio que o microprocessador executa.',
              undefined,
              'A eletricidade é o meio físico, como a água é o meio de um rio. Mas a informação e as regras de transformação dela são o que realmente importa; a eletricidade poderia ser substituída por engrenagens mecânicas (e foi, no começo).',
            ],
            explanation: 'Perfeito! Você entendeu. Dois estados + regras da lógica booleana + implementação física = a base de TUDO. O resto são camadas em cima.',
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-0-2',
            type: 'free-response',
            prompt: 'Explique com suas próprias palavras: por que dois estados são a escolha mais inteligente para construir uma máquina de calcular? (Não se preocupe com a escrita; eu vou procurar pelas ideias.)',
            keywords: ['confi', 'simples', 'estados', 'dois', 'interrupt', 'ruído', 'erro', 'ligado', 'deslig', 'fisic'],
            minWords: 15,
            sampleAnswer: 'Dois estados são mais confiáveis porque é fácil de distinguir entre ligado e desligado fisicamente. Qualquer pequeno ruído não atrapalha, e interruptores ou transistores podem ser feitos muito pequenos. Com mais estados, fica mais fácil de dar erro.',
          },
        },
        {
          kind: 'phase-complete',
          title: '🎉 Fase 0 concluída!',
          text: 'Você entendeu a ideia central. Agora vamos para a Fase 1, onde você vai aprender a representar NÚMEROS usando apenas 0s e 1s. Isso é essencial porque computadores não armazenam só "sim/não" — eles armazenam números, texto, imagens, e tudo mais. Tudo começa com como escrever números em binário.',
        },
      ],
    },
  ],
};

// ============================================================
// FASE 1: Bits e Números Binários
// ============================================================
const fase1: Phase = {
  id: 1,
  title: 'Números Binários',
  subtitle: 'Contar com apenas dois dedos',
  description: 'Você está acostumado(a) a contar com dez dígitos (0 a 9). Os computadores contam com apenas dois. Vamos aprender como isso funciona, por que é assim, e como converter entre "nosso jeito" e o "jeito do computador".',
  icon: '🔢',
  color: 'blue',
  lessons: [
    {
      id: '1-1',
      title: 'Como você conta? O sistema decimal',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Você já parou para pensar em como funciona o jeito que escrevemos números?',
            'Usamos dez símbolos diferentes: 0, 1, 2, 3, 4, 5, 6, 7, 8 e 9. Por causa desses dez símbolos, chamamos nosso sistema de decimal (de "decem", que é dez em latim).',
            'Quando queremos escrever um número maior que 9, nós fazemos um truque: usamos mais de um dígito. Cada posição tem um peso diferente.',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'curiosity',
          title: 'Lembre-se da escola: as casas',
          text: 'Quando você era criança, aprendeu "casa das unidades, casa das dezenas, casa das centenas". Pois é. Isso é exatamente o valor posicional. Na direita: unidades (10⁰ = 1). Uma casa para a esquerda: dezenas (10¹ = 10). Depois centenas (10² = 100). Depois milhares (10³ = 1000), e assim por diante.',
        },
        {
          kind: 'narrative',
          texts: [
            'Por exemplo, o número 237 é: 2 centenas + 3 dezenas + 7 unidades. Ou seja: 2 × 100 + 3 × 10 + 7 × 1 = 200 + 30 + 7 = 237.',
            'Até aqui nada novo, certo? Você já fazia isso desde os 7 anos de idade.',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-1-1',
            type: 'multiple-choice',
            prompt: 'No número 482, o que o dígito 8 representa?',
            options: ['8 unidades', '8 dezenas (ou seja, 80)', '8 centenas (ou seja, 800)', '8 milhares'],
            correctIndex: 1,
            feedbackIncorreto: [
              'Unidades é a casa da direita. O 2 está ali.',
              undefined,
              'Centenas é a casa da esquerda; ali está o 4.',
              'Não tem casa de milhar nesse número, ele só tem 3 dígitos.',
            ],
          },
        },
      ],
      newGlossaryTerms: [
        {
          term: 'Sistema Decimal',
          termEn: 'Decimal System',
          definition: 'Sistema de numeração na base 10, que usa 10 símbolos (0-9) e valores posicionais que são potências de 10. O usamos porque temos 10 dedos nas mãos.',
        },
        {
          term: 'Valor Posicional',
          termEn: 'Positional Notation',
          definition: 'Regra onde cada dígito tem um valor que depende da sua posição no número. A mesma posição na esquerda vale a base (10 no decimal, 2 no binário) vezes mais que a posição à direita.',
        },
      ],
    },
    {
      id: '1-2',
      title: 'O mesmo truque, mas com base 2',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'O sistema binário usa EXATAMENTE o mesmo princípio do decimal, mas com uma única diferença: em vez de 10 símbolos, temos apenas 2: 0 e 1.',
            'Isso significa que as "casas" (as posições dos dígitos) não são mais potências de 10, mas sim potências de 2.',
            'Em vez de 1, 10, 100, 1000... temos: 1, 2, 4, 8, 16, 32, 64, 128... e assim por diante.',
          ],
        },
        {
          kind: 'reveal',
          title: 'As casas do binário (da direita para a esquerda)',
          texts: [
            'Casa 0 (direita): 2⁰ = 1 (unidades)',
            'Casa 1: 2¹ = 2',
            'Casa 2: 2² = 4',
            'Casa 3: 2³ = 8',
            'Casa 4: 2⁴ = 16',
            'Casa 5: 2⁵ = 32',
            'Casa 6: 2⁶ = 64',
            'Casa 7: 2⁷ = 128',
            'Cada casa vale o DOBRO da anterior, em vez de 10 vezes mais.',
          ],
        },
        {
          kind: 'narrative',
          texts: [
            'Para ler um número binário, você faz exatamente como no decimal: olha cada posição, vê se o dígito é 1 ou 0. Se for 1, você soma o valor daquela casa; se for 0, não soma nada.',
            'Vamos pegar o número binário 101. Temos 3 casas. Da direita para a esquerda: casa 0 (1), casa 1 (2), casa 2 (4). O dígito na casa 0 é 1 (vale 1), na casa 1 é 0 (vale 0), na casa 2 é 1 (vale 4). Somando tudo: 1 + 0 + 4 = 5. Então 101 em binário é 5 em decimal.',
            'Vamos ver outro: 110. Casa 0: 0 (não soma nada). Casa 1: 1 (soma 2). Casa 2: 1 (soma 4). Total: 6. 110 em binário é 6 em decimal.',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'tip',
          title: 'Regra prática: binário para decimal',
          text: '1. Escreva os pesos (1, 2, 4, 8, 16...) em cima de cada dígito, da DIREITA para a esquerda. 2. Onde tiver 1, pegue o peso; onde tiver 0, ignore. 3. Some os pesos que você pegou. Esse é o número em decimal.',
        },
      ],
      newGlossaryTerms: [
        {
          term: 'Sistema Binário',
          termEn: 'Binary System',
          definition: 'Sistema de numeração na base 2 que usa apenas dois dígitos (0 e 1). Tudo dentro de um computador é representado em binário.',
        },
        {
          term: 'Base',
          termEn: 'Base (radix)',
          definition: 'O número de símbolos diferentes que um sistema de numeração usa. Decimal usa base 10; binário usa base 2. A base determina quanto vale cada posição (potências da base).',
        },
      ],
    },
    {
      id: '1-3',
      title: 'Praticando a leitura: mãos à obra',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Vamos praticar. Não adianta ler passivamente — você precisa fazer você mesmo(a).',
            'Lembre-se: pesos da direita para esquerda são 1, 2, 4, 8, 16...',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-1-2',
            type: 'multiple-choice',
            prompt: 'Quanto vale o número binário 10 em decimal?',
            options: ['1', '2', '10', '3'],
            correctIndex: 1,
            feedbackIncorreto: [
              'Você olhou só a casa da direita? O 1 está na casa da esquerda, que vale 2.',
              undefined,
              '"10" no decimal é dez, mas "10" no binário é dois! Tome MUITO cuidado — você verá "10" muito em contextos onde ele é lido como "um zero binário", não como "dez".',
              '11 em binário que vale 3. Aqui temos um 0 na casa do 1, então é só o valor da casa do 2: 2.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-1-3',
            type: 'multiple-choice',
            prompt: 'Quanto vale o número binário 111 em decimal?',
            options: ['3', '7', '15', '111'],
            correctIndex: 1,
            feedbackIncorreto: [
              '3 é 11 em binário (casas 1 e 2: 2 + 1 = 3). Você se esqueceu de uma casa.',
              undefined,
              '15 é 1111 em binário (8 + 4 + 2 + 1).',
              '111 em decimal é cento e onze, mas em binário os dígitos não são pesos de 100/10/1 e sim de 4/2/1.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-1-4',
            type: 'multiple-choice',
            prompt: 'Quanto vale o número binário 1000 em decimal?',
            options: ['1000', '8', '4', '16'],
            correctIndex: 1,
            feedbackIncorreto: [
              'Isso é mil em decimal. Lembre-se: no binário, as casas não são 1, 10, 100, 1000... São 1, 2, 4, 8.',
              undefined,
              '4 é 100 (apenas três dígitos). 1000 tem quatro dígitos, então a casa mais à esquerda é 8.',
              '16 é 10000 (cinco dígitos). Conte os dígitos: 1000 tem quatro, então 2³ = 8.',
            ],
          },
        },
      ],
    },
    {
      id: '1-4',
      title: 'Contando em binário',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Quando você conta em decimal, depois do 9 você não tem mais um símbolo, então "carrega o 1": o dígito da direita volta para 0 e você cria um novo dígito 1 na esquerda, formando 10.',
            'Em binário, é exatamente a mesma ideia, mas isso acontece depois de 1 (porque só temos 0 e 1).',
          ],
        },
        {
          kind: 'reveal',
          title: 'Contando de 0 a 15 em binário',
          texts: [
            '0 em decimal = 0 em binário',
            '1 = 1',
            '2 = 10  (o 1 "acabou", então carrega: vira 0 e ganha 1 na esquerda)',
            '3 = 11',
            '4 = 100 (o 11 acabou, carrega tudo! 11 → 00 + novo 1 na esquerda = 100)',
            '5 = 101',
            '6 = 110',
            '7 = 111',
            '8 = 1000',
            '9 = 1001',
            '10 = 1010',
            '11 = 1011',
            '12 = 1100',
            '13 = 1101',
            '14 = 1110',
            '15 = 1111',
          ],
        },
        {
          kind: 'narrative',
          texts: [
            'Observe um padrão importante: com N bits (N dígitos binários), você consegue representar quantos números diferentes?',
            'Com 1 bit: 0, 1 → 2 números (de 0 a 1).',
            'Com 2 bits: 0, 1, 2, 3 → 4 números (de 0 a 3).',
            'Com 3 bits: 0 a 7 → 8 números.',
            'Com 4 bits: 0 a 15 → 16 números.',
            'Com 8 bits (um byte): 0 a 255 → 256 números.',
            'Com N bits: 2ᴺ números diferentes, de 0 até 2ᴺ - 1.',
          ],
        },
        {
          kind: 'exercise',
            exercise: {
            id: 'ex-1-5',
            type: 'multiple-choice',
            prompt: 'Com 8 bits (um byte), quantos valores diferentes podemos representar?',
            options: ['8', '64', '256', '16'],
            correctIndex: 2,
            feedbackIncorreto: [
              '8 é o número de bits, não o de valores possíveis.',
              '64 é 2⁶. Você usou o expoente errado.',
              undefined,
              '16 é 2⁴ (4 bits). 8 bits é 2⁸ = 256.',
            ],
            explanation: '2 elevado a 8 dá 256. Por isso um byte representa de 0 a 255.',
          },
        },
      ],
      newGlossaryTerms: [
        {
          term: 'Byte',
          termEn: 'Byte',
          definition: 'Um grupo de 8 bits. Pode representar números de 0 a 255. É a unidade que usamos para medir tamanho de arquivos, memória etc. (1 KB = 1024 bytes, 1 MB = 1024 KB etc.)',
        },
      ],
    },
    {
      id: '1-5',
      title: 'Convertendo para binário (decimal → binário)',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Agora vamos ao caminho inverso: dado um número em decimal, como escrevê-lo em binário?',
            'Há várias maneiras, mas a mais simples para iniciantes é a seguinte: comece pelo maior peso (potência de 2) que é menor ou igual ao número. Se o número for maior ou igual ao peso, você coloca 1 e subtrai o peso do número. Se for menor, coloca 0 e não subtrai nada. Depois vá para o próximo peso menor, até chegar em 1.',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'tip',
          title: 'Exemplo: converter 13 para binário',
          text: 'Pesos de referência: 8, 4, 2, 1.\n- O maior peso ≤ 13 é 8. 13 ≥ 8? SIM. Coloque 1 e subtraia: 13 - 8 = 5.\n- Próximo peso: 4. 5 ≥ 4? SIM. Coloque 1. 5 - 4 = 1.\n- Próximo peso: 2. 1 ≥ 2? NÃO. Coloque 0. Não subtrai.\n- Próximo peso: 1. 1 ≥ 1? SIM. Coloque 1. 1 - 1 = 0.\nLendo os dígitos de cima para baixo: 1 1 0 1. Então 13 em binário é 1101. Confere: 8+4+1 = 13. ✓',
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-1-6',
            type: 'multiple-choice',
            prompt: 'Converta o número 6 para binário. (Pesos disponíveis: 4, 2, 1)',
            options: ['101', '110', '011', '111'],
            correctIndex: 1,
            feedbackIncorreto: [
              '101 é 4 + 0 + 1 = 5. Você errou.',
              undefined,
              '011 é 0 + 2 + 1 = 3. Verifique as casas.',
              '111 é 4+2+1 = 7, que é um a mais que 6.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-1-7',
            type: 'multiple-choice',
            prompt: 'Converta o número 9 para binário. (Pesos: 8, 4, 2, 1)',
            options: ['1001', '1010', '0111', '1100'],
            correctIndex: 0,
            feedbackIncorreto: [
              undefined,
              '1010 é 8+2 = 10. Você colocou 1 na casa do 2, não na da unidade.',
              '0111 é 4+2+1 = 7. Você está começando no peso errado? 9 é ≥ 8, então deve começar com 1 na casa do 8.',
              '1100 é 8+4 = 12.',
            ],
          },
        },
      ],
    },
    {
      id: '1-6',
      title: 'Por que isso importa? Representando mais que números',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Você pode estar pensando: "Tá, eu sei contar em binário. E daí? Eu só queria programar."',
            'Aí é que está: absolutamente TUDO dentro de um computador é uma sequência de bits. Números são só o começo.',
          ],
        },
        {
          kind: 'reveal',
          title: 'Como qualquer informação vira bits',
          texts: [
            'Números: você acabou de aprender (binário).',
            'Texto: cada letra recebe um código numérico (ex: A=65, B=66, C=67...), e esse número vai para binário.',
            'Imagens: cada pixel tem valores de vermelho/verde/azul (de 0 a 255 para cada cor), cada um vira 8 bits.',
            'Sons: a onda sonora é medida milhares de vezes por segundo; cada medição vira um número binário.',
            'Programas (código): cada instrução é um número binário; a CPU interpreta esse número como um comando.',
            'Tudo é número, todo número é bit, então tudo é bits.',
          ],
        },
        {
          kind: 'narrative',
          texts: [
            'Neste curso, nosso foco não é em como representar texto ou imagens. Vamos focar em uma pergunta mais fundamental: depois que temos os bits, como podemos CALCULAR com eles? Como fazer operações, transformar informação, tomar decisões?',
            'Isso nos leva de volta para a álgebra booleana, que é a matemática de manipular bits. É isso que vamos começar na próxima fase.',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-1-8',
            type: 'multiple-choice',
            prompt: 'Verdadeiro ou falso: "Letras, imagens e músicas são fundamentalmente diferentes de números dentro do computador."',
            options: [
              'Verdadeiro — o computador guarda cada tipo de dado em formatos completamente diferentes.',
              'Falso — tudo é representado como números binários; o que muda é apenas como interpretamos esses números.',
              'Verdadeiro — números são da CPU, texto é da memória RAM, e imagens são da placa de vídeo.',
            ],
            correctIndex: 1,
            feedbackIncorreto: [
              'Não! Todos são bits na memória. O que faz uma sequência de bits ser uma letra ou uma cor é a CONVENÇÃO de como a interpretamos.',
              undefined,
              'Errado. Tudo é um amontoado de 0s e 1s. O hardware não sabe "o que" aquilo representa; ele só manipula os bits.',
            ],
          },
        },
      ],
    },
    {
      id: '1-7',
      title: '⚔️ Chefe da Fase 1',
      blocks: [
        {
          kind: 'boss-intro',
          title: '⚔️ CHEFE DA FASE 1',
          text: 'Antes de avançar para a matemática da lógica, você precisa dominar a conversão binário ↔ decimal e o conceito de valor posicional. Vamos lá!',
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-1-1',
            type: 'multiple-choice',
            prompt: 'Quanto vale o número binário 1010 em decimal?',
            options: ['10', '8', '12', '1010'],
            correctIndex: 0,
            feedbackIncorreto: [
              undefined,
              '8 é 1000, mas você se esqueceu do 1 na segunda casa (que vale 2).',
              '12 é 1100.',
              'Isso é mil e dez em decimal, mas no binário os pesos são potências de 2, não de 10.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-1-2',
            type: 'multiple-choice',
            prompt: 'Qual é a representação binária do número 25? (Dica: 16, 8, 4, 2, 1)',
            options: ['11001', '10101', '11100', '10011'],
            correctIndex: 0,
            feedbackIncorreto: [
              undefined,
              '10101 é 16+4+1 = 21. Verifique as casas.',
              '11100 é 16+8+4 = 28.',
              '10011 é 16+2+1 = 19.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-1-3',
            type: 'free-response',
            prompt: 'Explique com suas palavras como o sistema binário é igual e como ele é diferente do sistema decimal. Seja específico sobre o princípio de valor posicional.',
            keywords: ['posiç', 'peso', 'dois', 'dez', 'base', '2', '10', 'dígito', '0', '1', 'casa'],
            minWords: 25,
            sampleAnswer: 'Os dois sistemas usam valor posicional, onde cada casa vale a base elevada a uma potência. O decimal usa base 10 (dez símbolos, pesos 1, 10, 100...) e o binário usa base 2 (dois símbolos, pesos 1, 2, 4, 8...). A mecânica de "carregar o 1" quando acaba os símbolos é a mesma nos dois.',
          },
        },
        {
          kind: 'phase-complete',
          title: '🎉 Fase 1 concluída!',
          text: 'Você já sabe representar números em binário e entende por que essa é a linguagem que o hardware entende. Agora vamos para a parte realmente emocionante: a matemática que permite aos computadores CALCULAR com esses bits — a Álgebra Booleana.',
        },
      ],
    },
  ],
};

// ============================================================
// FASE 2: Álgebra Booleana
// ============================================================
const fase2: Phase = {
  id: 2,
  title: 'Álgebra Booleana',
  subtitle: 'A matemática de verdadeiro e falso',
  description: 'George Boole criou uma matemática inteira que lida apenas com dois valores: 0 e 1, verdadeiro e falso. Nesta fase você vai aprender as três operações fundamentais (NOT, AND, OR), suas tabelas-verdade, e como combinar expressões.',
  icon: '➕',
  color: 'emerald',
  lessons: [
    {
      id: '2-1',
      title: 'Uma matemática diferente',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Na matemática que você aprendeu na escola, as variáveis (x, y, z) podem assumir qualquer número, e as operações são soma, subtração, multiplicação, divisão, etc.',
            'Na álgebra booleana, tudo é mais simples (e mais estranho no começo): uma variável pode ter apenas UM de DOIS valores: 0 ou 1 (falso ou verdadeiro). E existem apenas TRÊS operações básicas: NOT, AND e OR.',
            'Pode parecer limitante, mas daqui a algumas fases você verá que essas três operações são suficientes para fazer QUALQUER cálculo, inclusive os de uma calculadora ou de um processador.',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'simplification',
          title: 'Simplificação proposital',
          text: 'Vamos usar 0 e 1 ao invés de "falso" e "verdadeiro", porque é o que o hardware usa e o que vamos usar para fazer contas depois. Os dois pares são intercambiáveis nesta fase.',
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-2-1',
            type: 'multiple-choice',
            prompt: 'Na álgebra booleana, uma variável pode assumir quantos valores diferentes?',
            options: [
              'Infinitos, como na álgebra normal.',
              'Apenas 2 (0 ou 1).',
              'Dez, como os dígitos decimais.',
              'Depende do tamanho da memória.',
            ],
            correctIndex: 1,
            feedbackIncorreto: [
              'Essa é a álgebra "normal". Booleana é bem mais restrita.',
              undefined,
              'Não — a álgebra booleana não tem relação direta com a contagem decimal nesse sentido.',
              'Isso é sobre hardware, não sobre a matemática em si.',
            ],
          },
        },
      ],
    },
    {
      id: '2-2',
      title: 'NOT: a operação mais simples de todas',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'NOT é a operação que INVERTE o valor. É como o "não" da língua portuguesa.',
            'Se a entrada for 0, NOT 0 = 1. Se a entrada for 1, NOT 1 = 0.',
            'Só tem uma entrada. Não há surpresas aqui.',
          ],
        },
        {
          kind: 'reveal',
          title: 'Tabela-verdade do NOT',
          texts: [
            'Uma tabela-verdade lista TODAS as combinações possíveis de entrada e a saída correspondente. Para o NOT, que só tem 1 entrada e 2 combinações, ela é pequena:',
            '',
            'Entrada (A) | Saída (NOT A)',
            '0           | 1',
            '1           | 0',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'curiosity',
          title: 'Outras notações para NOT',
          text: 'Em diferentes contextos você verá NOT ser escrito como: ¬A, !A, Ā (A com uma barra em cima), /A, ou ~A. Todas significam a mesma coisa: "o inverso de A". Neste curso vamos usar NOT A ou !A quando precisar de notação compacta.',
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-2-2',
            type: 'multiple-choice',
            prompt: 'Quanto é NOT 0?',
            options: ['0', '1', '10', 'Depende do contexto.'],
            correctIndex: 1,
            feedbackIncorreto: [
              '0 invertido? Oposto de 0 é 1.',
              undefined,
              'Não, isso é dois em binário! NOT é uma operação booleana de um único bit.',
              'Não — o NOT é sempre determinístico; não depende de nada. 0 sempre vira 1.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-2-3',
            type: 'multiple-choice',
            prompt: 'Quanto é NOT 1?',
            options: ['0', '1', '-1', 'Nenhuma das anteriores.'],
            correctIndex: 0,
            feedbackIncorreto: [
              undefined,
              '1 invertido é o oposto, não ele mesmo.',
              '-1? Booleanos não são números inteiros, não tem negativo. Apenas 0 e 1.',
              'Tem sim uma resposta correta: é 0.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-2-4',
            type: 'multiple-choice',
            prompt: 'Quanto é NOT (NOT 1)?',
            options: ['0', '1', '2', 'Não existe essa operação.'],
            correctIndex: 1,
            feedbackIncorreto: [
              'Primeiro calculamos o NOT de dentro: NOT 1 = 0. Depois NOT 0 = 1. Dá duas inversões, volta ao original.',
              undefined,
              'Não! Você não pode ter 2 em booleano.',
              'Você pode aplicar NOT quantas vezes quiser, é um efeito de "liga/desliga".',
            ],
            explanation: 'Duas negações se cancelam, como na vida real: "não não quero" = "quero".',
          },
        },
      ],
      newGlossaryTerms: [
        {
          term: 'NOT',
          termEn: 'NOT (inverter, negation)',
          definition: 'Operação booleana de uma entrada que inverte o valor: 0 vira 1, 1 vira 0. Também chamada de inversão ou negação.',
        },
        {
          term: 'Tabela-Verdade',
          termEn: 'Truth Table',
          definition: 'Uma tabela que lista todas as combinações possíveis de entradas e mostra a saída correspondente para uma operação ou circuito.',
        },
      ],
    },
    {
      id: '2-3',
      title: 'AND: as duas coisas precisam ser verdade',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'A operação AND recebe DUAS entradas e devolve 1 SOMENTE SE as duas entradas forem 1. Se qualquer uma delas for 0, a saída é 0.',
            'É como o "e" da língua portuguesa. "Eu vou sair SE fizer sol E eu tiver dinheiro" — só acontece se as duas condições forem verdadeiras.',
            'Fisicamente, no mundo dos interruptores, um AND corresponde a dois interruptores ligados EM SÉRIE (um depois do outro). A corrente só passa se AMBOS estiverem ligados.',
          ],
        },
        {
          kind: 'reveal',
          title: 'Tabela-verdade do AND',
          texts: [
            'Agora temos duas entradas (A e B), então 4 combinações possíveis:',
            '',
            'A | B | A AND B',
            '0 | 0 | 0',
            '0 | 1 | 0',
            '1 | 0 | 0',
            '1 | 1 | 1',
            '',
            'Note que só a última linha (ambas 1) dá saída 1. Todas as outras dão 0.',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'tip',
          title: 'Regra de bolso do AND',
          text: 'AND é 1 só quando TODAS as entradas são 1. Se houver um único 0, já era: saída 0. Se você tivesse 3 entradas (A AND B AND C), a saída seria 1 só com A=1, B=1, C=1.',
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-2-5',
            type: 'multiple-choice',
            prompt: 'Quanto é 1 AND 1?',
            options: ['0', '1', '2', '11'],
            correctIndex: 1,
            feedbackIncorreto: [
              'AND só dá 0 se alguma entrada for 0. Ambas são 1.',
              undefined,
              'Não! Não é soma. É operação booleana, não adição.',
              'Isso é uma concatenação de bits, não o resultado de um AND.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-2-6',
            type: 'multiple-choice',
            prompt: 'Quanto é 1 AND 0?',
            options: ['0', '1', 'Depende da ordem.', '10'],
            correctIndex: 0,
            feedbackIncorreto: [
              undefined,
              'AND precisa que AMBAS sejam 1. Uma é 0, então a saída é 0.',
              'AND é comutativo (a ordem não importa). 1 AND 0 = 0 AND 1 = 0, exatamente como a multiplicação.',
              'Não é a junção dos bits; é uma operação lógica.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-2-7',
            type: 'multiple-choice',
            prompt: 'Quanto é 0 AND 0?',
            options: ['0', '1', '00', '-1'],
            correctIndex: 0,
            feedbackIncorreto: [
              undefined,
              '0 com 0: nem uma coisa nem outra é 1, então não pode dar 1.',
              'Novamente, não é concatenar.',
              'Booleanos não tem negativo, lembra?',
            ],
          },
        },
      ],
      newGlossaryTerms: [
        {
          term: 'AND',
          termEn: 'AND (conjunction)',
          definition: 'Operação booleana de duas ou mais entradas que devolve 1 somente se TODAS as entradas forem 1. Se qualquer entrada for 0, o resultado é 0. Equivalente a interruptores em série.',
        },
      ],
    },
    {
      id: '2-4',
      title: 'OR: basta uma coisa ser verdade',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'A operação OR também recebe duas entradas, mas é o oposto do AND em certo sentido: ela devolve 1 SE PELO MENOS UMA das entradas for 1. A única situação em que OR devolve 0 é quando AS DUAS entradas são 0.',
            'É como o "ou" da língua portuguesa. "Eu vou ser feliz se ganhar na loteria OU se encontrar o amor da minha vida" — basta um dos dois para ficar feliz. Se os dois acontecerem, também tudo bem (não é "ou exclusivo", que veremos depois).',
            'Fisicamente, OR corresponde a dois interruptores em PARALELO (um caminho alternativo ao outro). Se QUALQUER UM estiver ligado, a corrente passa.',
          ],
        },
        {
          kind: 'reveal',
          title: 'Tabela-verdade do OR',
          texts: [
            'A | B | A OR B',
            '0 | 0 | 0',
            '0 | 1 | 1',
            '1 | 0 | 1',
            '1 | 1 | 1',
            '',
            'Note que só a PRIMEIRA linha (ambas 0) dá saída 0. Todas as outras dão 1.',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'warning',
          title: 'OR em português vs OR em lógica',
          text: 'Atenção! Em português, "ou" às vezes significa "um ou outro, mas não os dois" (como em "ou você fica ou vai embora"). Esse "ou exclusivo" é o XOR, que veremos depois. O OR da lógica booleana é o "ou inclusivo": se os dois forem verdade, tudo bem, a saída é 1 do mesmo jeito.',
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-2-8',
            type: 'multiple-choice',
            prompt: 'Quanto é 0 OR 0?',
            options: ['0', '1', '2', 'Nenhuma das alternativas.'],
            correctIndex: 0,
            feedbackIncorreto: [
              undefined,
              'OR precisa de PELO MENOS um 1. Ambos são 0, então resultado 0.',
              'Novamente: não é soma, não resulta em 2.',
              'É 0, confia.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-2-9',
            type: 'multiple-choice',
            prompt: 'Quanto é 1 OR 0?',
            options: ['0', '1', '10', 'Depende.'],
            correctIndex: 1,
            feedbackIncorreto: [
              'Tem um 1 na entrada! OR basta um 1 para dar 1.',
              undefined,
              'Não é junção de bits.',
              'OR é determinístico. Com um 1 e um 0, sempre dá 1.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-2-10',
            type: 'multiple-choice',
            prompt: 'Quanto é 1 OR 1?',
            options: ['0', '1', '2', '11'],
            correctIndex: 1,
            feedbackIncorreto: [
              'Tem dois 1s! OR com qualquer um 1 já dá 1, então com dois também dá 1.',
              undefined,
              'Já falamos: não é soma de inteiros. Booleanos não geram "2".',
              'É um único bit de saída, não dois bits.',
            ],
            explanation: 'OR é inclusivo. Se os dois são verdade, continua verdadeiro. A saída é um único bit (0 ou 1), não a soma.',
          },
        },
      ],
      newGlossaryTerms: [
        {
          term: 'OR',
          termEn: 'OR (disjunction, inclusive OR)',
          definition: 'Operação booleana que devolve 1 se PELO MENOS UMA entrada for 1. Só devolve 0 quando TODAS as entradas são 0. Equivalente a interruptores em paralelo.',
        },
      ],
    },
    {
      id: '2-5',
      title: 'Resumo e comparação das três operações',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Vamos colocar tudo lado a lado. Se você lembra da multiplicação e da adição, vai notar algo interessante:',
            'O AND se comporta exatamente como a MULTIPLICAÇÃO de 0s e 1s: 0×0=0, 0×1=0, 1×0=0, 1×1=1. Todas batem!',
            'O OR se parece com a adição, mas tem uma diferença na última linha: 1+1=2 na soma normal, mas 1 OR 1 = 1 na lógica booleana.',
            'O NOT é o inversor: uma coisa que a álgebra normal não tem de forma tão simples.',
          ],
        },
        {
          kind: 'reveal',
          title: 'Tabela-resumo das 3 operações básicas',
          texts: [
            'Inputs | AND | OR | XOR (que veremos depois)',
            '0  0   |  0  |  0 | 0',
            '0  1   |  0  |  1 | 1',
            '1  0   |  0  |  1 | 1',
            '1  1   |  1  |  1 | 0',
          ],
        },
        {
          kind: 'narrative',
          texts: [
            'Também existem regras óbvias chamadas "propriedades", mas que é bom mencionar:',
            'Comutatividade: A AND B = B AND A; A OR B = B OR A (ordem não importa).',
            'Associatividade: (A AND B) AND C = A AND (B AND C); mesmo para OR. Então podemos ter AND/OR com mais de duas entradas sem problema.',
            'Identidade: A AND 1 = A; A OR 0 = A (se você faz AND com 1 ou OR com 0, o valor não muda).',
            'Anulação: A AND 0 = 0 (basta um 0 para matar o AND); A OR 1 = 1 (basta um 1 para o OR dar 1).',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-2-11',
            type: 'multiple-choice',
            prompt: 'Qual das quatro linhas tem saída DIFERENTE entre AND e OR?',
            options: ['0 e 0', '0 e 1', '1 e 0', '1 e 1'],
            correctIndex: 3,
            feedbackIncorreto: [
              'Com 0 e 0: ambos dão 0. Igual.',
              'Com 0 e 1: AND dá 0, OR dá 1. Esta é diferente! Mas a questão é "qual das quatro", e tem duas certas? Espera: olhando a tabela: 00=0/0; 01=0/1; 10=0/1; 11=1/1. As linhas 01 e 10 são diferentes.',
              'Com 1 e 0: igual a 0 e 1. Mas a questão pede UMA resposta; na verdade 0,1 e 1,0 são ambas diferentes, mas como são equivalentes pela comutatividade...',
              'Com 1 e 1: ambos dão 1. São iguais.',
            ],
            explanation: 'Na verdade, AND e OR dão saídas diferentes tanto em (0,1) quanto em (1,0) — que é a mesma coisa pois ordem não importa. Para 0,0 os dois dão 0; para 1,1 os dois dão 1; para 0,1 e 1,0: AND dá 0 e OR dá 1.',
          },
        },
      ],
    },
    {
      id: '2-6',
      title: 'Expressões booleanas compostas',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Você pode combinar as operações para criar expressões maiores. Por exemplo: "A AND (NOT B)". Ou "(A OR B) AND C".',
            'A precedência é: NOT é calculado primeiro (como o sinal de negativo em matemática), depois AND, depois OR. Parenteses forçam a ordem, exatamente como na matemática normal.',
            'Exemplo: A = 1, B = 0. Quanto é A AND NOT B? Primeiro NOT B = NOT 0 = 1. Depois A AND 1 = 1 AND 1 = 1. Resultado: 1.',
            'Outro exemplo: A = 0, B = 1, C = 1. Quanto é (A OR B) AND (NOT C)? A OR B = 0 OR 1 = 1. NOT C = NOT 1 = 0. Então 1 AND 0 = 0.',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'warning',
          title: 'Precedência (ordem em que calculamos)',
          text: '1. NOT (mais forte, calcula primeiro)\n2. AND\n3. OR (mais fraco, calcula por último)\n\nIsso é só a convenção. Se tiver dúvida, use parênteses — eles nunca erram.',
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-2-12',
            type: 'multiple-choice',
            prompt: 'Com A=1, B=1, qual o resultado de (NOT A) AND B?',
            options: ['0', '1', '10', 'Não sei, preciso de ajuda.'],
            correctIndex: 0,
            feedbackIncorreto: [
              undefined,
              'Primeiro: NOT A = NOT 1 = 0. Depois: 0 AND B = 0 AND 1 = 0. Você esqueceu de negar A?',
              'Novamente, não é juntar bits.',
              'Vamos passo a passo: NOT 1 é 0. 0 AND qualquer coisa dá 0.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-2-13',
            type: 'multiple-choice',
            prompt: 'Com A=0, B=1, qual o resultado de A OR NOT B?',
            options: ['0', '1', 'Depende da ordem.', 'Não há dados suficientes.'],
            correctIndex: 0,
            feedbackIncorreto: [
              undefined,
              'NOT B = NOT 1 = 0. A OR 0 = 0 OR 0 = 0. Cuidado para não se confundir.',
              'A ordem é definida: NOT antes de OR. Se você calcular NOT A primeiro? NOT 0 é 1, mas A já é 0. Wait — a operação é NOT B, não NOT A. Preste atenção.',
              'Temos todos os valores: A=0, B=1. Dá para calcular.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-2-14',
            type: 'multiple-choice',
            prompt: 'Com A=1, B=0, C=1, qual o resultado de (A AND B) OR (NOT C)?',
            options: ['0', '1', '11', '2'],
            correctIndex: 0,
            feedbackIncorreto: [
              undefined,
              'Primeiro: A AND B = 1 AND 0 = 0. NOT C = NOT 1 = 0. OR entre eles: 0 OR 0 = 0.',
              'São bits separados; a resposta é um único bit.',
              'Não! Resultado booleano é sempre 0 ou 1.',
            ],
          },
        },
      ],
    },
    {
      id: '2-7',
      title: '⚔️ Chefe da Fase 2',
      blocks: [
        {
          kind: 'boss-intro',
          title: '⚔️ CHEFE DA FASE 2',
          text: 'Você precisa dominar as três operações básicas, saber as tabelas-verdade de cor e saber calcular expressões compostas. Essas operações são as ferramentas que você usará para construir TUDO nas próximas fases.',
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-2-1',
            type: 'multiple-choice',
            prompt: 'Qual é a ÚNICA combinação de entradas que faz um AND de duas entradas dar 1?',
            options: ['A=0, B=0', 'A=0, B=1', 'A=1, B=0', 'A=1, B=1'],
            correctIndex: 3,
            feedbackIncorreto: [
              '0 AND 0 = 0.',
              '0 AND 1 = 0.',
              '1 AND 0 = 0.',
              undefined,
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-2-2',
            type: 'multiple-choice',
            prompt: 'Qual é a ÚNICA combinação de entradas que faz um OR de duas entradas dar 0?',
            options: ['A=0, B=0', 'A=0, B=1', 'A=1, B=0', 'A=1, B=1'],
            correctIndex: 0,
            feedbackIncorreto: [
              undefined,
              '0 OR 1 = 1.',
              '1 OR 0 = 1.',
              '1 OR 1 = 1.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-2-3',
            type: 'free-response',
            prompt: 'Explique a diferença entre AND e OR com um exemplo do mundo real (do cotidiano), sem usar as palavras "booleano", "bit", "0" ou "1".',
            keywords: ['amb', 'dois', 'se', 'só', 'pelo menos', 'um', 'qualquer', 'tod', 'ou', 'e'],
            minWords: 20,
            sampleAnswer: 'Para eu ir ao cinema, eu preciso que eu tenha dinheiro E que o filme esteja passando. As duas coisas precisam acontecer — se faltar uma, não vou. OR é diferente: para eu ser feliz no fim de semana, basta eu ver um amigo OU jogar videogame. Se os dois acontecerem, também estou feliz. Se só um, também estou. Só não fico feliz se nada acontecer.',
          },
        },
        {
          kind: 'phase-complete',
            title: '🎉 Fase 2 concluída!',
            text: 'Agora você conhece as três operações fundamentais da lógica booleana: NOT, AND e OR. Na próxima fase, você vai ver como essas operações abstratas se transformam em peças FÍSICAS de hardware: as PORTAS LÓGICAS. Você vai interagir com elas, clicar nas entradas e ver as saídas mudando em tempo real.',
        },
      ],
    },
  ],
};

// ============================================================
// FASE 3: Portas Lógicas
// ============================================================
const fase3: Phase = {
  id: 3,
  title: 'Portas Lógicas',
  subtitle: 'A matemática que virou hardware',
  description: 'Agora vamos transformar a álgebra booleana em peças de hardware. Você vai conhecer os símbolos das portas lógicas, simulá-las e entender como transistores funcionam como interruptores que implementam AND, OR e NOT.',
  icon: '🔌',
  color: 'violet',
  lessons: [
    {
      id: '3-1',
      title: 'Onde a matemática encontra a física',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Lembre-se de Claude Shannon, o garoto de 21 anos do MIT? O que ele mostrou foi o seguinte: a álgebra booleana não é só uma curiosidade matemática. Você pode implementá-la com fios e interruptores.',
            'Uma "porta lógica" é um componente físico (hoje em dia, feito de transistores em um chip) que recebe uma ou mais entradas binárias (fios com alta ou baixa tensão) e produz uma saída binária de acordo com uma operação booleana.',
            'Cada operação booleana (NOT, AND, OR) corresponde a um tipo de porta lógica. E você pode ligar a saída de uma porta na entrada de outra, formando circuitos maiores — exatamente como você combina funções em uma expressão booleana.',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'curiosity',
          title: 'Quão pequenas são as portas lógicas hoje?',
          text: 'Em 1938, uma porta AND ocupava o espaço de uma caixa de sapatos, feita de relés mecânicos. Hoje, um transistor em um processador Apple M3 tem cerca de 3 nanômetros. Para você ter ideia: um fio de cabelo humano tem ~80.000 nanômetros de espessura. As portas lógicas são feitas de um punhado desses transistores.',
        },
      ],
      newGlossaryTerms: [
        {
          term: 'Porta Lógica',
          termEn: 'Logic Gate',
          definition: 'Um circuito físico (ou uma representação dele) que implementa uma operação booleana. Recebe 0s e 1s nas entradas, calcula a operação e devolve 0 ou 1 na saída.',
        },
        {
          term: 'Circuito',
          termEn: 'Circuit',
          definition: 'Uma rede de portas lógicas interligadas, onde saídas de umas portas se conectam às entradas de outras. Um circuito implementa uma função booleana mais complexa.',
        },
      ],
    },
    {
      id: '3-2',
      title: 'Como funciona fisicamente: interruptores e transistores',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Vamos simplificar a física. Um transistor (se comporta como) um INTERRUPTOR CONTROLADO POR ELETRICIDADE. Ele tem três terminais: a fonte (onde a corrente entra), o dreno (onde ela sai) e o gate (o "botão" que controla se está ligado ou desligado).',
            'Quando o gate recebe tensão alta (1), a corrente pode passar (interruptor ligado). Quando recebe tensão baixa (0), a corrente não passa (interruptor desligado).',
            'Importante: um transistor é menor que um fio de cabelo, é incrivelmente rápido (bilhões de operações por segundo), e não tem peças móveis. Mas pelo preço de um simples interruptor, é exatamente isso que ele é.',
          ],
        },
        {
          kind: 'reveal',
          title: 'Como fazer as portas com interruptores',
          texts: [
            'NOT: Um único transistor, configurado como inversor. Se a entrada é 1, a saída é 0, e vice-versa.',
            '',
            'AND: Dois transistores ligados em SÉRIE (um depois do outro). A corrente só chega à saída se AMBOS estiverem ligados. Para passar, precisa fechar os dois caminhos.',
            '',
            'OR: Dois transistores ligados em PARALELO (dois caminhos separados). Se QUALQUER UM estiver ligado, a corrente chega à saída.',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'simplification',
          title: 'Simplificação',
          text: 'A implementação real em transistores CMOS usa pares de transistores (PMOS + NMOS) e tem mais detalhes. Para os propósitos deste curso (entender a lógica), o modelo de "interruptor" é perfeitamente suficiente — o comportamento lógico é idêntico. Cursos de arquitetura de computadores ou eletrônica digital aprofundam isso.',
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-3-1',
            type: 'multiple-choice',
            prompt: 'Dois transistores em SÉRIE (um depois do outro) implementam qual operação?',
            options: ['NOT', 'AND', 'OR', 'XOR'],
            correctIndex: 1,
            feedbackIncorreto: [
              'NOT usa só um transistor e é um inversor.',
              undefined,
              'OR é em paralelo, não em série.',
              'XOR é uma composição mais complexa, não dois transistores.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-3-2',
            type: 'multiple-choice',
            prompt: 'Dois transistores em PARALELO (caminhos separados) implementam qual operação?',
            options: ['NOT', 'AND', 'OR', 'NAND'],
            correctIndex: 2,
            feedbackIncorreto: [
              'NOT é um inversor de uma entrada só.',
              'AND é em série.',
              undefined,
              'NAND é um AND seguido de um NOT, também mais complexo.',
            ],
          },
        },
      ],
    },
    {
      id: '3-3',
      title: 'Os símbolos das portas',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Para desenhar circuitos, usamos símbolos padronizados para cada porta. Você vai aprender a reconhecê-los agora. Cada porta tem: entradas (à esquerda) e uma saída (à direita ou ponta).',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'tip',
          title: 'Os símbolos que vamos usar',
          text: 'NOT (inversor): Um triângulo apontando para a direita com um pequeno círculo na ponta. O círculo significa "inversão", e ele sempre aparece na saída das portas negadas (NAND, NOR etc.).\n\nAND: Parece meio que um D achatado. A entrada é a face plana à esquerda, a saída é uma curva à direita.\n\nOR: Parece uma ponta de flecha curva, com duas linhas curvadas para dentro na entrada.',
        },
        {
          kind: 'narrative',
          texts: [
            'Aqui está o ponto importante: você não precisa decorar o desenho com precisão agora. Conforme formos usando, você vai pegar o jeito. O que importa é o COMPORTAMENTO de cada porta, que você já aprendeu na fase de álgebra booleana.',
          ],
        },
      ],
    },
    {
      id: '3-4',
      title: 'Simulador de portas: interaja você mesmo!',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Chega de ler! Agora você vai interagir com uma porta lógica real. Clique nos interruptores das entradas (0 = desligado, 1 = ligado) e veja a saída e o fio mudarem em tempo real.',
            'Vamos começar com um NOT, depois AND, depois OR.',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-3-3',
            type: 'gate-simulate',
            gateType: 'NOT',
            prompt: 'Experimente clicar no interruptor da entrada da porta NOT. Observe que a saída é sempre o inverso. Quando dominar o NOT, vamos para as portas de duas entradas.',
            inputs: [0],
            correctOutput: 1,
            hint: 'Pode parecer bobagem, mas certifique-se de que entendeu: a saída é sempre o oposto da entrada. Clique na entrada algumas vezes para ver.',
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-3-4',
            type: 'gate-simulate',
            gateType: 'AND',
            prompt: 'Porta AND. Brinque com as duas entradas. Observe que a saída só acende (fica 1) quando AS DUAS entradas estão em 1. (A saída 1 é representada por um fio dourado/brilhante.)',
            inputs: [0, 0],
            correctOutput: 0,
            hint: 'Todas as combinações: 00=0, 01=0, 10=0, 11=1.',
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-3-5',
            type: 'gate-simulate',
            gateType: 'OR',
            prompt: 'Porta OR. Tente todas as combinações. Note que a luz da saída acende com QUALQUER entrada em 1, inclusive as duas juntas.',
            inputs: [0, 0],
            correctOutput: 0,
            hint: '00=0; todas as outras três combinações dão 1.',
          },
        },
        {
          kind: 'narrative',
          texts: [
            'Parabéns! Você acabou de operar portas lógicas que funcionam exatamente da mesma forma que as portas dentro de um processador. O princípio é idêntico, os de um chip só são bilhões de vezes menores e mais rápidos.',
          ],
        },
      ],
    },
    {
      id: '3-5',
      title: 'Tabelas-verdade preenchidas por VOCÊ',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Agora vamos treinar de verdade: você vai preencher a coluna de saída da tabela-verdade para cada porta. Isso é recuperação ativa — você tem que PRODUZIR a resposta, não só reconhecer. Isso é muito mais eficaz para aprender.',
            'Preencha a saída para cada linha. Eu só deixo você avançar quando acertar todas.',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-3-6',
            type: 'truth-table',
            gateType: 'NOT',
            numInputs: 1,
            correctOutputs: [1, 0],
            prompt: 'Preencha a tabela-verdade da porta NOT. Clique nas células da coluna "Saída" para alternar entre 0 e 1.',
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-3-7',
            type: 'truth-table',
            gateType: 'AND',
            numInputs: 2,
            correctOutputs: [0, 0, 0, 1],
            prompt: 'Preencha a tabela do AND. Lembre-se: só a última linha dá 1.',
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-3-8',
            type: 'truth-table',
            gateType: 'OR',
            numInputs: 2,
            correctOutputs: [0, 1, 1, 1],
            prompt: 'Preencha a tabela do OR. Lembre-se: só a primeira linha dá 0.',
          },
        },
      ],
    },
    {
      id: '3-6',
      title: '⚔️ Chefe da Fase 3',
      blocks: [
        {
          kind: 'boss-intro',
            title: '⚔️ CHEFE DA FASE 3',
            text: 'Você precisa reconhecer portas, saber como elas correspondem à álgebra booleana e entender a base física. Vamos lá!',
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-3-1',
            type: 'identify-gate',
            prompt: 'A tabela-verdade abaixo pertence a qual porta?\n\n0,0 → 0\n0,1 → 0\n1,0 → 0\n1,1 → 1',
            truthTable: [[0,0,0],[0,1,0],[1,0,0],[1,1,1]],
            options: ['AND', 'OR', 'NOT', 'NAND'],
            correctGate: 'AND',
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-3-2',
            type: 'identify-gate',
            prompt: 'A tabela-verdade abaixo pertence a qual porta?\n\n0,0 → 0\n0,1 → 1\n1,0 → 1\n1,1 → 1',
            truthTable: [[0,0,0],[0,1,1],[1,0,1],[1,1,1]],
            options: ['AND', 'OR', 'NOT', 'NOR'],
            correctGate: 'OR',
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-3-3',
            type: 'free-response',
            prompt: 'Explique com suas palavras a relação entre os três níveis: álgebra booleana (abstrato), portas lógicas (desenho/símbolo) e transistores (físico). Como eles se conectam?',
            keywords: ['álgebra', 'matem', 'porta', 'físic', 'transist', 'implement', 'símbolo', 'hardware', 'abstra'],
            minWords: 30,
            sampleAnswer: 'A álgebra booleana é a matemática abstrata que define as regras (NOT, AND, OR). As portas lógicas são símbolos ou componentes que representam essas operações. Os transistores são os componentes físicos reais, feitos de silício, que implementam as portas. A álgebra é a ideia; a porta é a peça; os transistores são o material de que a peça é feita.',
          },
        },
        {
          kind: 'phase-complete',
          title: '🎉 Fase 3 concluída!',
          text: 'Agora você entende as três portas básicas e como elas são fisicamente construídas com transistores. Na Fase 4, você vai começar a MÁGICA: combinar portas para criar portas novas e mais poderosas. É a arte da composição, e é assim que construímos circuitos complexos a partir dos simples.',
        },
      ],
    },
  ],
};

// Vamos continuar construindo as fases em outro arquivo? Para não ficar gigante.
// Por uma questão de organização, vou fazer tudo num só arquivo mas continuar abaixo.

// ============================================================
// FASE 4: Composição - Portas feitas de portas
// ============================================================
const fase4: Phase = {
  id: 4,
  title: 'Composição',
  subtitle: 'Construindo portas com outras portas',
  description: 'Uma das ideias mais poderosas da computação: com apenas três portas básicas, você pode construir QUALQUER outra porta ou circuito. Nesta fase vamos criar NAND, NOR e XOR e descobrir o conceito de "universalidade".',
  icon: '🧱',
  color: 'rose',
  lessons: [
    {
      id: '4-1',
      title: 'O poder de combinar',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Na Fase 3 você aprendeu as portas básicas: NOT, AND e OR. Mas aqui vem a primeira revelação importante: você pode ligar a saída de uma porta na entrada de outra. E ao fazer isso, cria portas NOVAS.',
            'Isso se chama COMPOSIÇÃO, e é o processo pelo qual computadores inteiros são construídos: peças simples se juntam em peças maiores, que se juntam em peças ainda maiores, e assim por diante.',
            'Começaremos com as duas "portas negadas": NAND (AND seguido de NOT) e NOR (OR seguido de NOT).',
          ],
        },
      ],
      newGlossaryTerms: [
        {
          term: 'Composição',
          termEn: 'Composition',
          definition: 'O processo de construir coisas complexas a partir de coisas mais simples. Em computação, ligamos a saída de portas nas entradas de outras para criar circuitos maiores.',
        },
      ],
    },
    {
      id: '4-2',
      title: 'NAND: o AND invertido',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'NAND é a abreviação de "NOT AND" (não-AND). Ela é exatamente a porta AND seguida de um NOT (inversor) na saída.',
            'O que isso significa? Todas as saídas do AND são invertidas. Onde o AND dava 0, o NAND dá 1; onde o AND dava 1, o NAND dá 0.',
          ],
        },
        {
          kind: 'reveal',
          title: 'Tabela-verdade do NAND',
          texts: [
            'A | B | NAND',
            '0 | 0 | 1 (AND daria 0, invertemos → 1)',
            '0 | 1 | 1 (AND daria 0, invertemos → 1)',
            '1 | 0 | 1 (AND daria 0, invertemos → 1)',
            '1 | 1 | 0 (AND daria 1, invertemos → 0)',
            '',
            'O NAND é o oposto do AND: só dá 0 quando AMBAS as entradas são 1. Dá 1 em todo o resto.',
          ],
        },
        {
          kind: 'narrative',
          texts: [
            'Você pode identificar visualmente uma NAND porque ela tem o mesmo formato da AND, mas com um pequeno círculo na saída — esse círculo é o que significa "inverte aqui".',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-4-1',
            type: 'gate-simulate',
            gateType: 'NAND',
            prompt: 'Interaja com a porta NAND. Observe como ela se comporta: é o AND invertido. Tente todas as quatro combinações.',
            inputs: [0, 0],
            correctOutput: 1,
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-4-2',
            type: 'multiple-choice',
            prompt: 'Quando o NAND de duas entradas dá 0?',
            options: [
              'Quando as duas entradas são 0.',
              'Quando apenas uma entrada é 1.',
              'Quando as duas entradas são 1.',
              'Nunca — NAND sempre dá 1.',
            ],
            correctIndex: 2,
            feedbackIncorreto: [
              '0 NAND 0 = 1.',
              '0 NAND 1 = 1 e 1 NAND 0 = 1. Uma única entrada 1 ainda dá 1.',
              undefined,
              'Ele dá 0 sim, exatamente quando as duas são 1.',
            ],
          },
        },
      ],
      newGlossaryTerms: [
        {
          term: 'NAND',
          termEn: 'NAND (NOT AND)',
          definition: 'Porta que equivale a um AND seguido de NOT. Só dá saída 0 quando as duas entradas são 1. Nos circuitos integrados, é a mais "fácil" de construir e é universal (dá para fazer QUALQUER outra porta só com NAND).',
        },
      ],
    },
    {
      id: '4-3',
      title: 'NOR: o OR invertido',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'NOR é "NOT OR": é a porta OR seguida de um NOT. Novamente, basta inverter a saída do OR.',
          ],
        },
        {
          kind: 'reveal',
          title: 'Tabela-verdade do NOR',
          texts: [
            'A | B | NOR',
            '0 | 0 | 1 (OR dá 0, invertido → 1)',
            '0 | 1 | 0 (OR dá 1, invertido → 0)',
            '1 | 0 | 0 (OR dá 1, invertido → 0)',
            '1 | 1 | 0 (OR dá 1, invertido → 0)',
            '',
            'NOR só dá 1 quando AMBAS as entradas são 0. Em todas as outras situações, dá 0.',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-4-3',
            type: 'gate-simulate',
            gateType: 'NOR',
            prompt: 'Interaja com a porta NOR. Note que ela é muito rara de dar 1 — só quando ambos são 0.',
            inputs: [0, 0],
            correctOutput: 1,
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-4-4',
            type: 'truth-table',
            gateType: 'NOR',
            numInputs: 2,
            correctOutputs: [1, 0, 0, 0],
            prompt: 'Preencha a tabela-verdade do NOR (OR invertido). Lembre: é o oposto do OR.',
          },
        },
      ],
      newGlossaryTerms: [
        {
          term: 'NOR',
          termEn: 'NOR (NOT OR)',
          definition: 'Porta que equivale a um OR seguido de NOT. Só dá saída 1 quando as duas entradas são 0. Também é universal.',
        },
      ],
    },
    {
      id: '4-4',
      title: 'A grande surpresa: uma única porta basta (universalidade)',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Aqui vem uma descoberta que choca muita gente: você não precisa de NOT, AND e OR. Com APENAS um tipo de porta — NAND ou NOR — você consegue reconstruir todas as outras!',
            'Isso se chama "universalidade funcional" (functional completeness). A porta NAND e a porta NOR são ditas "universais".',
            'Só com NANDs, você faz NOT, depois AND, depois OR, e daí para frente, tudo.',
            'Essa é a razão pela qual o curso famoso do MIT se chama "NAND to Tetris": eles escolhem o NAND como tijolo único, e com ele constroem um computador inteiro do zero.',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'curiosity',
          title: 'Por que isso importa na prática',
          text: 'Se você projetar um chip e tiver que fabricar um tipo só de porta (NAND, em vez de três diferentes), o processo de fabricação fica mais simples e mais barato. Foi uma escolha natural na história dos circuitos integrados. NAND e NOR são menores e mais rápidas para construir em silício do que AND ou OR puras.',
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-4-5',
            type: 'multiple-choice',
            prompt: 'O que significa que uma porta é "universal"?',
            options: [
              'Que ela funciona em qualquer país do mundo.',
              'Que você pode construir TODAS as outras portas apenas usando ela repetidamente.',
              'Que ela é maior e mais potente que as outras.',
              'Que ela é a mais difícil de construir.',
            ],
            correctIndex: 1,
            feedbackIncorreto: [
              'Haha, não. Universal aqui tem sentido matemático.',
              undefined,
              'Não, o NAND é inclusive mais simples que muitas outras.',
              'É o oposto: geralmente é a mais simples de fabricar.',
            ],
          },
        },
      ],
      newGlossaryTerms: [
        {
          term: 'Universalidade',
          termEn: 'Functional Completeness',
          definition: 'A propriedade de um conjunto de operações (ou de uma única operação) que permite construir QUALQUER outra função booleana. NAND e NOR são universais.',
        },
      ],
    },
    {
      id: '4-5',
      title: 'XOR: o "ou exclusivo"',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Lembra que eu comentei sobre o "ou exclusivo" na fase do OR? Chegou a hora de conhecê-lo formalmente: XOR (de "exclusive OR").',
            'O XOR devolve 1 somente quando as DUAS ENTRADAS SÃO DIFERENTES (uma é 0 e a outra é 1). Se as duas são iguais (ambas 0 ou ambas 1), ele devolve 0.',
            'Ele é extremamente útil, porque é a operação de "diferença": detecta quando as entradas não batem.',
          ],
        },
        {
          kind: 'reveal',
          title: 'Tabela-verdade do XOR',
          texts: [
            'A | B | XOR',
            '0 | 0 | 0  (iguais: 0)',
            '0 | 1 | 1  (diferentes: 1)',
            '1 | 0 | 1  (diferentes: 1)',
            '1 | 1 | 0  (iguais: 0)',
          ],
        },
        {
          kind: 'narrative',
          texts: [
            'O XOR é uma porta feita pela combinação de AND, OR e NOT. A construção exata é: (A AND (NOT B)) OR ((NOT A) AND B). Ou seja: "(A mas não B) ou (B mas não A)".',
            'Observe que isso dá 1 exatamente quando apenas uma das duas é 1 — mas não as duas.',
            'Você também vai ver o símbolo ⊕ para XOR em muitos textos. A ⊕ B = A XOR B.',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-4-6',
            type: 'gate-simulate',
            gateType: 'XOR',
            prompt: 'Interaja com o XOR. Note a diferença para o OR: quando as duas entradas são 1, XOR dá 0; OR dava 1. Essa é a única diferença entre eles!',
            inputs: [0, 0],
            correctOutput: 0,
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-4-7',
            type: 'truth-table',
            gateType: 'XOR',
            numInputs: 2,
            correctOutputs: [0, 1, 1, 0],
            prompt: 'Preencha a tabela do XOR. Dica: dá 1 só quando os dois são diferentes.',
          },
        },
      ],
      newGlossaryTerms: [
        {
          term: 'XOR (ou exclusivo)',
          termEn: 'XOR (eXclusive OR)',
          definition: 'Porta que dá 1 somente quando as entradas são DIFERENTES (0 e 1, ou 1 e 0). Quando são iguais (00 ou 11), dá 0. É a base dos somadores, que veremos na Fase 5.',
        },
      ],
    },
    {
      id: '4-6',
      title: 'Reconhecendo portas por suas tabelas',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Agora que temos 6 portas (NOT, AND, OR, NAND, NOR, XOR), vamos praticar a identificação a partir da tabela-verdade. Se você consegue olhar para uma tabela e dizer qual porta é, você demonstrou que domina o comportamento de todas elas.',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-4-8',
            type: 'identify-gate',
            prompt: 'Identifique a porta: 00→1, 01→1, 10→1, 11→0',
            truthTable: [[0,0,1],[0,1,1],[1,0,1],[1,1,0]],
            options: ['AND', 'OR', 'NAND', 'NOR'],
            correctGate: 'NAND',
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-4-9',
            type: 'identify-gate',
            prompt: 'Identifique a porta: 00→0, 01→1, 10→1, 11→0',
            truthTable: [[0,0,0],[0,1,1],[1,0,1],[1,1,0]],
            options: ['OR', 'AND', 'XOR', 'NOR'],
            correctGate: 'XOR',
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-4-10',
            type: 'identify-gate',
            prompt: 'Identifique a porta: 00→1, 01→0, 10→0, 11→0',
            truthTable: [[0,0,1],[0,1,0],[1,0,0],[1,1,0]],
            options: ['OR', 'NOR', 'AND', 'NAND'],
            correctGate: 'NOR',
          },
        },
      ],
    },
    {
      id: '4-7',
      title: '⚔️ Chefe da Fase 4',
      blocks: [
        {
          kind: 'boss-intro',
          title: '⚔️ CHEFE DA FASE 4',
          text: 'Você precisa dominar as seis portas e o conceito de composição/universalidade.',
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-4-1',
            type: 'multiple-choice',
            prompt: 'Qual é a diferença entre XOR e OR?',
            options: [
              'Não há diferença; são a mesma coisa com nomes diferentes.',
              'XOR dá 0 quando os dois são 1; OR dá 1.',
              'OR é mais rápido; XOR é mais lento.',
              'XOR tem três entradas; OR tem duas.',
            ],
            correctIndex: 1,
            feedbackIncorreto: [
              'Há uma diferença crucial na linha 1,1.',
              undefined,
              'Não tem nada a ver com velocidade; são apenas operações diferentes.',
              'Ambos podem ter duas ou mais entradas; a diferença é a regra.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-4-2',
            type: 'multiple-choice',
            prompt: 'Se eu só tiver portas NAND, consigo construir um computador inteiro?',
            options: [
              'Não — preciso também de NOT, AND e OR.',
              'Sim, porque NAND é universal, e com ela consigo fazer todas as outras portas.',
              'Não, porque NAND só aceita 0s e não 1s.',
              'Sim, mas o computador só vai fazer cálculos envolvendo negação.',
            ],
            correctIndex: 1,
            feedbackIncorreto: [
              'Você pode fazer NOT, AND e OR a partir de NANDs. O MIT provou isso construindo um computador inteiro só com NAND.',
              undefined,
              'NAND aceita 0s e 1s normalmente.',
              'Você consegue fazer TODOS os cálculos, não só negação.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-4-3',
            type: 'free-response',
            prompt: 'Explique o conceito de composição aplicado a portas lógicas. Dê um exemplo de uma porta que é feita compondo outras.',
            keywords: ['combin', 'lig', 'saída', 'entrada', 'porta', 'NAND', 'NOR', 'XOR', 'constr', 'form', 'AND', 'NOT', 'OR'],
            minWords: 25,
            sampleAnswer: 'Composição significa ligar a saída de uma porta na entrada de outra para criar portas novas, mais complexas. Por exemplo: um NAND é um AND cuja saída passa por um NOT. Um XOR é feito com vários AND, OR e NOT. Com a composição, partimos de portas simples e construímos tudo o mais.',
          },
        },
        {
          kind: 'phase-complete',
          title: '🎉 Fase 4 concluída!',
          text: 'Agora você sabe que podemos combinar portas básicas para criar portas novas. Na Fase 5, nós vamos usar esse poder para construir circuitos ÚTEIS: multiplexadores (que escolhem entre sinais) e SOMADORES, que fazem aritmética real. Sim: vamos ver como a soma de números nasce diretamente da lógica booleana.',
        },
      ],
    },
  ],
};

// ============================================================
// FASE 5: Circuitos Úteis - MUX e Somadores
// ============================================================
const fase5: Phase = {
  id: 5,
  title: 'Aritmética Booleana',
  subtitle: 'Quando a lógica vira cálculo',
  description: 'Aqui é onde tudo clica. Você vai construir multiplexadores e depois somadores — circuitos que EFETIVAMENTE SOMAM números binários. Esse é o momento onde a lógica deixa de ser "coisa filosófica" e se transforma em computação de verdade.',
  icon: '🧮',
  color: 'orange',
  lessons: [
    {
      id: '5-1',
      title: 'Multiplexador: o escolhedor',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Antes de chegarmos à soma, vamos conhecer um circuito incrivelmente útil chamado MUX (abreviação de multiplexador).',
            'Um MUX é como um "seletor de fonte". Ele tem duas entradas de dados (A e B) e uma entrada extra chamada "seleção" (S). O MUX olha para S: se S for 0, ele manda o valor de A para a saída; se S for 1, ele manda o valor de B.',
            'Ou seja: ele é um canal de TV. S escolhe qual "canal" (A ou B) aparece na tela (saída).',
          ],
        },
        {
          kind: 'reveal',
          title: 'Como o MUX funciona',
          texts: [
            'Entradas: A, B (dados) e S (seleção de 1 bit, 0 ou 1)',
            'Saída: um único bit.',
            '',
            'S=0 → saída = A',
            'S=1 → saída = B',
            '',
            'Equação booleana: (A AND (NOT S)) OR (B AND S)',
            'Ou seja: "A quando S é 0; B quando S é 1".',
          ],
        },
        {
          kind: 'narrative',
          texts: [
            'Esse circuito é a base de MUITA coisa dentro do processador: selecionar qual operação a ALU deve fazer, rotear dados entre barramentos, etc.',
            'Mas o MUX é só o aquecimento. Vamos ao astro da fase.',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-5-1',
            type: 'multiple-choice',
            prompt: 'Em um MUX de 2 entradas, se S=0 e A=1 e B=0, qual é a saída?',
            options: ['0', '1', '2', 'Depende da ordem que eu ligar.'],
            correctIndex: 1,
            feedbackIncorreto: [
              'S=0 seleciona A (que vale 1).',
              undefined,
              'A saída é um bit, nunca 2.',
              'Não — S=0 sempre seleciona o canal A.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-5-2',
            type: 'multiple-choice',
            prompt: 'Em um MUX, se S=1, A=0, B=0, qual é a saída?',
            options: ['0', '1', 'Erro', '11'],
            correctIndex: 0,
            feedbackIncorreto: [
              undefined,
              'S=1 seleciona B, que é 0.',
              'Não dá erro; dá 0 simplesmente.',
              'É um bit, não dois.',
            ],
          },
        },
      ],
      newGlossaryTerms: [
        {
          term: 'Multiplexador (MUX)',
          termEn: 'Multiplexer (MUX)',
          definition: 'Circuito que tem múltiplas entradas de dados e uma entrada de seleção. A saída é a entrada de dados que o sinal de seleção escolher. Funciona como um comutador/seletor.',
        },
      ],
    },
    {
      id: '5-2',
      title: 'A grande pergunta: como somar com lógica?',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Nós sabemos contar em binário. Nós sabemos lógica booleana. Nós sabemos portas. Agora a pergunta que tudo responde: como um computador SOMA dois números binários?',
            'Vamos começar pelo caso mais simples: somar dois bits de um dígito só.',
            'Em binário, 0+0=0, 0+1=1, 1+0=1 e 1+1=... 10 (ou seja, 0 com um "vai-um" para a próxima casa).',
          ],
        },
        {
          kind: 'reveal',
          title: 'A soma de dois bits',
          texts: [
            'A soma de dois bits (A e B) tem DUAS saídas: o bit do RESULTADO (chamamos de S, de "sum") e o bit de "vai um" ou "carry-out" (chamamos de C_out).',
            '',
            'A | B | S (soma) | C_out (vai-um)',
            '0 | 0 | 0        | 0',
            '0 | 1 | 1        | 0',
            '1 | 0 | 1        | 0',
            '1 | 1 | 0        | 1',
          ],
        },
        {
          kind: 'narrative',
          texts: [
            'Agora olhe com atenção para a coluna S (soma). Você já viu esse padrão antes? É exatamente o XOR!',
            'E a coluna C_out (vai-um)? É exatamente o AND!',
            'Isso significa que para somar dois bits, precisamos de APENAS duas portas: um XOR para calcular a soma, e um AND para calcular o vai-um.',
            'Isso é tão simples que chega a ser chocante. Uma operação que crianças de 7 anos aprendem é exatamente duas portas lógicas.',
          ],
        },
        {
          kind: 'exercise',
            exercise: {
            id: 'ex-5-3',
            type: 'multiple-choice',
            prompt: 'Que porta lógica dá o bit da soma (S) ao somar dois bits?',
            options: ['AND', 'OR', 'XOR', 'NAND'],
            correctIndex: 2,
            feedbackIncorreto: [
              'AND dá o carry (vai-um), não a soma.',
              'OR daria 1 para 1+1, mas a soma ali é 0 (com carry 1).',
              undefined,
              'NAND dá 1 em quase todos os casos, não serve.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-5-4',
            type: 'multiple-choice',
            prompt: 'Que porta lógica dá o bit do "vai um" (carry) ao somar dois bits?',
            options: ['AND', 'OR', 'XOR', 'NOT'],
            correctIndex: 0,
            feedbackIncorreto: [
              undefined,
              'OR daria 1 em todos os casos exceto 0+0, mas só queremos carry quando AMBOS são 1.',
              'XOR dá a soma, não o carry.',
              'NOT é inversor de uma entrada; não serve para duas.',
            ],
          },
        },
      ],
      newGlossaryTerms: [
        {
          term: 'Half-Adder (Somador de Meio Bit)',
          termEn: 'Half-Adder',
          definition: 'Circuito que soma DOIS bits (A e B), produzindo um bit de soma (S) e um bit de carry-out (C_out). É chamado de "meio" somador porque ainda não sabe lidar com um carry que vem da casa anterior.',
        },
        {
          term: 'Carry (Vai-um)',
          termEn: 'Carry',
          definition: 'O bit que é "carregado" para a próxima coluna da soma quando a soma em uma coluna ultrapassa 1 (em binário: só acontece em 1+1, que gera carry 1).',
        },
      ],
    },
    {
      id: '5-3',
      title: 'Half-Adder: interaja com o primeiro somador do mundo',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Aqui abaixo está o diagrama do half-adder: ele tem dois bits de entrada (A e B), passa A e B por um XOR para obter S, e por um AND para obter C_out. Brinque com as entradas. Note que S é sempre a soma do dígito e C_out é o que vai para a casa da esquerda.',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-5-5',
            type: 'build-half-adder',
            prompt: 'Este é o half-adder. Clique nas entradas e observe como S e C_out correspondem à soma de dois bits. Verifique todas as quatro combinações.',
          },
        },
        {
          kind: 'narrative',
          texts: [
            'Você pode estar pensando: "tá, somar dois bits é legal, mas e se tiver um carry entrando da casa anterior?". O half-adder não lida com isso. Para somar colunas do meio (onde chega um carry da direita), precisamos de um circuito um pouco mais esperto.',
          ],
        },
      ],
    },
    {
      id: '5-4',
      title: 'Full-Adder: somando com "vem-um"',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Um "full-adder" (somador completo) soma TRÊS bits: A, B e C_in (o carry que VEM da casa anterior). Ele ainda gera S (soma do bit) e C_out (carry que VAI para a próxima casa).',
            'Como construir um? Simples: usamos DOIS half-adders ligados em sequência:',
            '1. Primeiro, somamos A e B com um half-adder. Temos uma soma parcial S1 e um carry C1.',
            '2. Depois, somamos S1 com C_in usando outro half-adder. Isso dá o S final e um carry C2.',
            '3. O C_out final é o OR entre C1 e C2 (se qualquer um dos dois half-adders gerou carry, temos carry para frente).',
          ],
        },
        {
          kind: 'reveal',
          title: 'O que o full-adder faz (tabela-verdade resumida)',
          texts: [
            'O full-adder tem 3 entradas (8 combinações), mas o princípio é simples: ele soma os três bits e dá o resultado e o carry de saída.',
            'Ex: 1+1+1 = 11 em binário (3 em decimal), então S=1 e C_out=1.',
            'Ex: 1+0+1 = 10 (2 em decimal), então S=0 e C_out=1.',
          ],
        },
        {
          kind: 'narrative',
          texts: [
            'Com um full-adder, podemos somar números com MÚLTIPLOS BITS. Como?',
            'Lembre-se de como você somava números grandes no papel: começava da coluna da direita (unidades), somava os dígitos, escrevia o resultado e levava o "vai um" para a coluna à esquerda. Depois fazia a mesma coisa na próxima coluna, agora somando os dígitos MAIS o que veio da anterior.',
            'Pois é. Para somar números binários de vários bits, fazemos EXATAMENTE ISSO: um full-adder por coluna, e o carry-out de um é ligado ao carry-in do próximo à esquerda.',
            'O bit mais à direita não tem carry entrando (C_in = 0), e o carry-out do bit mais à esquerda é o bit de overflow (estoura a capacidade).',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-5-6',
            type: 'multiple-choice',
            prompt: 'Quantas entradas tem um full-adder?',
            options: [
              '2 (A e B).',
              '3 (A, B, carry-in).',
              '4 (A, B, carry-in, carry-out).',
              'Depende do tamanho do número.',
            ],
            correctIndex: 1,
            feedbackIncorreto: [
              'Esse é o half-adder. O full-adder também recebe o carry da coluna anterior.',
              undefined,
              'Carry-out é saída, não entrada. Contamos só entradas.',
              'O full-adder sempre soma 3 bits de uma vez; depois encadeamos vários para números maiores.',
            ],
          },
        },
      ],
      newGlossaryTerms: [
        {
          term: 'Full-Adder (Somador Completo)',
          termEn: 'Full-Adder',
          definition: 'Circuito que soma TRÊS bits: A, B e carry-in (vem-um da coluna anterior). Produz S (soma) e carry-out (vai-um para a próxima coluna). Feito com dois half-adders e um OR.',
        },
        {
          term: 'Overflow',
          termEn: 'Overflow',
          definition: 'Quando o carry-out do bit mais significativo é 1, a soma é maior do que o número de bits aguenta. É o "estouro" da capacidade.',
        },
      ],
    },
    {
      id: '5-5',
      title: 'A visão do alto: somadores de 4 bits, 8 bits, 16 bits...',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Com um half-adder na coluna da direita (porque não há carry-in) e full-adders nas colunas seguintes, conseguimos somar números de QUALQUER tamanho.',
            'Quer um somador de 8 bits? Encadeie 1 half-adder + 7 full-adders. (Na prática, para simplificar, usamos full-adders também na primeira coluna, com C_in=0.)',
            'Quer 16 bits? 16 full-adders em cascata. E assim por diante.',
            'E o mais incrível: cada full-adder é só 6 portas lógicas. Ou seja, um somador de 8 bits é 48 portas. Algumas dezenas de transistores por porta, total de algumas centenas de transistores. E um processador moderno tem BILHÕES de transistores. Dá para ter noção do quanto é possível construir.',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'curiosity',
          title: 'Da soma para a calculadora inteira',
          text: 'Com somadores, conseguimos fazer adição. Subtração é uma adição com um número negativo (usando complemento de dois, que é assunto de uma fase futura). Multiplicação é soma repetida. Divisão é subtração repetida. De fato, as quatro operações básicas são construídas em cima da adição, que é construída em cima de XOR e AND, que são construídos com transistores. Então: aritmética inteira é lógica booleana em cascata.',
        },
      ],
    },
    {
      id: '5-6',
      title: '⚔️ Chefe da Fase 5',
      blocks: [
        {
          kind: 'boss-intro',
          title: '⚔️ CHEFE DA FASE 5',
          text: 'Você precisa entender como a lógica booleana implementa a soma. Este é o momento crucial — se você dominar isso, você entendeu o coração da computação.',
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-5-1',
            type: 'multiple-choice',
            prompt: 'Um half-adder somando 1+1 dá...',
            options: [
              'Soma=0, Carry=1',
              'Soma=1, Carry=1',
              'Soma=2, Carry=0',
              'Erro, porque 1+1 é maior que 1.',
            ],
            correctIndex: 0,
            feedbackIncorreto: [
              undefined,
              'Soma é XOR de A e B: 1 XOR 1 = 0. A soma de 1+1 em binário de 1 bit é 0 com carry 1.',
              'Soma é um bit, não pode ser 2!',
              'Não é erro; é assim que funciona a adição binária — o resultado 10 tem dois bits: 0 no resultado da coluna e 1 no carry.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-5-2',
            type: 'free-response',
            prompt: 'Explique com suas palavras: por que a soma de dois bits é feita com XOR e o carry com AND? Relacione com o que você aprendeu sobre o comportamento dessas portas.',
            keywords: ['XOR', 'AND', 'difer', 'amb', 'igu', 'soma', 'carry', '1', '0'],
            minWords: 30,
            sampleAnswer: 'O XOR dá 1 quando os dois bits são diferentes (0+1 ou 1+0), que é exatamente quando a soma do bit é 1 sem carry. Quando são iguais: se ambos 0, soma 0; se ambos 1, soma 0 (com carry 1). O AND dá 1 somente quando AMBOS são 1, que é a única hora em que temos um carry. Então o XOR captura o bit do resultado, e o AND captura o vai-um.',
          },
        },
        {
          kind: 'phase-complete',
          title: '🎉 Fase 5 concluída!',
          text: 'Você entendeu o grande salto: de interruptores para lógica, de lógica para portas, de portas para somadores. O resto de um computador (subtração, comparações, desvios, instruções, memória) é tudo construído em cima dessa base. Na Fase 6, o chefão final: você vai construir e testar um somador completo de verdade.',
        },
      ],
    },
  ],
};

// ============================================================
// FASE 6: Projeto Final - O Somador
// ============================================================
const fase6: Phase = {
  id: 6,
  title: 'Projeto Final',
  subtitle: 'Construa você mesmo um somador funcional',
  description: 'Chegou a hora de aplicar tudo. Você vai construir um somador de 2 bits peça por peça, verificar que ele funciona, e depois responder a perguntas que exigem domínio completo. Se passar, está pronto para a ponte.',
  icon: '🏆',
  color: 'yellow',
  lessons: [
    {
      id: '6-1',
      title: 'Preparação: o projeto',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Vamos construir juntos um somador de 2 bits. Ele vai receber dois números de 2 bits cada (A1A0 e B1B0, onde A0 e B0 são as unidades, A1 e B1 são os "dois") e vai produzir um resultado de 3 bits (S2, S1, S0).',
            'Na verdade, você vai ver a simulação funcionando e terá que prever as saídas corretas para todas as combinações — demonstrando que você realmente entende como cada parte trabalha.',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'tip',
          title: 'Como o somador de 2 bits funciona',
          text: '1. Primeiro HA soma A0 + B0 → S0 e C0.\n2. Depois um FA soma A1 + B1 + C0 → S1 e C1.\n3. S2 é o próprio C1 (o carry final).\n\nResultado final: S2 S1 S0, um número de 3 bits.',
        },
      ],
    },
    {
      id: '6-2',
      title: 'Desafios do somador',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Abaixo, você verá um somador completo. Clique nas entradas para configurar os números A e B de 2 bits. Pense: qual deve ser o resultado antes de clicar?',
            'Depois de brincar, responda às perguntas.',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-6-1',
            type: 'multiple-choice',
            prompt: 'Somando A = 01 (1 em decimal) + B = 01 (1 em decimal), qual é o resultado binário de 3 bits?',
            options: [
              '010 (2 em decimal)',
              '001 (1)',
              '100 (4)',
              '011 (3)',
            ],
            correctIndex: 0,
            feedbackIncorreto: [
              undefined,
              '1+1 = 2, não 1.',
              '4 é 100, mas 1+1 dá 2.',
              '3 é 011; esse seria 1+2.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-6-2',
            type: 'multiple-choice',
            prompt: 'Somando A = 11 (3) + B = 11 (3), qual o resultado?',
            options: [
              '011 (3)',
              '101 (5)',
              '110 (6)',
              '111 (7)',
            ],
            correctIndex: 2,
            feedbackIncorreto: [
              '3+3 = 6. Você não propagou os carries?',
              '5 é 101. 3+3 dá 6 (110).',
              undefined,
              '7 é 3+4. 3+3 = 6.',
            ],
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-6-3',
            type: 'multiple-choice',
            prompt: 'Somando A = 10 (2) + B = 01 (1), qual o resultado?',
            options: [
              '010 (2)',
              '011 (3)',
              '100 (4)',
              '101 (5)',
            ],
            correctIndex: 1,
            feedbackIncorreto: [
              '2+1=3, não 2.',
              undefined,
              '4 é muito. 2+1=3.',
              '5 também é maior.',
            ],
          },
        },
      ],
    },
    {
      id: '6-3',
      title: 'A grande questão: dominando tudo',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Para passar de fase e provar que você realmente entendeu a base de tudo, você vai responder a uma última questão de explicação livre e uma pergunta difícil que conecta todas as fases.',
          ],
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-6-4',
            type: 'free-response',
            prompt: 'Resuma o caminho completo: saíndo de transistores (interruptores), como chegamos até a soma de números binários? Mencione: transistores, portas lógicas, AND/OR/NOT, composição, half-adder, full-adder, e como isso se conecta em um somador maior. (Esta é a pergunta mais importante do curso.)',
            keywords: ['transist', 'interrupt', 'porta', 'AND', 'OR', 'NOT', 'compos', 'soma', 'half', 'adder', 'full', 'XOR', 'carry', 'bin', 'encade', 'bit'],
            minWords: 60,
            sampleAnswer: 'Começamos com transistores funcionando como interruptores (ligado/desligado). Com dois transistores em série fazemos um AND; em paralelo, um OR; com um inversor, um NOT. Essas três portas (ou só NAND) são as operações booleanas. Ao combinar portas (composição), construímos XOR, que junto com AND forma um half-adder (soma dois bits em soma e carry). Com dois half-adders e um OR, fazemos um full-adder (soma dois bits MAIS o carry que vem da coluna anterior). Encadeando full-adders, um por bit, conseguimos somar números de qualquer tamanho. Tudo o que é computação repousa sobre essa arquitetura em camadas: hardware → portas → somadores → ALU → CPU → software.',
          },
        },
        {
          kind: 'exercise',
          exercise: {
            id: 'ex-boss-6-5',
            type: 'multiple-choice',
            prompt: 'Considere as afirmações:\n\nI. O XOR é sempre usado para o bit de soma porque dá 1 exatamente quando os bits são diferentes (0+1 ou 1+0).\nII. O carry é um AND porque só existe vai-um quando ambos os bits são 1.\nIII. Um somador de 4 bits precisa de 3 full-adders e 1 half-adder (ou 4 full-adders com C_in=0 no primeiro).\n\nQuais estão corretas?',
            options: [
              'Apenas I.',
              'Apenas I e II.',
              'Apenas II e III.',
              'Todas (I, II e III).',
            ],
            correctIndex: 3,
            feedbackIncorreto: [
              'Todas são verdadeiras! I é verdade, II é verdade, III é verdade.',
              'III também está correta!',
              'I também está correta!',
              undefined,
            ],
          },
        },
        {
          kind: 'phase-complete',
          title: '🏆 VOCÊ CHEGOU AO FIM DA BASE!',
          text: 'Parabéns! Você entende a fundação sobre a qual TUDO o mais em computação e programação é construído. Agora siga para a Fase 7, que é a ponte: explico o que vem a seguir, como essa base se conecta com programação de verdade, e quais seus próximos passos naturais.',
        },
      ],
    },
  ],
};

// ============================================================
// FASE 7: A Ponte (o que vem depois)
// ============================================================
const fase7: Phase = {
  id: 7,
  title: 'A Ponte para o Próximo Nível',
  subtitle: 'O que vem depois e como chegar a programar',
  description: 'Chegamos ao fim do curso fundamental. Vamos olhar para cima e ver a pirâmide inteira: daqui até a programação de alto nível que você ouve falar (Python, JavaScript etc.). Vou te indicar o caminho com honestidade, sem vendas nem atalhos falsos.',
  icon: '🌉',
  color: 'cyan',
  lessons: [
    {
      id: '7-1',
      title: 'Recapitulando a jornada',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Vamos recapitular rapidamente o que você aprendeu:',
            'Fase 0: A ideia fundamental — computadores usam apenas dois estados porque são fisicamente confiáveis. Toda informação vira bits.',
            'Fase 1: Números binários — contar com 0s e 1s usando valor posicional e potências de 2.',
            'Fase 2: Álgebra booleana — NOT, AND, OR, tabelas-verdade e expressões.',
            'Fase 3: Portas lógicas — como transistores implementam a álgebra booleana.',
            'Fase 4: Composição — construir portas novas (NAND, NOR, XOR) a partir das básicas; universalidade.',
            'Fase 5: Somadores — a grande revelação de como aritmética nasce da lógica.',
            'Fase 6: Você construiu e testou um somador, demonstrando domínio completo.',
            'O que você tem agora é a fundação. Vamos ver o que vem em cima dela.',
          ],
        },
      ],
    },
    {
      id: '7-2',
      title: 'As próximas camadas da pirâmide',
      blocks: [
        {
          kind: 'reveal',
          title: 'A pirâmide completa, do físico ao abstrato',
          texts: [
            'NÍVEL 0 (o que você dominou): Transistores → Portas lógicas (NOT/AND/OR/NAND/NOR/XOR) → Somadores → ALU (Arithmetic Logic Unit, que não é só somar: também faz AND, OR, XOR, comparações, etc.).',
            '',
            'NÍVEL 1: Memória. Flip-flops (construídos com portas em um loop de feedback) → registradores → RAM. Com memória, guardamos informação entre cálculos. Sem memória, você tem uma calculadora; com memória, você tem um computador.',
            '',
            'NÍVEL 2: CPU. ALU + registradores + unidade de controle + clock. O clock sincroniza tudo, a unidade de controlo busca "instruções" na memória e a ALU as executa.',
            '',
            'NÍVEL 3: Linguagem de máquina. Cada instrução (somar, mover, comparar, pular) é um número binário que a CPU entende diretamente. Programar em linguagem de máquina é tedioso e difícil.',
            '',
            'NÍVEL 4: Assembly (representação em texto das instruções de máquina, com nomes em vez de números).',
            '',
            'NÍVEL 5: Compiladores, linguagens de baixo nível (C, Rust). Escrevemos comandos mais próximos do português, um programa "compilador" traduz para linguagem de máquina.',
            '',
            'NÍVEL 6: Linguagens de alto nível (Python, JavaScript, Java, etc.). Abstrações ainda mais altas, com mais recursos, gerenciamento de memória, etc. Um outro compilador/interpretador traduz para algo mais baixo.',
            '',
            'NÍVEL 7: Frameworks, bibliotecas, aplicações, IA, web, jogos, etc.',
          ],
        },
        {
          kind: 'narrative',
          texts: [
            'Percebeu? Quanto mais alto o nível, mais produtivo você é (escreve menos para fazer mais), mas mais você depende de camadas abaixo que você pode não entender.',
            'O seu diferencial é que agora você sabe o que existe no fundo da pirâmide. Quando você chegar em Python e ouvir falar em "bit", "booleano", "operadores AND/OR", "overflow", "bytes", "binário", você não vai decorar — você vai entender.',
          ],
        },
      ],
      newGlossaryTerms: [
        {
          term: 'ALU (Unidade Lógica e Aritmética)',
          termEn: 'ALU (Arithmetic Logic Unit)',
          definition: 'O "cérebro" da CPU: o circuito que faz somas, subtrações, AND/OR/XOR, comparações etc. Tudo o que uma CPU faz de cálculo acontece na ALU. Ela é construída com o que você aprendeu.',
        },
        {
          term: 'Flip-flop',
          termEn: 'Flip-flop (latch)',
          definition: 'Circuito sequencial que guarda um bit de informação. Feito com portas lógicas conectadas em realimentação. É o bloco básico da memória (RAM, registradores).',
        },
        {
          term: 'RAM',
          termEn: 'RAM (Random Access Memory)',
          definition: 'Memória de acesso aleatório: um conjunto grande de células que guardam bits (ou bytes/palavras), organizadas em endereços. A CPU lê e escreve bytes na RAM enquanto o computador está ligado.',
        },
        {
          term: 'CPU',
          termEn: 'CPU (Central Processing Unit)',
          definition: 'O processador: ALU + registradores + unidade de controle + clock. Busca instruções na memória, decodifica, executa usando a ALU e a memória. É a peça que executa programas.',
        },
        {
          term: 'Linguagem de Máquina',
          termEn: 'Machine Code',
          definition: 'Sequências de bits que a CPU entende diretamente como comandos. Cada processador tem a sua (x86, ARM, RISC-V, etc.). É o nível mais baixo de programação.',
        },
        {
          term: 'Compilador',
          termEn: 'Compiler',
          definition: 'Programa que traduz código escrito em uma linguagem mais alta para uma mais baixa (ex: C → linguagem de máquina; Java → bytecode; Python → bytecode interpretado).',
        },
      ],
    },
    {
      id: '7-3',
      title: 'Seu próximo passo recomendado',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Eu queria poder te dizer "agora vá direto para Python", mas isso seria pular camadas intermediárias e você voltaria a ter a sensação de "estou decorando sem entender".',
            'Para o seu perfil (aprendiz que quer ir à raiz), o próximo passo MAIS RECOMENDADO é:',
          ],
        },
        {
          kind: 'aside',
          asidetype: 'curiosity',
          title: 'Caminho recomendado (de verdade, sem enrolação)',
          text: '1. Faça o curso NAND2TETRIS (é gratuito em nand2tetris.org e no Coursera). Ele continua exatamente de onde paramos: começa com portas NAND, passa por memória, CPU, e termina com uma linguagem de alto-level. Não precisa saber programar para começar a parte 1. O livro "The Elements of Computing Systems" é o companheiro do curso.\n\n2. Depois disso, você pode escolher uma linguagem. Python é amigável para iniciantes. Mas agora você vai estudar Python sabendo o que é cada tipo, cada operador, cada booleano, cada byte.\n\n3. Quando chegar em variáveis, tipos, funções, condicionais, loops, e depois em estruturas de dados e algoritmos, você vai se sair muito melhor porque sabe o que a máquina está realmente fazendo.\n\n4. Quando você tiver base de Python (ou qualquer outra linguagem), aí você pode escolher seu rumo: web, dados, IA, sistemas, jogos, etc.',
        },
        {
          kind: 'narrative',
          texts: [
            'Uma outra opção excelente é o livro "But How Do It Know?" de J. Clark Scott, que é um livro muito acessível que passa pelos mesmos tópicos em linguagem super simples, com diagramas.',
            'Ou o livro "Code" de Charles Petzold, que é um clássico e conta a história toda desde telégrafos e código Morse até computadores completos.',
          ],
        },
      ],
    },
    {
      id: '7-4',
      title: 'Como rodar este jogo/curso',
      blocks: [
        {
          kind: 'narrative',
          texts: [
            'Se você quiser rodar este curso novamente ou compartilhar com alguém:',
            '1. Instale o Node.js (baixe no site nodejs.org, a versão LTS recomendada).',
            '2. Abra o terminal na pasta do projeto.',
            '3. Execute "npm install" para instalar as dependências.',
            '4. Execute "npm run dev" para iniciar o servidor de desenvolvimento.',
            '5. Abra o navegador no endereço que aparecer no terminal (geralmente http://localhost:5173).',
            'O progresso fica salvo automaticamente no localStorage do navegador — se você fechar a aba e voltar depois, ele lembra onde você parou.',
          ],
        },
      ],
    },
    {
      id: '7-5',
      title: 'Encerramento',
      blocks: [
        {
          kind: 'quote',
          title: 'Parabéns!',
          text: 'A maioria das pessoas que programa profissionalmente nunca parou para pensar no que você aprendeu. Elas sabem usar as ferramentas, mas não sabem como as ferramentas funcionam por baixo. Você agora sabe.\n\nEspero que esse curso tenha cumprido a promessa: não ter dito "é assim porque é assim", ter construído em camadas, ter explicado o porquê de cada coisa, e ter dado exercícios para você provar a si mesmo que entendeu.\n\nLembre-se: a sensação de esforço, de "isso é difícil mas eu estou conseguindo", não é sinal de fracasso. É o sinal que a aprendizagem REAL está acontecendo. A ciência chama isso de "desirable difficulties" (dificuldades desejáveis). Se fosse fácil, você não estaria aprendendo nada duradouro.\n\nBoa jornada rumo a se tornar um craque em programação. A base está sólida. Agora é construir para cima.\n\n— O curso "A Base de Tudo".',
        },
      ],
    },
  ],
};

// Exporta todas as fases em ordem
export const phases: Phase[] = [
  fase0,
  fase1,
  fase2,
  fase3,
  fase4,
  fase5,
  fase6,
  fase7,
];

export function getPhaseById(id: number): Phase | undefined {
  return phases.find((p) => p.id === id);
}

export function getLessonById(
  phaseId: number,
  lessonId: string
): { phase: Phase; lessonIndex: number } | undefined {
  const phase = phases.find((p) => p.id === phaseId);
  if (!phase) return undefined;
  const idx = phase.lessons.findIndex((l) => l.id === lessonId);
  if (idx === -1) return undefined;
  return { phase, lessonIndex: idx };
}

export function getNextLesson(
  phaseId: number,
  lessonId: string
): { phaseId: number; lessonId: string } | null {
  const phase = phases.find((p) => p.id === phaseId);
  if (!phase) return null;
  const idx = phase.lessons.findIndex((l) => l.id === lessonId);
  if (idx === -1) return null;
  if (idx < phase.lessons.length - 1) {
    return { phaseId, lessonId: phase.lessons[idx + 1].id };
  }
  const nextPhase = phases.find((p) => p.id === phaseId + 1);
  if (!nextPhase) return null;
  return { phaseId: nextPhase.id, lessonId: nextPhase.lessons[0].id };
}

export function getAllGlossaryTerms(): GlossaryEntry[] {
  const terms: GlossaryEntry[] = [];
  const seen = new Set<string>();
  for (const phase of phases) {
    for (const lesson of phase.lessons) {
      if (lesson.newGlossaryTerms) {
        for (const t of lesson.newGlossaryTerms) {
          const key = t.term.toLowerCase();
          if (!seen.has(key)) {
            seen.add(key);
            terms.push(t);
          }
        }
      }
    }
  }
  return terms;
}
