import { useState, useEffect, useMemo } from 'react';
import type {
  LessonBlock,
  Exercise,
  Progress,
  GlossaryEntry,
} from './types';
import {
  phases,
  getNextLesson,
} from './courseData';
import {
  loadProgress,
  saveProgress,
  markLessonComplete,
  recordExerciseResult,
  unlockPhase,
  addGlossaryTerms,
  resetProgress,
} from './progressStore';
import {
  MultipleChoiceView,
  TruthTableView,
  GateSimulateView,
  FreeResponseView,
  IdentifyGateView,
  BuildHalfAdderView,
} from './components/Exercises';

// ============================================================
// App principal
// ============================================================
export default function App() {
  const [progress, setProgress] = useState<Progress>(() => loadProgress());
  const [currentView, setCurrentView] = useState<'course' | 'glossary' | 'intro'>('intro');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Persistência automática
  useEffect(() => {
    saveProgress(progress);
  }, [progress]);

  // Calcular lição atual
  const currentLesson = useMemo(() => {
    if (currentView !== 'course') return null;
    const phase = phases.find((p) => p.id === progress.currentPhaseId);
    if (!phase) return null;
    const lessonId = progress.currentLessonId ?? phase.lessons[0].id;
    const lesson = phase.lessons.find((l) => l.id === lessonId);
    return lesson ? { phase, lesson } : null;
  }, [progress, currentView]);

  // Ao entrar em uma lição, adicionar seus termos ao glossário
  useEffect(() => {
    if (currentLesson?.lesson.newGlossaryTerms) {
      const terms = currentLesson.lesson.newGlossaryTerms;
      if (terms.some((t) => !progress.glossary.find((g) => g.term.toLowerCase() === t.term.toLowerCase()))) {
        setProgress((p) => addGlossaryTerms(p, terms));
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentLesson?.lesson.id]);

  const totalLessons = phases.reduce((acc, p) => acc + p.lessons.length, 0);
  const completedCount = progress.completedLessons.length;
  const percentComplete = Math.round((completedCount / totalLessons) * 100);

  const navigateToLesson = (phaseId: number, lessonId: string) => {
    setProgress((p) => {
      let next: Progress = { ...p, currentPhaseId: phaseId, currentLessonId: lessonId };
      next = unlockPhase(next, phaseId);
      return next;
    });
    setCurrentView('course');
    setSidebarOpen(false);
    window.scrollTo(0, 0);
  };

  const completeCurrentLesson = () => {
    if (!currentLesson) return;
    const { phase, lesson } = currentLesson;
    setProgress((p) => {
      let next = markLessonComplete(p, lesson.id);
      next = unlockPhase(next, phase.id + 1);
      const nextLesson = getNextLesson(phase.id, lesson.id);
      if (nextLesson) {
        next.currentPhaseId = nextLesson.phaseId;
        next.currentLessonId = nextLesson.lessonId;
      }
      return next;
    });
    window.scrollTo(0, 0);
  };

  const handleExerciseResult = (exercise: Exercise, correct: boolean) => {
    setProgress((p) => recordExerciseResult(p, exercise.id, correct));
  };

  const handleReset = () => {
    if (window.confirm('Tem certeza que quer recomeçar do zero? Todo o progresso será apagado.')) {
      setProgress(resetProgress());
      setCurrentView('intro');
    }
  };

  // --------- TELA DE INTRO ---------
  if (currentView === 'intro') {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100">
        <div className="max-w-4xl mx-auto px-6 py-16">
          <div className="text-center space-y-6">
            <div className="inline-flex h-24 w-24 items-center justify-center rounded-3xl bg-gradient-to-br from-amber-400 to-rose-500 shadow-2xl shadow-amber-500/20 text-5xl">
              ⚛️
            </div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-amber-300 via-rose-300 to-indigo-300 bg-clip-text text-transparent">
              A Base de Tudo
            </h1>
            <p className="text-xl text-slate-400">
              Um curso-jogo interativo sobre o fundamento absoluto da computação
            </p>
          </div>

          <div className="mt-16 space-y-6 bg-slate-900/70 border border-slate-800 rounded-2xl p-8 leading-relaxed">
            <h2 className="text-2xl font-bold text-amber-300">O que é a "base" de que estamos falando?</h2>
            <p className="text-slate-300">
              A base mais fundamental de tudo o que existe em programação e computação é{' '}
              <strong className="text-amber-200">a Lógica Booleana Binária implementada como portas lógicas</strong>.
            </p>
            <p className="text-slate-300">
              Tudo — absolutamente tudo, desde o Google, WhatsApp, Instagram, ChatGPT, Python, JavaScript, Windows,
              iOS, PlayStation, o sistema operacional do seu celular e até o software que levou o homem à Lua —
              desce, camada por camada, até interruptores ligando e desligando, combinados pelas regras de
              AND, OR e NOT.
            </p>
            <p className="text-slate-300">
              Em 1854, George Boole criou a matemática da lógica binária. Em 1937, Claude Shannon provou que
              circuitos elétricos implementam essa matemática. Esse curso te leva do zero absoluto (o que é um bit?)
              até construir um somador funcional — o coração da ALU, que é o coração de todo processador.
            </p>
            <div className="border-t border-slate-800 pt-6">
              <h3 className="text-lg font-bold text-indigo-300 mb-3">Metodologia baseada em ciência da aprendizagem:</h3>
              <ul className="space-y-2 text-slate-300 list-disc list-inside">
                <li><strong className="text-slate-100">Recuperação ativa:</strong> você precisa PRODUZIR respostas, não só ler.</li>
                <li><strong className="text-slate-100">Feedback imediato:</strong> se errar, explico por quê sem dar a resposta de graça.</li>
                <li><strong className="text-slate-100">Progressão por domínio:</strong> só avança quando demonstrar que entendeu.</li>
                <li><strong className="text-slate-100">Camadas:</strong> nenhum termo aparece antes de ser explicado.</li>
                <li><strong className="text-slate-100">Prática:</strong> você interage com portas, preenche tabelas, soma números em binário.</li>
              </ul>
            </div>
          </div>

          {completedCount > 0 && (
            <div className="mt-8 bg-emerald-950/40 border border-emerald-800/40 rounded-2xl p-6 text-center">
              <p className="text-emerald-200">
                👋 Bem-vindo(a) de volta! Você já completou <strong>{completedCount}</strong> de {totalLessons} lições (
                {percentComplete}%).
              </p>
            </div>
          )}

          <div className="mt-8 flex flex-wrap gap-4 justify-center">
            <button
              onClick={() => {
                if (completedCount > 0) {
                  setCurrentView('course');
                } else {
                  navigateToLesson(0, '0-1');
                }
              }}
              className="px-8 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-slate-950 font-bold text-lg shadow-lg shadow-amber-500/30 transition-all hover:scale-105"
            >
              {completedCount > 0 ? `▶ Continuar (${percentComplete}%)` : '▶ Começar pela Fase 0'}
            </button>
            {completedCount > 0 && (
              <button
                onClick={() => navigateToLesson(0, '0-1')}
                className="px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold transition-colors"
              >
                Recomeçar do começo
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // --------- TELA DO CURSO ---------
  const phase = currentLesson?.phase;
  const lesson = currentLesson?.lesson;
  const lessonIndex = phase ? phase.lessons.findIndex((l) => l.id === lesson?.id) : -1;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex">
      {/* SIDEBAR */}
      <aside
        className={`fixed lg:sticky top-0 left-0 h-screen w-80 bg-slate-900 border-r border-slate-800 overflow-y-auto z-40 transition-transform ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="p-4 border-b border-slate-800">
          <button
            onClick={() => setCurrentView('intro')}
            className="flex items-center gap-2 w-full text-left group"
          >
            <span className="text-2xl">⚛️</span>
            <div>
              <div className="font-bold text-amber-300 group-hover:text-amber-200">A Base de Tudo</div>
              <div className="text-xs text-slate-400">Lógica Booleana & Portas</div>
            </div>
          </button>
        </div>

        <div className="p-4">
          <div className="mb-4">
            <div className="flex justify-between text-xs text-slate-400 mb-1">
              <span>Progresso total</span>
              <span>{percentComplete}%</span>
            </div>
            <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-indigo-500 transition-all"
                style={{ width: `${percentComplete}%` }}
              />
            </div>
          </div>

          <nav className="space-y-4">
            {phases.map((p) => {
              const isUnlocked = progress.phasesUnlocked.includes(p.id);
              const isCurrent = p.id === progress.currentPhaseId;
              const completedInPhase = p.lessons.filter((l) => progress.completedLessons.includes(l.id)).length;
              return (
                <div key={p.id}>
                  <button
                    disabled={!isUnlocked}
                    onClick={() => {
                      if (isUnlocked) {
                        const firstIncomplete = p.lessons.find((l) => !progress.completedLessons.includes(l.id)) ?? p.lessons[0];
                        navigateToLesson(p.id, firstIncomplete.id);
                      }
                    }}
                    className={`w-full text-left flex items-center gap-2 px-2 py-2 rounded-lg transition-colors ${
                      isCurrent
                        ? 'bg-slate-800 text-white'
                        : isUnlocked
                        ? 'text-slate-300 hover:bg-slate-800/50'
                        : 'text-slate-600 cursor-not-allowed'
                    }`}
                  >
                    <span className="text-xl">{isUnlocked ? p.icon : '🔒'}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold truncate">
                        Fase {p.id}: {p.title}
                      </div>
                      <div className="text-xs text-slate-500 truncate">{p.subtitle}</div>
                    </div>
                  </button>
                  {isUnlocked && isCurrent && (
                    <div className="ml-8 mt-1 space-y-0.5 border-l border-slate-700 pl-3">
                      {p.lessons.map((l, i) => {
                        const done = progress.completedLessons.includes(l.id);
                        const isCurrentLesson = l.id === progress.currentLessonId;
                        return (
                          <button
                            key={l.id}
                            onClick={() => navigateToLesson(p.id, l.id)}
                            className={`w-full text-left text-xs py-1 px-2 rounded transition-colors flex items-center gap-2 ${
                              isCurrentLesson
                                ? 'bg-indigo-500/20 text-indigo-200'
                                : done
                                ? 'text-emerald-400 hover:bg-slate-800'
                                : 'text-slate-400 hover:bg-slate-800/50'
                            }`}
                          >
                            <span>{done ? '✓' : i + 1}</span>
                            <span className="truncate">{l.title}</span>
                          </button>
                        );
                      })}
                      <div className="text-xs text-slate-500 mt-1">
                        {completedInPhase}/{p.lessons.length} lições
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </nav>
        </div>

        <div className="p-4 border-t border-slate-800 space-y-2">
          <button
            onClick={() => setCurrentView('glossary')}
            className="w-full px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm"
          >
            📖 Glossário ({progress.glossary.length} termos)
          </button>
          <button
            onClick={handleReset}
            className="w-full px-3 py-2 rounded-lg bg-red-950/30 hover:bg-red-900/40 text-red-300 text-xs"
          >
            🗑 Recomeçar do zero
          </button>
        </div>
      </aside>

      {/* Overlay mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* CONTEÚDO PRINCIPAL */}
      {currentView === 'glossary' ? (
        <GlossaryView terms={progress.glossary} onBack={() => setCurrentView('course')} />
      ) : phase && lesson ? (
        <main className="flex-1 min-h-screen">
          <div className="sticky top-0 z-20 bg-slate-950/95 backdrop-blur border-b border-slate-800 lg:hidden px-4 py-3 flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(true)}
              className="px-3 py-1.5 rounded bg-slate-800 text-sm"
            >
              ☰ Menu
            </button>
            <span className="text-sm text-slate-400">Fase {phase.id}: {phase.title}</span>
            <span />
          </div>

          <div className="max-w-3xl mx-auto px-6 py-10">
            <div className="mb-2 text-sm font-mono text-slate-500">
              Fase {phase.id} · Lição {lessonIndex + 1} de {phase.lessons.length}
            </div>
            <h1 className="text-4xl font-bold mb-2 text-slate-50">{lesson.title}</h1>
            {lesson.subtitle && (
              <p className="text-lg text-slate-400 mb-8">{lesson.subtitle}</p>
            )}

            <div className="space-y-6">
              {lesson.blocks.map((block, idx) => (
                <BlockRenderer
                  key={idx}
                  block={block}
                  onExerciseResult={handleExerciseResult}
                  completedExercises={progress.completedExercises}
                />
              ))}
            </div>

            <div className="mt-12 flex justify-between items-center border-t border-slate-800 pt-6">
              <button
                onClick={() => setCurrentView('intro')}
                className="text-slate-400 hover:text-slate-200 text-sm"
              >
                ← Voltar ao início
              </button>
              <button
                onClick={completeCurrentLesson}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold shadow-lg shadow-emerald-500/20 transition-all hover:scale-[1.02]"
              >
                {lessonIndex < phase.lessons.length - 1
                  ? 'Marcar como concluída e avançar →'
                  : phase.id < phases.length - 1
                  ? 'Concluir fase →'
                  : 'Concluir curso 🎉'}
              </button>
            </div>
          </div>
        </main>
      ) : null}
    </div>
  );
}

// ============================================================
// Renderizador de Blocos
// ============================================================
function BlockRenderer({
  block,
  onExerciseResult,
  completedExercises,
}: {
  block: LessonBlock;
  onExerciseResult: (exercise: Exercise, correct: boolean) => void;
  completedExercises: Record<string, { correct: boolean; attempts: number }>;
}) {
  switch (block.kind) {
    case 'narrative':
      return (
        <div className="space-y-4 text-slate-300 text-base leading-relaxed">
          {block.texts?.map((t, i) => (
            <p key={i}>{t}</p>
          ))}
          {block.text && <p>{block.text}</p>}
        </div>
      );

    case 'aside': {
      const colorMap: Record<string, string> = {
        curiosity: 'bg-sky-950/40 border-sky-700/40 text-sky-100',
        warning: 'bg-rose-950/40 border-rose-700/40 text-rose-100',
        history: 'bg-purple-950/40 border-purple-700/40 text-purple-100',
        simplification: 'bg-orange-950/40 border-orange-700/40 text-orange-100',
        tip: 'bg-emerald-950/40 border-emerald-700/40 text-emerald-100',
      };
      const iconMap: Record<string, string> = {
        curiosity: '💡',
        warning: '⚠️',
        history: '📜',
        simplification: 'ℹ️',
        tip: '✅',
      };
      const cls = colorMap[block.asidetype ?? 'tip'] ?? colorMap.tip;
      return (
        <div className={`rounded-xl border p-4 ${cls}`}>
          <div className="font-bold text-sm mb-1 flex items-center gap-2">
            <span>{iconMap[block.asidetype ?? 'tip'] ?? '✅'}</span>
            <span>{block.title}</span>
          </div>
          <div className="whitespace-pre-line text-sm leading-relaxed opacity-95">
            {block.text}
          </div>
        </div>
      );
    }

    case 'reveal':
      return (
        <details className="rounded-xl border border-indigo-700/30 bg-indigo-950/20 open:bg-indigo-950/40 transition-colors">
          <summary className="cursor-pointer px-5 py-3 font-bold text-indigo-200 hover:text-indigo-100">
            ▶ {block.title}
          </summary>
          <div className="px-5 pb-4 space-y-1 text-indigo-100/90 font-mono text-sm whitespace-pre-line">
            {block.texts?.map((t, i) => <div key={i}>{t}</div>)}
          </div>
        </details>
      );

    case 'quote':
      return (
        <div className="rounded-xl border-l-4 border-amber-500 bg-amber-950/20 pl-5 pr-4 py-4">
          {block.title && (
            <div className="text-amber-300 font-bold text-sm mb-2">{block.title}</div>
          )}
          <div className="text-amber-100/90 italic leading-relaxed whitespace-pre-line">
            {block.text}
          </div>
        </div>
      );

    case 'boss-intro':
      return (
        <div className="rounded-2xl border-2 border-rose-500/50 bg-gradient-to-br from-rose-950/60 via-slate-900 to-amber-950/40 p-6 shadow-lg shadow-rose-500/10">
          <div className="text-rose-300 font-bold text-xl mb-2">
            ⚔️ {block.title}
          </div>
          <p className="text-slate-200 leading-relaxed">{block.text}</p>
        </div>
      );

    case 'phase-complete':
      return (
        <div className="rounded-2xl border-2 border-emerald-500/40 bg-emerald-950/30 p-6 text-center shadow-lg shadow-emerald-500/10">
          <div className="text-3xl mb-3">{block.title}</div>
          <p className="text-emerald-100 leading-relaxed">{block.text}</p>
        </div>
      );

    case 'exercise': {
      if (!block.exercise) return null;
      const ex = block.exercise;
      const prevResult = completedExercises[ex.id];
      return (
        <div className="space-y-2">
          {(() => {
            switch (ex.type) {
              case 'multiple-choice':
                return (
                  <MultipleChoiceView
                    key={ex.id}
                    exercise={ex}
                    onComplete={(correct) => onExerciseResult(ex, correct)}
                  />
                );
              case 'truth-table':
                return (
                  <TruthTableView
                    key={ex.id}
                    exercise={ex}
                    onComplete={(correct) => onExerciseResult(ex, correct)}
                  />
                );
              case 'gate-simulate':
                return (
                  <GateSimulateView
                    key={ex.id}
                    exercise={ex}
                    onComplete={(correct) => onExerciseResult(ex, correct)}
                  />
                );
              case 'free-response':
                return (
                  <FreeResponseView
                    key={ex.id}
                    exercise={ex}
                    onComplete={(correct) => onExerciseResult(ex, correct)}
                  />
                );
              case 'identify-gate':
                return (
                  <IdentifyGateView
                    key={ex.id}
                    exercise={ex}
                    onComplete={(correct) => onExerciseResult(ex, correct)}
                  />
                );
              case 'build-half-adder':
                return (
                  <BuildHalfAdderView
                    key={ex.id}
                    exercise={ex}
                    onComplete={(correct) => onExerciseResult(ex, correct)}
                  />
                );
              default:
                return <div>Exercício de tipo desconhecido.</div>;
            }
          })()}
          {prevResult?.correct && (
            <div className="text-xs text-emerald-400">
              ✓ Exercício já resolvido ({prevResult.attempts} tentativa{prevResult.attempts > 1 ? 's' : ''}).
            </div>
          )}
        </div>
      );
    }

    default:
      return null;
  }
}

// ============================================================
// Tela do Glossário
// ============================================================
function GlossaryView({ terms, onBack }: { terms: GlossaryEntry[]; onBack: () => void }) {
  return (
    <main className="flex-1 min-h-screen px-6 py-10 max-w-3xl mx-auto">
      <button
        onClick={onBack}
        className="text-slate-400 hover:text-slate-200 text-sm mb-6"
      >
        ← Voltar para o curso
      </button>
      <h1 className="text-4xl font-bold mb-2">📖 Glossário</h1>
      <p className="text-slate-400 mb-8">
        Todos os termos técnicos que apareceram no curso, em ordem alfabética.
        Esta lista cresce automaticamente conforme você avança nas fases.
      </p>

      {terms.length === 0 ? (
        <p className="text-slate-500 italic">
          Nenhum termo adicionado ainda. Conforme você avançar no curso, os termos vão aparecer aqui.
        </p>
      ) : (
        <div className="space-y-4">
          {[...terms]
            .sort((a, b) => a.term.localeCompare(b.term, 'pt-BR'))
            .map((t, i) => (
              <div key={i} className="rounded-xl border border-slate-700/50 bg-slate-900/60 p-4">
                <div className="flex flex-wrap items-baseline gap-3">
                  <h3 className="font-bold text-amber-300 text-lg">{t.term}</h3>
                  {t.termEn && (
                    <span className="text-xs text-slate-500 font-mono">({t.termEn})</span>
                  )}
                </div>
                <p className="text-slate-300 text-sm mt-2 leading-relaxed">{t.definition}</p>
              </div>
            ))}
        </div>
      )}
    </main>
  );
}
