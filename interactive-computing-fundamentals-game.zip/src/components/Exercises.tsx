import { useState } from 'react';
import type {
  MultipleChoiceExercise,
  TruthTableExercise,
  GateSimulateExercise,
  FreeResponseExercise,
  IdentifyGateExercise,
  BuildHalfAdderExercise,
  GateType,
} from '../types';
import { GateSVG } from './GateSVG';
import { HalfAdderSVG } from './HalfAdderSVG';

// Funções de avaliação de portas
function gateOutput(type: GateType, inputs: number[]): number {
  const [a, b] = [inputs[0] ?? 0, inputs[1] ?? 0];
  switch (type) {
    case 'NOT':
      return a === 1 ? 0 : 1;
    case 'AND':
      return a === 1 && b === 1 ? 1 : 0;
    case 'OR':
      return a === 1 || b === 1 ? 1 : 0;
    case 'NAND':
      return a === 1 && b === 1 ? 0 : 1;
    case 'NOR':
      return a === 0 && b === 0 ? 1 : 0;
    case 'XOR':
      return a !== b ? 1 : 0;
    case 'XNOR':
      return a === b ? 1 : 0;
    default:
      return 0;
  }
}

interface ExerciseProps {
  onComplete: (correct: boolean) => void;
}

// ============================================================
// MÚLTIPLA ESCOLHA
// ============================================================
export function MultipleChoiceView({
  exercise,
  onComplete,
}: { exercise: MultipleChoiceExercise } & ExerciseProps) {
  const [selected, setSelected] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [showHint, setShowHint] = useState(false);

  const isCorrect = selected === exercise.correctIndex;

  const handleSubmit = () => {
    if (selected === null) return;
    setSubmitted(true);
    onComplete(isCorrect);
  };

  const getFeedback = () => {
    if (!submitted || selected === null) return null;
    if (isCorrect) {
      return exercise.explanation || 'Correto! 🎉';
    }
    return (
      exercise.feedbackIncorreto?.[selected] ||
      'Não foi dessa vez. Tente novamente — leia o feedback e pense de novo.'
    );
  };

  return (
    <div className="rounded-xl border border-slate-700/50 bg-slate-900/70 p-5 space-y-4">
      <p className="text-slate-100 text-lg leading-relaxed">{exercise.prompt}</p>
      <div className="space-y-2">
        {exercise.options.map((opt, i) => {
          let optClass =
            'w-full text-left px-4 py-3 rounded-lg border transition-all cursor-pointer ';
          if (!submitted) {
            optClass +=
              selected === i
                ? 'border-indigo-400 bg-indigo-500/20 text-indigo-100'
                : 'border-slate-700 bg-slate-800/50 text-slate-200 hover:border-slate-500 hover:bg-slate-800';
          } else {
            if (i === exercise.correctIndex) {
              optClass += 'border-emerald-400 bg-emerald-500/20 text-emerald-100';
            } else if (i === selected) {
              optClass += 'border-red-400 bg-red-500/20 text-red-100';
            } else {
              optClass += 'border-slate-700/50 bg-slate-800/30 text-slate-400';
            }
          }
          return (
            <button
              key={i}
              disabled={submitted && isCorrect}
              onClick={() => {
                if (submitted && isCorrect) return;
                setSelected(i);
                if (submitted) setSubmitted(false);
              }}
              className={optClass}
            >
              <span className="font-mono text-sm mr-2 text-slate-400">
                {String.fromCharCode(65 + i)}.
              </span>
              {opt}
            </button>
          );
        })}
      </div>

      {!submitted && (
        <div className="flex items-center gap-3">
          <button
            onClick={handleSubmit}
            disabled={selected === null}
            className="px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 disabled:text-slate-500 text-white font-semibold transition-colors"
          >
            Verificar
          </button>
          {exercise.hint && (
            <button
              onClick={() => setShowHint((s) => !s)}
              className="text-sm text-slate-400 hover:text-amber-300 underline"
            >
              {showHint ? 'Esconder dica' : 'Preciso de uma dica'}
            </button>
          )}
        </div>
      )}

      {showHint && exercise.hint && !submitted && (
        <div className="rounded-lg bg-amber-950/50 border border-amber-700/40 p-3 text-amber-100/90 text-sm">
          💡 {exercise.hint}
        </div>
      )}

      {submitted && (
        <div
          className={`rounded-lg p-3 text-sm ${
            isCorrect
              ? 'bg-emerald-950/60 border border-emerald-700/40 text-emerald-100'
              : 'bg-red-950/60 border border-red-700/40 text-red-100'
          }`}
        >
          {isCorrect ? '✅ ' : '❌ '}
          {getFeedback()}
          {!isCorrect && (
            <div className="mt-3">
              <button
                onClick={() => {
                  setSubmitted(false);
                  setSelected(null);
                }}
                className="px-4 py-1.5 rounded bg-slate-700 hover:bg-slate-600 text-white text-sm"
              >
                Tentar novamente
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ============================================================
// TABELA VERDADE (preencher saídas)
// ============================================================
export function TruthTableView({
  exercise,
  onComplete,
}: { exercise: TruthTableExercise } & ExerciseProps) {
  const { numInputs, correctOutputs, gateType } = exercise;
  const [outputs, setOutputs] = useState<number[]>(
    () => Array(correctOutputs.length).fill(-1) as number[]
  );
  const [submitted, setSubmitted] = useState(false);

  const numRows = correctOutputs.length;
  // Gerar as combinações de entrada
  const rows: number[][] = [];
  for (let i = 0; i < numRows; i++) {
    if (numInputs === 1) {
      rows.push([i]);
    } else {
      // 2 entradas: as linhas na ordem padrão 00, 01, 10, 11
      rows.push([(i >> 1) & 1, i & 1]);
    }
  }

  const allFilled = outputs.every((o) => o === 0 || o === 1);
  const allCorrect = outputs.every((o, i) => o === correctOutputs[i]);

  const toggle = (idx: number) => {
    if (submitted && allCorrect) return;
    setOutputs((prev) => {
      const next = [...prev];
      next[idx] = next[idx] === -1 ? 0 : next[idx] === 0 ? 1 : -1;
      return next;
    });
    if (submitted) setSubmitted(false);
  };

  const handleSubmit = () => {
    setSubmitted(true);
    onComplete(allCorrect);
  };

  return (
    <div className="rounded-xl border border-slate-700/50 bg-slate-900/70 p-5 space-y-4">
      <p className="text-slate-100 text-lg leading-relaxed">{exercise.prompt}</p>
      <div className="overflow-x-auto">
        <table className="border-collapse">
          <thead>
            <tr className="text-slate-300 text-sm">
              {numInputs === 1 ? (
                <th className="px-4 py-2 border border-slate-700 bg-slate-800/60">A</th>
              ) : (
                <>
                  <th className="px-4 py-2 border border-slate-700 bg-slate-800/60">A</th>
                  <th className="px-4 py-2 border border-slate-700 bg-slate-800/60">B</th>
                </>
              )}
              <th className="px-4 py-2 border border-slate-700 bg-slate-800/60 text-indigo-300">
                Saída ({gateType})
              </th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, i) => {
              const val = outputs[i];
              const expected = correctOutputs[i];
              let cellClass = 'px-4 py-2 border border-slate-700 text-center cursor-pointer select-none font-mono text-lg font-bold ';
              if (!submitted) {
                if (val === -1) cellClass += 'bg-slate-800/40 text-slate-600';
                else if (val === 1) cellClass += 'bg-amber-500/20 text-amber-300';
                else cellClass += 'bg-slate-700/40 text-slate-300';
              } else {
                if (val === expected) {
                  cellClass += 'bg-emerald-500/20 text-emerald-300';
                } else {
                  cellClass += 'bg-red-500/20 text-red-300';
                }
              }
              return (
                <tr key={i}>
                  {row.map((v, j) => (
                    <td key={j} className="px-4 py-2 border border-slate-700 text-center font-mono text-lg text-slate-200">
                      {v}
                    </td>
                  ))}
                  <td className={cellClass} onClick={() => toggle(i)}>
                    {val === -1 ? '?' : val}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-slate-400">Clique nas células da coluna "Saída" para circular entre ? → 0 → 1 → ?.</p>

      <div className="flex items-center gap-3">
        <button
          onClick={handleSubmit}
          disabled={!allFilled}
          className="px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 disabled:text-slate-500 text-white font-semibold transition-colors"
        >
          Verificar tudo
        </button>
      </div>

      {submitted && (
        <div
          className={`rounded-lg p-3 text-sm ${
            allCorrect
              ? 'bg-emerald-950/60 border border-emerald-700/40 text-emerald-100'
              : 'bg-red-950/60 border border-red-700/40 text-red-100'
          }`}
        >
          {allCorrect ? (
            <>✅ Perfeito! Todas as {numRows} linhas estão corretas. Você dominou a tabela da {gateType}.</>
          ) : (
            <>
              ❌ Há {outputs.filter((o, i) => o !== correctOutputs[i]).length} erro(s) na tabela.
              Clique nas células vermelhas para corrigir. Lembre-se: se não souber, volte à lição da porta {gateType}.
              <div className="mt-3">
                <button
                  onClick={() => setSubmitted(false)}
                  className="px-4 py-1.5 rounded bg-slate-700 hover:bg-slate-600 text-white text-sm"
                >
                  Corrigir
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}

// ============================================================
// SIMULADOR DE PORTA (clicar nas entradas)
// ============================================================
export function GateSimulateView({
  exercise,
  onComplete,
}: { exercise: GateSimulateExercise } & ExerciseProps) {
  const [inputs, setInputs] = useState<number[]>(exercise.inputs);
  const [acknowledged, setAcknowledged] = useState(false);

  const isNot = exercise.gateType === 'NOT';
  const currentOutput = gateOutput(exercise.gateType, inputs);

  const toggleInput = (idx: number) => {
    setInputs((prev) => {
      const next = [...prev];
      next[idx] = next[idx] === 1 ? 0 : 1;
      return next;
    });
  };

  return (
    <div className="rounded-xl border border-slate-700/50 bg-slate-900/70 p-5 space-y-4">
      <p className="text-slate-100 text-lg leading-relaxed">{exercise.prompt}</p>
      <div className="flex flex-col items-center gap-3 bg-slate-950/50 rounded-lg p-4">
        <GateSVG type={exercise.gateType} inputs={inputs} output={currentOutput} size={220} />
        <div className="flex gap-3 mt-2">
          {inputs.map((_, i) => (
            <button
              key={i}
              onClick={() => toggleInput(i)}
              className="px-3 py-1.5 rounded bg-slate-700 hover:bg-slate-600 text-white text-sm font-mono"
            >
              Alternar entrada {isNot ? 'A' : i === 0 ? 'A' : 'B'}
            </button>
          ))}
        </div>
      </div>
      {exercise.hint && (
        <p className="text-sm text-slate-400">💡 {exercise.hint}</p>
      )}
      <div className="flex gap-3">
        <button
          onClick={() => {
            setAcknowledged(true);
            onComplete(true);
          }}
          className="px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition-colors"
        >
          {acknowledged ? 'Entendi! Continuar →' : 'Pronto, entendi essa porta'}
        </button>
      </div>
    </div>
  );
}

// ============================================================
// HALF-ADDER INTERATIVO
// ============================================================
export function BuildHalfAdderView({
  exercise,
  onComplete,
}: { exercise: BuildHalfAdderExercise } & ExerciseProps) {
  const [a, setA] = useState(0);
  const [b, setB] = useState(0);
  const [done, setDone] = useState(false);
  const sum = a !== b ? 1 : 0;
  const carry = a === 1 && b === 1 ? 1 : 0;

  return (
    <div className="rounded-xl border border-slate-700/50 bg-slate-900/70 p-5 space-y-4">
      <p className="text-slate-100 text-lg leading-relaxed">{exercise.prompt}</p>
      <div className="flex flex-col items-center gap-4 bg-slate-950/50 rounded-lg p-4">
        <HalfAdderSVG a={a} b={b} sum={sum} carry={carry} />
        <div className="flex gap-6">
          <label className="flex flex-col items-center gap-1 text-slate-300 text-sm">
            <span className="font-semibold">Entrada A</span>
            <button
              onClick={() => setA((v) => (v ? 0 : 1))}
              className={`px-5 py-2 rounded-lg font-mono font-bold text-lg transition-colors ${
                a ? 'bg-amber-400 text-slate-900' : 'bg-slate-700 text-slate-300'
              }`}
            >
              {a}
            </button>
          </label>
          <label className="flex flex-col items-center gap-1 text-slate-300 text-sm">
            <span className="font-semibold">Entrada B</span>
            <button
              onClick={() => setB((v) => (v ? 0 : 1))}
              className={`px-5 py-2 rounded-lg font-mono font-bold text-lg transition-colors ${
                b ? 'bg-amber-400 text-slate-900' : 'bg-slate-700 text-slate-300'
              }`}
            >
              {b}
            </button>
          </label>
        </div>
        <div className="text-slate-300 text-sm bg-slate-800/40 px-4 py-2 rounded-lg">
          Soma: <span className="font-mono text-amber-300 font-bold">{sum}</span> •
          Carry: <span className="font-mono text-amber-300 font-bold">{carry}</span> •
          Resultado: <span className="font-mono text-emerald-300 font-bold">{carry * 2 + sum}</span>
          {' '}({a} + {b} = {carry * 2 + sum})
        </div>
      </div>
      <div className="flex gap-3">
        <button
          onClick={() => {
            setDone(true);
            onComplete(true);
          }}
          className="px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition-colors"
        >
          {done ? 'Entendi, continuar →' : 'Sim, eu vi funcionar! Somou com lógica!'}
        </button>
      </div>
    </div>
  );
}

// ============================================================
// IDENTIFICAR PORTA PELA TABELA
// ============================================================
export function IdentifyGateView({
  exercise,
  onComplete,
}: { exercise: IdentifyGateExercise } & ExerciseProps) {
  const [selected, setSelected] = useState<GateType | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const isCorrect = selected === exercise.correctGate;

  const handleSubmit = () => {
    if (!selected) return;
    setSubmitted(true);
    onComplete(isCorrect);
  };

  return (
    <div className="rounded-xl border border-slate-700/50 bg-slate-900/70 p-5 space-y-4">
      <p className="text-slate-100 text-lg leading-relaxed whitespace-pre-line">
        {exercise.prompt}
      </p>
      <div className="flex flex-wrap gap-3">
        {exercise.options.map((g) => {
          let cls =
            'px-5 py-2 rounded-lg border font-mono font-bold text-base transition-all cursor-pointer ';
          if (!submitted) {
            cls += selected === g
              ? 'border-indigo-400 bg-indigo-500/20 text-indigo-100'
              : 'border-slate-700 bg-slate-800/50 text-slate-300 hover:border-slate-500';
          } else {
            if (g === exercise.correctGate) cls += 'border-emerald-400 bg-emerald-500/20 text-emerald-100';
            else if (g === selected) cls += 'border-red-400 bg-red-500/20 text-red-100';
            else cls += 'border-slate-700/30 bg-slate-800/20 text-slate-500';
          }
          return (
            <button
              key={g}
              disabled={submitted && isCorrect}
              onClick={() => {
                setSelected(g);
                if (submitted) setSubmitted(false);
              }}
              className={cls}
            >
              {g}
            </button>
          );
        })}
      </div>
      {!submitted && (
        <button
          onClick={handleSubmit}
          disabled={!selected}
          className="px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 disabled:text-slate-500 text-white font-semibold transition-colors"
        >
          Verificar
        </button>
      )}
      {submitted && (
        <div
          className={`rounded-lg p-3 text-sm ${
            isCorrect
              ? 'bg-emerald-950/60 border border-emerald-700/40 text-emerald-100'
              : 'bg-red-950/60 border border-red-700/40 text-red-100'
          }`}
        >
          {isCorrect
            ? '✅ Correto! Você reconheceu a tabela.'
            : `❌ Não era ${selected}. Analise a tabela com mais cuidado: quando a saída é 1? Quando é 0? Compare com as tabelas que você já aprendeu.`}
          {!isCorrect && (
            <div className="mt-3">
              <button
                onClick={() => {
                  setSubmitted(false);
                  setSelected(null);
                }}
                className="px-4 py-1.5 rounded bg-slate-700 hover:bg-slate-600 text-white text-sm"
              >
                Tentar novamente
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ============================================================
// RESPOSTA LIVRE
// ============================================================
export function FreeResponseView({
  exercise,
  onComplete,
}: { exercise: FreeResponseExercise } & ExerciseProps) {
  const [text, setText] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [showSample, setShowSample] = useState(false);

  const words = text.trim().split(/\s+/).filter(Boolean).length;
  const minWords = exercise.minWords ?? 10;
  const lowerText = text.toLowerCase();
  const foundKeywords = exercise.keywords.filter((kw) =>
    lowerText.includes(kw.toLowerCase())
  );
  const hasMinWords = words >= minWords;
  const hasEnoughKeywords = foundKeywords.length >= Math.ceil(exercise.keywords.length * 0.4); // 40% das palavras
  const looksGood = hasMinWords && hasEnoughKeywords;

  const handleSubmit = () => {
    if (!hasMinWords) return;
    setSubmitted(true);
    onComplete(looksGood);
  };

  return (
    <div className="rounded-xl border border-slate-700/50 bg-slate-900/70 p-5 space-y-4">
      <p className="text-slate-100 text-lg leading-relaxed">{exercise.prompt}</p>
      <textarea
        value={text}
        onChange={(e) => {
          setText(e.target.value);
          if (submitted) setSubmitted(false);
        }}
        rows={5}
        placeholder="Escreva com suas palavras aqui. Não se preocupe com a gramática; o que importa é a ideia..."
        className="w-full bg-slate-950/60 border border-slate-700 rounded-lg p-3 text-slate-100 focus:border-indigo-400 focus:outline-none"
      />
      <div className="flex flex-wrap gap-3 items-center justify-between text-sm">
        <div className="text-slate-400">
          Palavras: <span className={hasMinWords ? 'text-emerald-400 font-bold' : 'text-amber-400'}>{words}</span>
          {' / '}
          mínimo: {minWords}
        </div>
        <button
          onClick={() => setShowSample((s) => !s)}
          className="text-slate-400 hover:text-indigo-300 underline"
        >
          {showSample ? 'Ocultar resposta exemplo' : 'Ver resposta exemplo (só depois de tentar!)'}
        </button>
      </div>

      {showSample && (
        <div className="rounded-lg bg-indigo-950/40 border border-indigo-700/40 p-3 text-indigo-100 text-sm italic">
          "{exercise.sampleAnswer}"
        </div>
      )}

      <button
        onClick={handleSubmit}
        disabled={!hasMinWords}
        className="px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 disabled:text-slate-500 text-white font-semibold transition-colors"
      >
        Verificar minha resposta
      </button>

      {submitted && (
        <div
          className={`rounded-lg p-3 text-sm ${
            looksGood
              ? 'bg-emerald-950/60 border border-emerald-700/40 text-emerald-100'
              : 'bg-amber-950/60 border border-amber-700/40 text-amber-100'
          }`}
        >
          {looksGood ? (
            <>
              ✅ Boa! Sua resposta tem {words} palavras e toca em pontos chave da explicação ({foundKeywords.length} palavras-chave detectadas de {exercise.keywords.length} esperadas).
              Se você explicou a ideia principal com suas próprias palavras, está aprovado(a)!
            </>
          ) : (
            <>
              ⚠️ Sua resposta tem {words} palavras (mínimo {minWords}) e menciona{' '}
              {foundKeywords.length} dos conceitos esperados. Tente escrever mais, mencionando:
              {' '}
              <span className="italic">
                {exercise.keywords.slice(0, 6).join(', ')}...
              </span>
              <div className="mt-3">
                <button
                  onClick={() => setSubmitted(false)}
                  className="px-4 py-1.5 rounded bg-slate-700 hover:bg-slate-600 text-white text-sm"
                >
                  Editar resposta
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
