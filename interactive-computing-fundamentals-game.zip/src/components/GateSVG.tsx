import type { GateType } from '../types';

interface GateSVGProps {
  type: GateType;
  inputs: number[];
  output: number;
  size?: number;
  showLabels?: boolean;
}

/**
 * Desenha uma porta lógica em SVG.
 * Entradas à esquerda, saída à direita.
 * Fios coloridos: branco/cinza = 0, dourado/amarelo brilhante = 1.
 */
export function GateSVG({ type, inputs, output, size = 120, showLabels = true }: GateSVGProps) {
  const width = size;
  const height = size * 0.8;
  const wireColor = (v: number) => (v === 1 ? '#facc15' : '#475569'); // amber-400 ou slate-600
  const wireWidth = 3;

  // Para portas de 1 entrada (NOT)
  const isNot = type === 'NOT';

  // Posições das entradas (y)
  const inputY1 = height * 0.3;
  const inputY2 = height * 0.7;
  const gateLeft = width * 0.35;
  const gateRight = width * 0.8;
  const outputX = width * 0.95;
  const gateCenterY = height / 2;

  // Forma da porta
  const renderGateBody = () => {
    const bodyStroke = '#e2e8f0';
    const bodyFill = 'rgba(15, 23, 42, 0.6)';

    switch (type) {
      case 'NOT':
        // Triângulo com círculo na ponta
        return (
          <g>
            <polygon
              points={`${gateLeft},${height * 0.2} ${gateLeft},${height * 0.8} ${gateRight - 8},${gateCenterY}`}
              fill={bodyFill}
              stroke={bodyStroke}
              strokeWidth={2}
            />
            <circle
              cx={gateRight - 4}
              cy={gateCenterY}
              r={5}
              fill={bodyFill}
              stroke={bodyStroke}
              strokeWidth={2}
            />
          </g>
        );
      case 'AND':
        // Meio-D: reta na esquerda, arco na direita
        return (
          <path
            d={`M ${gateLeft},${height * 0.2} L ${gateLeft + (gateRight - gateLeft) * 0.4},${height * 0.2}
                A ${(gateRight - gateLeft) * 0.55} ${height * 0.3} 0 0 1 ${gateLeft + (gateRight - gateLeft) * 0.4},${height * 0.8}
                L ${gateLeft},${height * 0.8} Z`}
            fill={bodyFill}
            stroke={bodyStroke}
            strokeWidth={2}
          />
        );
      case 'NAND':
        return (
          <g>
            <path
              d={`M ${gateLeft},${height * 0.2} L ${gateLeft + (gateRight - gateLeft) * 0.5},${height * 0.2}
                  A ${(gateRight - gateLeft) * 0.55} ${height * 0.3} 0 0 1 ${gateLeft + (gateRight - gateLeft) * 0.5},${height * 0.8}
                  L ${gateLeft},${height * 0.8} Z`}
              fill={bodyFill}
              stroke={bodyStroke}
              strokeWidth={2}
            />
            <circle cx={gateRight - 4} cy={gateCenterY} r={5} fill={bodyFill} stroke={bodyStroke} strokeWidth={2} />
          </g>
        );
      case 'OR':
        return (
          <path
            d={`M ${gateLeft},${height * 0.2}
                Q ${gateLeft + (gateRight - gateLeft) * 0.5},${height * 0.05} ${gateRight - 8},${gateCenterY}
                Q ${gateLeft + (gateRight - gateLeft) * 0.5},${height * 0.95} ${gateLeft},${height * 0.8}
                Q ${gateLeft + (gateRight - gateLeft) * 0.35},${gateCenterY} ${gateLeft},${height * 0.2} Z`}
            fill={bodyFill}
            stroke={bodyStroke}
            strokeWidth={2}
          />
        );
      case 'NOR':
        return (
          <g>
            <path
              d={`M ${gateLeft},${height * 0.2}
                  Q ${gateLeft + (gateRight - gateLeft) * 0.5},${height * 0.05} ${gateRight - 12},${gateCenterY}
                  Q ${gateLeft + (gateRight - gateLeft) * 0.5},${height * 0.95} ${gateLeft},${height * 0.8}
                  Q ${gateLeft + (gateRight - gateLeft) * 0.35},${gateCenterY} ${gateLeft},${height * 0.2} Z`}
              fill={bodyFill}
              stroke={bodyStroke}
              strokeWidth={2}
            />
            <circle cx={gateRight - 4} cy={gateCenterY} r={5} fill={bodyFill} stroke={bodyStroke} strokeWidth={2} />
          </g>
        );
      case 'XOR':
        return (
          <g>
            {/* Curva extra na entrada */}
            <path
              d={`M ${gateLeft - 2},${height * 0.2}
                  Q ${gateLeft + (gateRight - gateLeft) * 0.2},${gateCenterY} ${gateLeft - 2},${height * 0.8}`}
              fill="none"
              stroke={bodyStroke}
              strokeWidth={2}
            />
            <path
              d={`M ${gateLeft + 6},${height * 0.2}
                  Q ${gateLeft + (gateRight - gateLeft) * 0.55},${height * 0.05} ${gateRight - 8},${gateCenterY}
                  Q ${gateLeft + (gateRight - gateLeft) * 0.55},${height * 0.95} ${gateLeft + 6},${height * 0.8}
                  Q ${gateLeft + (gateRight - gateLeft) * 0.35},${gateCenterY} ${gateLeft + 6},${height * 0.2} Z`}
              fill={bodyFill}
              stroke={bodyStroke}
              strokeWidth={2}
            />
          </g>
        );
      case 'XNOR':
        return (
          <g>
            <path
              d={`M ${gateLeft - 2},${height * 0.2}
                  Q ${gateLeft + (gateRight - gateLeft) * 0.2},${gateCenterY} ${gateLeft - 2},${height * 0.8}`}
              fill="none"
              stroke={bodyStroke}
              strokeWidth={2}
            />
            <path
              d={`M ${gateLeft + 6},${height * 0.2}
                  Q ${gateLeft + (gateRight - gateLeft) * 0.55},${height * 0.05} ${gateRight - 12},${gateCenterY}
                  Q ${gateLeft + (gateRight - gateLeft) * 0.55},${height * 0.95} ${gateLeft + 6},${height * 0.8}
                  Q ${gateLeft + (gateRight - gateLeft) * 0.35},${gateCenterY} ${gateLeft + 6},${height * 0.2} Z`}
              fill={bodyFill}
              stroke={bodyStroke}
              strokeWidth={2}
            />
            <circle cx={gateRight - 4} cy={gateCenterY} r={5} fill={bodyFill} stroke={bodyStroke} strokeWidth={2} />
          </g>
        );
      default:
        return null;
    }
  };

  return (
    <svg
      viewBox={`0 0 ${width} ${height + 10}`}
      width={width}
      height={height + 10}
      className="select-none"
    >
      {/* Fios de entrada */}
      {isNot ? (
        <>
          <line
            x1={0}
            y1={gateCenterY}
            x2={gateLeft}
            y2={gateCenterY}
            stroke={wireColor(inputs[0] ?? 0)}
            strokeWidth={wireWidth}
          />
          {/* Indicador de entrada A */}
          {showLabels && (
            <text x={2} y={gateCenterY - 8} fill="#94a3b8" fontSize={11}>
              A
            </text>
          )}
          {/* Círculo do bit */}
          <circle
            cx={5}
            cy={gateCenterY}
            r={6}
            fill={inputs[0] === 1 ? '#facc15' : '#1e293b'}
            stroke="#64748b"
            strokeWidth={1.5}
          />
          <text
            x={5}
            y={gateCenterY + 4}
            textAnchor="middle"
            fill={inputs[0] === 1 ? '#1e293b' : '#cbd5e1'}
            fontSize={9}
            fontWeight="bold"
          >
            {inputs[0]}
          </text>
        </>
      ) : (
        <>
          {/* Entrada A */}
          <line
            x1={0}
            y1={inputY1}
            x2={gateLeft}
            y2={inputY1}
            stroke={wireColor(inputs[0] ?? 0)}
            strokeWidth={wireWidth}
          />
          <circle
            cx={5}
            cy={inputY1}
            r={6}
            fill={inputs[0] === 1 ? '#facc15' : '#1e293b'}
            stroke="#64748b"
            strokeWidth={1.5}
          />
          <text
            x={5}
            y={inputY1 + 4}
            textAnchor="middle"
            fill={inputs[0] === 1 ? '#1e293b' : '#cbd5e1'}
            fontSize={9}
            fontWeight="bold"
          >
            {inputs[0]}
          </text>
          {showLabels && (
            <text x={16} y={inputY1 - 6} fill="#94a3b8" fontSize={11}>
              A
            </text>
          )}
          {/* Entrada B */}
          <line
            x1={0}
            y1={inputY2}
            x2={gateLeft}
            y2={inputY2}
            stroke={wireColor(inputs[1] ?? 0)}
            strokeWidth={wireWidth}
          />
          <circle
            cx={5}
            cy={inputY2}
            r={6}
            fill={inputs[1] === 1 ? '#facc15' : '#1e293b'}
            stroke="#64748b"
            strokeWidth={1.5}
          />
          <text
            x={5}
            y={inputY2 + 4}
            textAnchor="middle"
            fill={inputs[1] === 1 ? '#1e293b' : '#cbd5e1'}
            fontSize={9}
            fontWeight="bold"
          >
            {inputs[1]}
          </text>
          {showLabels && (
            <text x={16} y={inputY2 - 6} fill="#94a3b8" fontSize={11}>
              B
            </text>
          )}
        </>
      )}

      {/* Corpo da porta */}
      {renderGateBody()}

      {/* Nome da porta */}
      {showLabels && (
        <text
          x={gateLeft + (gateRight - gateLeft) / 2}
          y={gateCenterY + 4}
          textAnchor="middle"
          fill="#f1f5f9"
          fontSize={13}
          fontWeight="bold"
        >
          {type}
        </text>
      )}

      {/* Fio de saída */}
      <line
        x1={type === 'NOT' || type === 'NAND' || type === 'NOR' || type === 'XNOR' ? gateRight + 2 : gateRight - 8}
        y1={gateCenterY}
        x2={outputX}
        y2={gateCenterY}
        stroke={wireColor(output)}
        strokeWidth={wireWidth}
      />
      <circle
        cx={outputX - 2}
        cy={gateCenterY}
        r={6}
        fill={output === 1 ? '#facc15' : '#1e293b'}
        stroke="#64748b"
        strokeWidth={1.5}
      />
      <text
        x={outputX - 2}
        y={gateCenterY + 4}
        textAnchor="middle"
        fill={output === 1 ? '#1e293b' : '#cbd5e1'}
        fontSize={9}
        fontWeight="bold"
      >
        {output}
      </text>
      {showLabels && (
        <text x={outputX - 2} y={gateCenterY - 10} fill="#94a3b8" fontSize={10} textAnchor="middle">
          S
        </text>
      )}
    </svg>
  );
}
