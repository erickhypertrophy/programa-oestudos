interface HalfAdderSVGProps {
  a: number;
  b: number;
  sum: number;
  carry: number;
}

/**
 * Desenha um half-adder mostrando as duas portas (XOR e AND)
 * e os fios coloridos de acordo com os valores.
 */
export function HalfAdderSVG({ a, b, sum, carry }: HalfAdderSVGProps) {
  const wireColor = (v: number) => (v === 1 ? '#facc15' : '#475569');
  const w = 340;
  const h = 220;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full max-w-lg">
      {/* Fios de entrada A e B indo para as duas portas */}
      {/* A vem de x=20, y=50; B vem de x=20, y=170 */}

      {/* Rótulos A e B */}
      <text x={8} y={54} fill="#e2e8f0" fontSize={14} fontWeight="bold">A</text>
      <text x={8} y={174} fill="#e2e8f0" fontSize={14} fontWeight="bold">B</text>

      {/* Fio A principal: da esquerda até bifurcar */}
      <line x1={25} y1={50} x2={90} y2={50} stroke={wireColor(a)} strokeWidth={3} />
      <circle cx={28} cy={50} r={6} fill={a === 1 ? '#facc15' : '#1e293b'} stroke="#64748b" strokeWidth={1.5} />
      <text x={28} y={54} textAnchor="middle" fill={a === 1 ? '#1e293b' : '#cbd5e1'} fontSize={10} fontWeight="bold">{a}</text>

      {/* Fio B principal */}
      <line x1={25} y1={170} x2={90} y2={170} stroke={wireColor(b)} strokeWidth={3} />
      <circle cx={28} cy={170} r={6} fill={b === 1 ? '#facc15' : '#1e293b'} stroke="#64748b" strokeWidth={1.5} />
      <text x={28} y={174} textAnchor="middle" fill={b === 1 ? '#1e293b' : '#cbd5e1'} fontSize={10} fontWeight="bold">{b}</text>

      {/* Fios que alimentam o XOR (porta superior) */}
      {/* A sobe/desce para y=70 (entrada superior XOR) */}
      <line x1={90} y1={50} x2={90} y2={70} stroke={wireColor(a)} strokeWidth={3} />
      <line x1={90} y1={70} x2={130} y2={70} stroke={wireColor(a)} strokeWidth={3} />
      {/* B sobe para y=90 (entrada inferior XOR) */}
      <line x1={90} y1={170} x2={90} y2={90} stroke={wireColor(b)} strokeWidth={3} />
      <line x1={90} y1={90} x2={130} y2={90} stroke={wireColor(b)} strokeWidth={3} />

      {/* Porta XOR (superior, dá o SUM) */}
      <path
        d="M 128,60 Q 150,50 180,80 Q 150,110 128,100 Q 142,80 128,60 Z"
        fill="rgba(15,23,42,0.6)"
        stroke="#e2e8f0"
        strokeWidth={2}
      />
      {/* curva extra do XOR */}
      <path d="M 122,60 Q 138,80 122,100" fill="none" stroke="#e2e8f0" strokeWidth={2} />
      <text x={150} y={84} textAnchor="middle" fill="#f1f5f9" fontSize={12} fontWeight="bold">XOR</text>
      <text x={150} y={120} textAnchor="middle" fill="#94a3b8" fontSize={11}>Soma (S)</text>

      {/* Fio de saída do XOR (soma) */}
      <line x1={180} y1={80} x2={280} y2={80} stroke={wireColor(sum)} strokeWidth={3} />
      <circle cx={285} cy={80} r={7} fill={sum === 1 ? '#facc15' : '#1e293b'} stroke="#64748b" strokeWidth={1.5} />
      <text x={285} y={84} textAnchor="middle" fill={sum === 1 ? '#1e293b' : '#cbd5e1'} fontSize={11} fontWeight="bold">{sum}</text>
      <text x={300} y={84} fill="#e2e8f0" fontSize={12} fontWeight="bold">S</text>

      {/* Fios que alimentam o AND (porta inferior) */}
      {/* A desce para y=150 (entrada superior do AND) */}
      <line x1={90} y1={50} x2={90} y2={150} stroke={wireColor(a)} strokeWidth={3} />
      <line x1={90} y1={150} x2={130} y2={150} stroke={wireColor(a)} strokeWidth={3} />
      {/* B já está em y=170; vai direto para a entrada inferior do AND */}
      <line x1={90} y1={170} x2={130} y2={170} stroke={wireColor(b)} strokeWidth={3} />

      {/* Porta AND (inferior, dá o Carry) */}
      <path
        d="M 130,140 L 152,140 A 25 25 0 0 1 152,190 L 130,190 Z"
        fill="rgba(15,23,42,0.6)"
        stroke="#e2e8f0"
        strokeWidth={2}
      />
      <text x={152} y={170} textAnchor="middle" fill="#f1f5f9" fontSize={12} fontWeight="bold">AND</text>
      <text x={152} y={208} textAnchor="middle" fill="#94a3b8" fontSize={11}>Vai-um (C)</text>

      {/* Fio de saída do AND (carry) */}
      <line x1={177} y1={165} x2={280} y2={165} stroke={wireColor(carry)} strokeWidth={3} />
      <circle cx={285} cy={165} r={7} fill={carry === 1 ? '#facc15' : '#1e293b'} stroke="#64748b" strokeWidth={1.5} />
      <text x={285} y={169} textAnchor="middle" fill={carry === 1 ? '#1e293b' : '#cbd5e1'} fontSize={11} fontWeight="bold">{carry}</text>
      <text x={300} y={169} fill="#e2e8f0" fontSize={12} fontWeight="bold">C</text>

      {/* Título */}
      <text x={w/2} y={25} textAnchor="middle" fill="#94a3b8" fontSize={14} fontWeight="bold">Half-Adder (meio somador)</text>
    </svg>
  );
}
