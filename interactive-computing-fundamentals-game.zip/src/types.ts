// Tipos para o curso/jogo "A Base de Tudo"

export type GateType = 'NOT' | 'AND' | 'OR' | 'NAND' | 'NOR' | 'XOR' | 'XNOR';

export interface GlossaryEntry {
  term: string;
  termEn?: string; // termo em inglês
  definition: string;
}

export type ExerciseType =
  | 'multiple-choice'
  | 'truth-table'
  | 'binary-convert'
  | 'gate-simulate'
  | 'free-response'
  | 'build-half-adder'
  | 'build-full-adder'
  | 'identify-gate'
  | 'note';

export interface BaseExercise {
  id: string;
  type: ExerciseType;
  prompt: string;
  explanation?: string; // explicação após acertar
  hint?: string;
}

export interface MultipleChoiceExercise extends BaseExercise {
  type: 'multiple-choice';
  options: string[];
  correctIndex: number;
  feedbackIncorreto?: (string | undefined)[]; // feedback por índice da opção errada; undefined = sem feedback especial
}

export interface TruthTableExercise extends BaseExercise {
  type: 'truth-table';
  gateType: GateType;
  // Respostas corretas para a coluna de saída (sequência: 00, 01, 10, 11; ou NOT: 0, 1)
  correctOutputs: number[];
  numInputs: 1 | 2;
}

export interface BinaryConvertExercise extends BaseExercise {
  type: 'binary-convert';
  // Conversão decimal -> binário ou binário -> decimal
  direction: 'dec-to-bin' | 'bin-to-dec';
  value: number; // o valor dado (em decimal), se for dec-to-bin; valor binário é uma string mas guardamos como number? Usamos string separado.
  binaryValue?: string;
  decValue?: number;
}

export interface GateSimulateExercise extends BaseExercise {
  type: 'gate-simulate';
  gateType: GateType;
  inputs: number[]; // os valores de entrada já setados; o aluno deve definir a saída
  correctOutput: number;
}

export interface FreeResponseExercise extends BaseExercise {
  type: 'free-response';
  keywords: string[]; // palavras-chave que devem estar presentes (case-insensitive)
  minWords?: number;
  sampleAnswer: string;
}

export interface IdentifyGateExercise extends BaseExercise {
  type: 'identify-gate';
  // Descreve uma tabela-verdade ou um comportamento; aluno escolhe qual porta é
  truthTable: number[][];
  options: GateType[];
  correctGate: GateType;
}

export interface BuildHalfAdderExercise extends BaseExercise {
  type: 'build-half-adder';
}

export interface NoteExercise extends BaseExercise {
  type: 'note';
}

export type Exercise =
  | MultipleChoiceExercise
  | TruthTableExercise
  | BinaryConvertExercise
  | GateSimulateExercise
  | FreeResponseExercise
  | IdentifyGateExercise
  | BuildHalfAdderExercise
  | NoteExercise;

export interface LessonBlock {
  kind: 'narrative' | 'aside' | 'image-caption' | 'exercise' | 'reveal' | 'quote' | 'boss-intro' | 'phase-complete';
  title?: string;
  text?: string;
  texts?: string[]; // para múltiplos parágrafos na narrativa
  exercise?: Exercise;
  asidetype?: 'curiosity' | 'warning' | 'history' | 'simplification' | 'tip';
}

export interface Lesson {
  id: string;
  title: string;
  subtitle?: string;
  blocks: LessonBlock[];
  newGlossaryTerms?: GlossaryEntry[];
}

export interface Phase {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  icon: string; // emoji ou caractere
  color: string; // cor tailwind para o tema da fase
  lessons: Lesson[];
  finalMessage?: string;
}

export interface ExerciseResult {
  exerciseId: string;
  attempts: number;
  correct: boolean;
  lastAttemptAt: number;
}

export interface Progress {
  currentPhaseId: number;
  currentLessonId: string | null;
  completedLessons: string[]; // lesson ids
  completedExercises: Record<string, ExerciseResult>;
  glossary: GlossaryEntry[];
  phasesUnlocked: number[];
  lastSeenAt: number;
}
